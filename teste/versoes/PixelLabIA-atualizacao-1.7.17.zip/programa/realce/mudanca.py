"""Instalação sempre em C:\\rla-lab\\<Nome do app> (padrão RLA.dev): muda a pasta de quem instalou em
outro lugar (Downloads, Área de Trabalho…), de forma automática.

O Windows não deixa mover uma pasta enquanto um programa roda de dentro dela, então:
  1. ao abrir, o lançador (realceia.pyw) chama precisa_mudar(); se a pasta não está no lugar
     padrão, iniciar() copia este arquivo para fora da pasta e o roda com o Python da pasta de
     dados (%LOCALAPPDATA%\\RealceIA, fora da pasta do app), e o lançador fecha;
  2. este arquivo, como ajudante (main), espera o lançador fechar, move a pasta inteira para
     C:\\rla-lab\\<Nome do app> (no mesmo disco é só renomear; de outro disco, copia, confere e só
     então apaga a antiga) e abre o app no lugar novo. O app refaz os atalhos sozinho, porque a
     marca dos atalhos leva o caminho da pasta (realce/atalhos.py, ATALHOS_VERSAO);
  3. se o ambiente Python não abrir no lugar novo, roda o instalador lá, que o refaz a partir do
     cache (sem baixar tudo de novo).
Se algo der errado antes de a pasta mudar, nada se perde: o app abre no lugar antigo e tenta de
novo nas próximas aberturas (até TENTATIVAS vezes). Sem permissão para criar C:\\rla-lab, usa
%LOCALAPPDATA%\\Programs\\rla-lab. Se o lugar novo já tem outra instalação, não mexe em nada.

Só usa a biblioteca padrão: roda fora do app, sem o resto do código.
"""

import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

NOME_APP = "Pixel Lab IA"
TENTATIVAS = 3  # tentativas que falharam antes de desistir (a pessoa pode mudar rodando o instalador)
ESTADO = Path(".runtime") / "mudanca.json"  # dentro da pasta do app


def raizes() -> list[Path]:
    """Onde ficam os apps da RLA.dev, na ordem de preferência: C:\\rla-lab e, sem permissão para
    criar pastas na raiz do disco, %LOCALAPPDATA%\\Programs\\rla-lab."""
    out = []
    if os.environ.get("REALCE_RAIZ_RLA_LAB"):  # para testes
        out.append(Path(os.environ["REALCE_RAIZ_RLA_LAB"]))
    else:
        out.append(Path(os.environ.get("SystemDrive", "C:") + "\\") / "rla-lab")
    if os.environ.get("LOCALAPPDATA"):
        out.append(Path(os.environ["LOCALAPPDATA"]) / "Programs" / "rla-lab")
    return out


def _mesmo(a: Path, b: Path) -> bool:
    return os.path.normcase(os.path.abspath(a)) == os.path.normcase(os.path.abspath(b))


def no_lugar(base: Path) -> bool:
    """A pasta do app já está numa das raízes (C:\\rla-lab ou a reserva)."""
    return any(_mesmo(base.parent, r) for r in raizes())


def _estado(base: Path) -> dict:
    try:
        return json.loads((base / ESTADO).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _gravar_estado(base: Path, dados: dict) -> None:
    try:
        (base / ESTADO).parent.mkdir(exist_ok=True)
        (base / ESTADO).write_text(json.dumps(dados, ensure_ascii=False, indent=1), encoding="utf-8")
    except OSError:
        pass


def precisa_mudar(base: Path) -> bool:
    """Se esta instalação deve ir para o lugar padrão agora."""
    if sys.platform != "win32" and not os.environ.get("REALCE_TESTE_MUDANCA"):
        return False
    if os.environ.get("REALCE_SEM_MUDANCA"):  # o ajudante reabrindo depois de uma tentativa falha
        return False
    if (base / ".git").exists() or not (base / "programa" / "app.py").is_file() or not (base / ".venv").is_dir():
        return False  # cópia de desenvolvimento ou organização antiga
    if no_lugar(base):
        return False
    return int(_estado(base).get("falhas", 0)) < TENTATIVAS


def _pode_gravar(pasta: Path) -> bool:
    try:
        pasta.mkdir(parents=True, exist_ok=True)
        teste = pasta / f".teste-{os.getpid()}"
        teste.write_text("ok")
        teste.unlink()
        return True
    except OSError:
        return False


def destino() -> Path | None:
    """A pasta nova: a primeira raiz em que dá para gravar. None se a pasta do app já existe lá
    com conteúdo (outra instalação, por exemplo: não mexe em nada)."""
    for raiz in raizes():
        if _pode_gravar(raiz):
            alvo = raiz / NOME_APP
            if alvo.exists() and any(alvo.iterdir()):
                return None
            return alvo
    return None


def python_de_fora() -> str | None:
    """O Python da pasta de dados (o do .venv fica dentro da pasta que vai ser movida)."""
    base = getattr(sys, "_base_executable", "") or sys.executable
    exe = Path(base)
    pyw = exe.with_name("pythonw.exe")
    for p in (pyw, exe):
        if p.is_file() and not _dentro(p, Path(sys.prefix)):
            return str(p)
    return None


def _dentro(p: Path, pasta: Path) -> bool:
    try:
        Path(os.path.abspath(p)).relative_to(os.path.abspath(pasta))
        return True
    except ValueError:
        return False


def iniciar(base: Path, argv: list[str]) -> bool:
    """Põe o ajudante para rodar, fora da pasta do app. True: o lançador deve fechar já."""
    alvo = destino()
    py = python_de_fora()
    if alvo is None or py is None or _dentro(Path(py), base):
        print("mudança de pasta: sem destino livre ou sem Python de fora; fica onde está", flush=True)
        return False
    dados = Path(os.environ.get("REALCE_DADOS") or alvo.parent) / "mudanca"
    try:
        dados.mkdir(parents=True, exist_ok=True)
        ajudante = dados / "mover.py"
        shutil.copy2(__file__, ajudante)
    except OSError as e:
        print("mudança de pasta: não deu para preparar o ajudante:", e, flush=True)
        return False
    flags = 0
    if os.name == "nt":
        flags = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW
    cmd = [py, str(ajudante), "--de", str(base), "--para", str(alvo), "--pid", str(os.getpid()), "--", *argv]
    subprocess.Popen(cmd, cwd=str(dados), creationflags=flags, close_fds=True,
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print(f"mudança de pasta: {base} -> {alvo}", flush=True)
    return True


# ---------------- ajudante (roda fora da pasta do app) ----------------

def _esperar_fechar(pid: int, limite: float = 120) -> None:
    fim = time.time() + limite
    if os.name == "nt":
        import ctypes

        h = ctypes.windll.kernel32.OpenProcess(0x00100000, False, pid)  # SYNCHRONIZE
        if h:
            ctypes.windll.kernel32.WaitForSingleObject(h, int(limite * 1000))
            ctypes.windll.kernel32.CloseHandle(h)
        time.sleep(1)  # o Windows solta os arquivos um instante depois
        return
    while time.time() < fim:
        try:
            os.kill(pid, 0)
        except OSError:
            return
        time.sleep(0.3)


def _arquivos(pasta: Path) -> dict[str, int]:
    return {str(p.relative_to(pasta)): p.stat().st_size for p in pasta.rglob("*") if p.is_file()}


def mover(de: Path, para: Path, tentativas: int = 10, espera: float = 1.0) -> str:
    """Move a pasta. No mesmo disco renomeia; de outro disco copia, confere e só então apaga a
    antiga. Devolve "movida", "copiada" (a antiga ficou, porque não deu para apagar tudo) ou
    levanta OSError sem ter mudado nada."""
    para.parent.mkdir(parents=True, exist_ok=True)
    if para.is_dir() and not any(para.iterdir()):
        para.rmdir()  # pasta vazia no caminho (o Windows não renomeia por cima dela)
    ultimo = None
    for _ in range(tentativas):  # um arquivo preso (antivírus, Explorador) costuma soltar logo
        try:
            os.rename(de, para)
            return "movida"
        except OSError as e:
            ultimo = e
            if getattr(e, "errno", None) == 18 or getattr(e, "winerror", None) == 17:  # outro disco
                break
            time.sleep(espera)
    else:
        raise ultimo
    temp = para.with_name(para.name + ".movendo")
    shutil.rmtree(temp, ignore_errors=True)
    try:
        shutil.copytree(de, temp, symlinks=True)
        if _arquivos(temp) != _arquivos(de):
            raise OSError("a cópia não confere com a pasta original")
        os.rename(temp, para)
    except OSError:
        shutil.rmtree(temp, ignore_errors=True)
        raise
    shutil.rmtree(de, ignore_errors=True)
    return "copiada" if de.exists() else "movida"


def _log(dados_dir: Path, msg: str) -> None:
    try:
        with open(dados_dir / "mudanca.log", "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg + "\n")
    except OSError:
        pass


def _python_ok(pasta: Path) -> bool:
    py = pasta / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    try:
        return subprocess.run([str(py), "-c", "import sys"], capture_output=True, timeout=120,
                              creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def _abrir(pasta: Path, argv: list[str], env: dict) -> None:
    pyw = pasta / ".venv" / ("Scripts/pythonw.exe" if os.name == "nt" else "bin/python")
    subprocess.Popen([str(pyw), str(pasta / "programa" / "realceia.pyw"), *argv], cwd=str(pasta / "programa"),
                     env=env, close_fds=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))


def main(args: list[str]) -> int:
    def valor(nome):
        return args[args.index(nome) + 1]

    de, para, pid = Path(valor("--de")), Path(valor("--para")), int(valor("--pid"))
    argv = args[args.index("--") + 1:] if "--" in args else []
    aqui = Path(__file__).resolve().parent
    _esperar_fechar(pid)
    try:
        como = mover(de, para)
    except OSError as e:
        estado = _estado(de)
        estado.update(falhas=int(estado.get("falhas", 0)) + 1, erro=str(e)[:300], quando=time.time())
        _gravar_estado(de, estado)
        _log(aqui, f"não deu para mudar {de} -> {para}: {e}; abrindo no lugar antigo")
        _abrir(de, argv, dict(os.environ, REALCE_SEM_MUDANCA="1"))
        return 1
    _gravar_estado(para, {"de": str(de), "como": como, "quando": time.time()})
    _log(aqui, f"pasta {como}: {de} -> {para}")
    if _python_ok(para):
        _abrir(para, argv, dict(os.environ))
        return 0
    # o ambiente Python não abriu no lugar novo: o instalador o refaz (a partir do cache) e abre o app
    _log(aqui, "o ambiente Python não abriu no lugar novo; rodando o instalador")
    bat = next(iter(sorted(para.glob("Instalar*.bat"))), None)
    if bat and os.name == "nt":
        subprocess.Popen(["cmd", "/c", str(bat), "--na-pasta"], cwd=str(para), close_fds=True)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
