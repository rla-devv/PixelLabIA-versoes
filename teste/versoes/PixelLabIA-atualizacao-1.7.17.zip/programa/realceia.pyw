"""Abre o Pixel Lab IA numa janela própria, como um programa comum.

Uso: dois cliques no atalho "Pixel Lab IA" (criado pelo "Instalar Pixel Lab IA.bat"), ou
     .venv\\Scripts\\pythonw.exe realceia.pyw [--navegador]
--navegador abre no navegador padrão em vez da janela própria. Sem o pywebview, ou se a janela
não abrir (por exemplo, sem o WebView2), o app abre no navegador sozinho.

O app (app.py) roda num processo à parte, só neste computador (127.0.0.1). Se ele sair com o
código 3 (atualização instalada), este lançador conclui a atualização e o abre de novo, já
com a versão nova. Se ele cair, abre de novo em 2 s, até 5 vezes em 10 minutos.

No modo navegador não há janela para fechar: o app fecha sozinho uns 5 minutos depois que a
página some (aba ou navegador fechados), se nada estiver rodando. Abrir o atalho de novo
enquanto ele está aberto só abre o navegador nele, sem criar outro.
"""

import json
import os
import re
import secrets
import socket
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
import webbrowser
from pathlib import Path, PureWindowsPath

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
# a pasta do app (com o .venv); desde a 1.5.0 o código fica na subpasta "programa"
BASE = ROOT.parent if ROOT.name == "programa" else ROOT
# versão deste lançador: o servidor só instala versões que pedem um lançador até esta
LANCADOR = "2"
# mesma pasta de dados usada pelo instalador (modelos compartilhados entre instalações)
if sys.platform == "win32" and os.environ.get("LOCALAPPDATA"):
    os.environ.setdefault("REALCE_DADOS", str(Path(os.environ["LOCALAPPDATA"]) / "RealceIA"))
sys.path.insert(0, str(ROOT))
# sem telemetria das bibliotecas de IA: vale para o app e para a instalação dos componentes, que
# recebem o ambiente deste processo
from realce import privacidade  # noqa: E402, F401

# sem console (pythonw), as mensagens vão para logs/pixel-lab-ia.log (passou de 256 KB, fica só o fim)
LOGS = ROOT / "logs"
LOGS.mkdir(exist_ok=True)
LOG_FILE = LOGS / "pixel-lab-ia.log"
(LOGS / "realceia.log").unlink(missing_ok=True)  # registro com o nome antigo do app
try:
    from realce.atualizacao import limitar_log
    for _nome in ("pixel-lab-ia.log", "servidor.log", "atualizacao.log"):
        limitar_log(LOGS / _nome)
except Exception:  # noqa: BLE001 - registro nunca impede o app de abrir
    pass
if sys.stdout is None or sys.executable.lower().endswith("pythonw.exe"):
    sys.stdout = sys.stderr = open(LOG_FILE, "a", encoding="utf-8", buffering=1)
    print(time.strftime("\n==== %Y-%m-%d %H:%M:%S ===="), flush=True)

# mesmas cores do app (tema escuro do padrão RLA.dev), para a abertura não "piscar" outra identidade
BG = "#0a1120"
PAGE = """<!doctype html><html><head><meta charset="utf-8"><style>
body{{margin:0;height:100vh;display:flex;align-items:center;justify-content:center;
font-family:"Segoe UI",system-ui,sans-serif;color:#e6ecf5;
background:radial-gradient(1100px 420px at 15% -120px,#12264a,transparent 70%),#0a1120}}
.box{{text-align:center;max-width:560px;padding:24px}}
.logo{{width:64px;height:64px;margin:0 auto 18px;border-radius:16px;background:#58c4ff;
color:#05162e;display:flex;align-items:center;justify-content:center}}
.logo svg{{width:36px;height:36px}}
.icon{{display:block;margin:0 auto 14px}}
h1{{font-size:38px;margin:0 0 6px;letter-spacing:-.02em}}
p{{font-size:16px;line-height:1.55;color:#93a3bb}}
.tag{{margin:0;font-size:17px}}
.spin{{width:36px;height:36px;margin:26px auto 14px;border:3px solid #24324d;
border-top-color:#58c4ff;border-radius:50%;animation:s .9s linear infinite}}
@keyframes s{{to{{transform:rotate(360deg)}}}}
.err{{color:#e6ecf5}}
code{{background:#182540;border:1px solid #24324d;color:#e6ecf5;padding:2px 6px;
border-radius:6px;word-break:break-all}}
</style></head><body><div class="box">{body}</div></body></html>"""

TITLE = "Pixel Lab IA"
def _logo() -> str:
    """O ícone do app (o mesmo do atalho); sem o arquivo, a lupa desenhada."""
    png = ROOT / "assets" / "pixel-lab-ia-icone-128.png"
    if png.exists():
        import base64

        data = base64.b64encode(png.read_bytes()).decode()
        return f'<img class="icon" src="data:image/png;base64,{data}" alt="" width="76" height="76">'
    return ('<div class="logo"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" '
            'stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" '
            'r="7"/><path d="m21 21-4.3-4.3"/><path d="M11 8v6M8 11h6"/></svg></div>')


LOGO = _logo()
HEADER = LOGO + "<h1>Pixel Lab IA</h1><p class='tag'>Melhoria de fotos e vídeos e leitura de placas diretamente no seu computador.</p>"

LOADING = PAGE.format(body=HEADER + "<div class='spin'></div>"
                           "<p>Carregando os modelos de IA…<br>"
                           "A primeira abertura pode levar até 1 minuto.</p>")


def error_page(msg: str) -> str:
    return PAGE.format(body=HEADER + f"<p class='err'>Não foi possível iniciar o app.</p>"
                            f"<p><code>{msg}</code></p>"
                            f"<p>Detalhes em <code>{LOGS / 'servidor.log'}</code></p>")


def message_page(msg: str) -> str:
    return PAGE.format(body=HEADER + f"<div class='spin'></div><p>{msg}</p>")


SAIR_PARA_ATUALIZAR = 3
FECHOU_PAGINA = 4  # modo navegador: a página foi fechada e o app fechou sozinho (não reabre)
NAVEGADOR = BASE / ".runtime" / "navegador.json"  # o app aberto no modo navegador (porta e senha)
MAX_QUEDAS, JANELA_QUEDAS = 5, 600  # até 5 quedas em 10 minutos


def mensagem_depois(r) -> str:
    """O que mostrar ao reabrir depois de uma atualização (ou de uma volta de versão)."""
    if not r:
        return "Abrindo o Pixel Lab IA…"
    if r.get("falhou") and r.get("voltou"):
        return "A atualização não deu certo e o Pixel Lab IA voltou para a versão anterior.<br>Abrindo…"
    if r.get("falhou"):
        return ("Não foi possível instalar os componentes desta versão; o app vai tentar de novo na "
                "próxima abertura.<br>Abrindo…")
    if r.get("restaurada"):
        return "Abrindo a versão anterior…"
    return "Abrindo a versão nova…"


def free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


class Server:
    """O app num processo à parte, que pode ser reaberto sem fechar a janela."""

    def __init__(self, show, navegador=False):
        self.navegador = navegador  # modo navegador: o app fecha sozinho quando a página some
        self.port = free_port()  # a mesma porta em todas as reaberturas: a página só recarrega
        self.url = f"http://127.0.0.1:{self.port}"
        # senha da sessão: só esta janela usa o servidor (ver realce/chave.py)
        self.chave = secrets.token_urlsafe(32)
        # já no tema escuro desde o primeiro quadro
        self.entrada = f"{self.url}/?__theme=dark&chave={self.chave}"
        self.show = show          # show(html=None, url=None): atualiza a janela ou o navegador
        self.proc = None
        self.closing = False
        self.falls: list[float] = []

    def start(self) -> bool:
        py = sys.executable  # pythonw.exe no Windows: o servidor também roda sem janela preta
        try:  # o registro do servidor cresce a cada abertura: passou de 256 KB, fica só o fim
            from realce.atualizacao import limitar_log
            limitar_log(LOGS / "servidor.log")
        except Exception:  # noqa: BLE001
            pass
        log = open(LOGS / "servidor.log", "a", encoding="utf-8")
        log.write(time.strftime("\n==== %Y-%m-%d %H:%M:%S ====\n"))
        log.flush()
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        # procura o app a cada abertura: uma atualização pode ter mudado a pasta do código
        nova = BASE / "programa"
        prog = nova if (nova / "app.py").is_file() else BASE
        env = dict(os.environ, REALCE_LANCADOR=LANCADOR, REALCE_CHAVE=self.chave)
        if self.navegador:
            env["REALCE_NAVEGADOR"] = "1"
        self.proc = subprocess.Popen([py, str(prog / "app.py"), "--porta", str(self.port)],
                                     cwd=str(prog), env=env, stdout=log, stderr=subprocess.STDOUT,
                                     creationflags=flags)
        deadline = time.time() + 300  # a primeira abertura carrega bibliotecas pesadas
        while time.time() < deadline:
            if self.proc.poll() is not None:
                return False
            try:
                urllib.request.urlopen(self.url + "/api/saude", timeout=2)
                return True
            except OSError:
                time.sleep(0.4)
        return False

    def finish_update(self):
        """Bibliotecas e modelos novos pedidos pela atualização, com o app fechado."""
        from realce import atualizacao

        try:
            r = atualizacao.concluir_pendente(lambda m: self.show(html=message_page(m)))
        except Exception:  # noqa: BLE001 - o app abre mesmo assim
            traceback.print_exc()
            return "Abrindo o Pixel Lab IA…"
        return mensagem_depois(r)

    def run(self):
        """Abre o app e o mantém aberto até a janela fechar."""
        self.finish_update()  # se uma atualização ficou pela metade, conclui antes
        while not self.closing:
            if not self.start():
                code = self.proc.poll()
                if self.closing:
                    return
                if not self._may_retry():
                    self.show(html=error_page(f"o app parou ao abrir (código {code})."))
                    return
                time.sleep(2)
                continue
            self.show(url=self.entrada)
            code = self.proc.wait()
            if self.closing:
                return
            print("app saiu com código", code, flush=True)
            if code == FECHOU_PAGINA:
                return
            if code == SAIR_PARA_ATUALIZAR:
                self.show(html=message_page("Aplicando a atualização…"))
                self.show(html=message_page(self.finish_update()))
                continue
            if not self._may_retry():
                self.show(html=error_page(f"o app parou {MAX_QUEDAS} vezes em pouco tempo "
                                          f"(último código {code})."))
                return
            self.show(html=message_page("O app parou inesperadamente. Abrindo de novo…"))
            time.sleep(2)

    def _may_retry(self) -> bool:
        now = time.time()
        self.falls = [t for t in self.falls if now - t < JANELA_QUEDAS] + [now]
        return len(self.falls) <= MAX_QUEDAS

    def stop(self):
        self.closing = True
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(5)
            except subprocess.TimeoutExpired:
                self.proc.kill()


# navegadores que abrem numa janela nova e maximizada com --new-window --start-maximized
MAXIMIZA = ("msedge.exe", "chrome.exe", "brave.exe", "vivaldi.exe", "opera.exe")


def comando_maximizado(comando, url):
    """Monta, a partir do comando do navegador padrão no registro ("C:\\...\\chrome.exe" -- "%1"), a linha que abre
    o endereço numa janela nova e maximizada. None se não for um navegador que aceite isso."""
    m = re.match(r'\s*"([^"]+)"|\s*(\S+)', comando or "")
    exe = m and (m.group(1) or m.group(2))
    if not exe:
        return None
    caminho = PureWindowsPath(exe)
    nome = caminho.name.lower()
    # o Opera (e o Opera GX) costumam se registrar pelo launcher.exe da pasta deles
    opera = nome == "launcher.exe" and any(p.lower().startswith("opera") for p in caminho.parts[:-1])
    if nome not in MAXIMIZA and not opera:
        return None
    return [exe, "--new-window", "--start-maximized", url]


def abrir_maximizado(url) -> bool:
    """Abre no navegador padrão do Windows, numa janela nova e maximizada. False se não deu (usa o webbrowser)."""
    if sys.platform != "win32":
        return False
    try:
        import winreg
        chave = r"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoice"
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, chave) as k:
            progid = winreg.QueryValueEx(k, "ProgId")[0]
        comando = None
        for raiz, base in ((winreg.HKEY_CURRENT_USER, "Software\\Classes\\"), (winreg.HKEY_CLASSES_ROOT, "")):
            try:
                with winreg.OpenKey(raiz, base + progid + r"\shell\open\command") as k:
                    comando = winreg.QueryValueEx(k, "")[0]
                break
            except OSError:
                pass
        linha = comando_maximizado(comando, url)
        if not linha or not Path(linha[0]).is_file():
            return False
        subprocess.Popen(linha, close_fds=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return True
    except Exception as e:  # noqa: BLE001 - sem janela maximizada, abre do jeito comum
        print("navegador sem janela maximizada:", e, flush=True)
        return False


def abrir_no_navegador(url) -> None:
    if not abrir_maximizado(url):
        webbrowser.open(url)


def ja_aberto() -> str | None:
    """Endereço (com a senha) de um Pixel Lab IA já aberto no modo navegador, se ele responder."""
    try:
        dados = json.loads(NAVEGADOR.read_text(encoding="utf-8"))
        url = f"http://127.0.0.1:{int(dados['porta'])}"
        with urllib.request.urlopen(url + "/api/saude", timeout=2) as r:
            if not json.loads(r.read()).get("ok"):
                return None
        return f"{url}/?__theme=dark&chave={dados['chave']}"
    except Exception:  # noqa: BLE001 - não há outro aberto
        return None


def modo_navegador() -> None:
    """Abre o app no navegador padrão (janela nova e maximizada, quando dá)."""
    entrada = ja_aberto()
    if entrada:  # já está aberto: só mostra de novo, sem criar outro
        print("já aberto; abrindo no navegador:", entrada.split("?")[0], flush=True)
        abrir_no_navegador(entrada)
        return
    opened = []

    def show(html=None, url=None):
        if html:
            print(html.split("<p>")[-1].split("</p>")[0].replace("<br>", " "), flush=True)
        if url and not opened:  # nas reaberturas a própria página recarrega
            opened.append(url)
            abrir_no_navegador(url)
            print("Pixel Lab IA em", url.split("?")[0], flush=True)

    server = Server(show, navegador=True)
    try:
        NAVEGADOR.parent.mkdir(exist_ok=True)
        NAVEGADOR.write_text(json.dumps({"porta": server.port, "chave": server.chave}), encoding="utf-8")
    except OSError:
        pass
    try:
        # sem janela para fechar: o app fecha sozinho quando a página some (ver app.py, presença)
        server.run()
    except KeyboardInterrupt:
        server.stop()
    finally:
        try:
            dados = json.loads(NAVEGADOR.read_text(encoding="utf-8"))
            if dados.get("porta") == server.port:
                NAVEGADOR.unlink()
        except (OSError, ValueError):
            pass


def main():
    # instalação sempre em C:\rla-lab\Pixel Lab IA (padrão RLA.dev): numa pasta em outro lugar, um
    # ajudante de fora da pasta a move e abre o app de lá (realce/mudanca.py); este lançador fecha
    try:
        from realce import mudanca

        if mudanca.precisa_mudar(BASE) and not ja_aberto() and mudanca.iniciar(BASE, sys.argv[1:]):
            return
    except Exception:  # noqa: BLE001 - a mudança nunca impede o app de abrir
        traceback.print_exc()

    use_browser = "--navegador" in sys.argv
    webview = None
    if not use_browser:
        try:
            import webview
        except ImportError:
            print("pywebview não instalado; abrindo no navegador.", flush=True)

    if webview is None:
        modo_navegador()
        return

    from realce import atalhos

    atalhos.identificar_processo()  # barra de tarefas: nome e ícone do app, não do Python
    # (os atalhos são conferidos pelo próprio app ao abrir: app.py, serve)
    opcoes = dict(html=LOADING, width=1400, height=900, min_size=(900, 600), text_select=True,
                  background_color=BG)
    try:
        webview.settings["ALLOW_DOWNLOADS"] = True  # permite baixar os resultados
        try:  # sempre abre maximizada
            window = webview.create_window(TITLE, maximized=True, **opcoes)
        except TypeError:  # pywebview antigo, sem a opção
            window = webview.create_window(TITLE, **opcoes)
    except Exception:  # noqa: BLE001 - sem a janela, abre no navegador
        traceback.print_exc()
        print("a janela não abriu; abrindo no navegador.", flush=True)
        modo_navegador()
        return

    def maximizar():  # reforço: maximiza de novo quando a janela aparece
        try:
            window.maximize()
        except Exception:  # noqa: BLE001 - nunca impede a janela de abrir
            traceback.print_exc()

    try:
        window.events.shown += maximizar
    except Exception:  # noqa: BLE001
        traceback.print_exc()

    def show(html=None, url=None):
        if url:
            window.load_url(url)
        elif html:
            window.load_html(html)

    server = Server(show)
    window.events.closed += server.stop

    def worker():
        try:
            server.run()
        except Exception as e:  # noqa: BLE001 - mostrar qualquer falha ao usuário
            traceback.print_exc()
            window.load_html(error_page(str(e)[:300]))

    begin = lambda: threading.Thread(target=worker, daemon=True).start()  # noqa: E731
    icon = ROOT / "assets" / "pixel-lab-ia.ico"
    try:
        try:
            webview.start(begin, icon=str(icon) if icon.exists() else None)
        except TypeError:  # pywebview antigo, sem ícone próprio
            webview.start(begin)
    except Exception:  # noqa: BLE001 - ex.: sem o WebView2: abre no navegador
        traceback.print_exc()
        print("a janela não abriu; abrindo no navegador.", flush=True)
        server.stop()
        modo_navegador()
        os._exit(0)
    # janela fechada: encerra tudo, inclusive o servidor
    server.stop()
    os._exit(0)


if __name__ == "__main__":
    main()
