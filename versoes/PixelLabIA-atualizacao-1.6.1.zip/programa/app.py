"""Pixel Lab IA — Melhoria de imagens e vídeos, rostos e placas.

Rode com:  python realceia.pyw  (ou python app.py, no navegador)
"""

import functools
import os
import sys
from pathlib import Path
import tempfile
import threading
from html import escape

import cv2
import gradio as gr
import numpy as np

from realce import __version__, atualizacao, faces, identity, people, plates, vehicle, video
from realce.faithful import (deinterlace, faithful_enhance, is_grayscale, looks_interlaced,
                             moire_index, remove_moire, to_gray)
from realce.models import gpu_info
from realce.upscale import run_model, upscale
from ui import layout, theme

NAME = "Pixel Lab IA"
TAGLINE = "Melhoria de fotos e vídeos e leitura de placas"

# opções mostradas ao usuário -> valores internos
MODES = {
    "Fiel: não inventa detalhes (recomendado)": "fiel",
    "IA generativa: mais nítido, pode inventar texturas": "gen",
}
SCALES = {"Não aumentar": 1, "2 vezes": 2, "4 vezes": 4}
VIDEO_SCALES = {"2 vezes": 2, "4 vezes": 4}


def aviso(msg: str, titulo: str = "Falta um passo") -> gr.Error:
    """Mensagem para a pessoa (sem o título "Error" em inglês do Gradio)."""
    return gr.Error(msg, title=titulo, print_exception=False)


# processamentos em andamento: a atualização só instala com o app parado
_ocupado = 0
_ocupado_trava = threading.Lock()


def ocupa(fn):
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        global _ocupado
        with _ocupado_trava:
            _ocupado += 1
        try:
            return fn(*args, **kwargs)
        finally:
            with _ocupado_trava:
                _ocupado -= 1
    return wrapper


def rgb2bgr(img):
    return cv2.cvtColor(img, cv2.COLOR_RGB2BGR)


def bgr2rgb(img):
    return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)


def save_png(img_bgr, name="pixel-lab-ia"):
    f = tempfile.NamedTemporaryFile(suffix=".png", delete=False, prefix=f"{name}-")
    cv2.imwrite(f.name, img_bgr)
    return f.name


def note(html: str, kind: str = "") -> str:
    return f'<div class="rl-result {kind}">{html}</div>'


# ---------------- Melhorar foto ----------------

@ocupa
def improve_photo(img, mode_label, scale_label, do_faces, deblur, fidelity, deint=False,
                  demoire=False, progress=gr.Progress()):
    if img is None:
        raise aviso("Envie ou cole uma foto primeiro.")
    mode, scale = MODES[mode_label], SCALES[scale_label]
    if scale == 1 and not deblur and not do_faces and not deint and not demoire:
        raise aviso("Com <b>Não aumentar</b>, marque <b>Melhorar rostos com IA</b> ou uma opção em "
                    "<b>Mais opções</b> (borrão, listras ou moiré). Ou escolha aumentar 2 ou 4 vezes.",
                    "Escolha o que melhorar")
    src = rgb2bgr(img)
    gray = is_grayscale(src)
    moire = moire_index(src) > 0.1
    # o moiré também parece "listras": só sugere tirar listras quando não é foto de tela
    striped = not moire and looks_interlaced(src)
    if demoire:
        src = remove_moire(src)
    if gray:
        src = to_gray(src)  # tira o tom de cor da tela e evita manchas coloridas no resultado
    if deint:
        src = deinterlace(src)

    progress(0.1, desc="Melhorando a foto…")
    if mode == "fiel":
        out = faithful_enhance(src, "realesrnet-x4plus", scale, deblur)
    else:
        base = run_model(src, "restormer-deblur", tile=384, pad=32) if deblur else src
        out = upscale(base, "realesrgan-x4plus", scale) if scale > 1 else base

    if gray:
        out = to_gray(out)
    if out.shape[:2] == src.shape[:2]:
        lines = [f"Foto de {src.shape[1]}×{src.shape[0]} px, mantida no mesmo tamanho. (O quadro "
                 "de comparação amplia a foto na tela só para ficar mais fácil de ver.)"]
    else:
        lines = [f"Foto de {src.shape[1]}×{src.shape[0]} px → {out.shape[1]}×{out.shape[0]} px."]
    if gray:
        lines.append("Foto em preto e branco (câmera noturna): o resultado também sai em preto e "
                     "branco, sem manchas de cor.")
    if moire and not demoire:
        lines.append("Esta foto parece ter sido tirada de uma <b>tela</b> (padrão de ondas/grade). "
                     "Em <b>Mais opções</b>, marque <b>Remover moiré</b> e melhore de novo.")
    if striped and not deint:
        lines.append("Esta foto parece ter <b>listras horizontais</b> de câmera entrelaçada. Em "
                     "<b>Mais opções</b>, marque <b>Remover listras horizontais</b> e melhore de novo.")
    if do_faces:
        progress(0.6, desc="Melhorando rostos…")
        fs = faces.plausible_faces(src, faces.detect_faces(src))
        if not fs:
            lines.append("Nenhum rosto encontrado na foto.")
        else:
            k = out.shape[1] / src.shape[1]
            scaled = [faces.Face(f.box, f.landmarks * k, f.score) for f in fs]
            out, _ = faces.restore_faces(out, "codeformer", fidelity, scaled)
            # confere o quanto cada rosto continua parecido com o original
            for i, f in enumerate(fs, 1):
                sim = float(identity.embed(src, f.landmarks) @ identity.embed(out, f.landmarks * k))
                small = (" (rosto pequeno: a conferência é menos confiável)"
                         if max(f.box[2:]) < 40 else "")
                lines.append(f"Rosto {i}: semelhança com o original <b>{sim:.2f}</b>, "
                             f"{identity.verdict(sim)}{small}.")
    before = cv2.resize(src, (out.shape[1], out.shape[0]), interpolation=cv2.INTER_CUBIC)
    return ((bgr2rgb(before), bgr2rgb(out)), note("<br>".join(lines)),
            gr.File(save_png(out, "foto-melhorada"), visible=True))


# ---------------- Ler placa (foto) ----------------

def _level(share: float) -> tuple[str, str]:
    if share >= 0.85:
        return "Confiança alta", "ok"
    if share >= 0.5:
        return "Confiança média", "mid"
    return "Confiança baixa", "low"


ILLEGIBLE = ("Não há detalhe suficiente na imagem para ler esta placa: ela tem poucos pixels "
             "ou está muito borrada. Nenhuma ferramenta consegue recuperar o que não foi "
             "registrado; uma IA que \"lesse\" esta placa estaria inventando.")


def plate_card(read: plates.PlateRead, title: str, extra: str = "", tip: str = "") -> str:
    best = read.best
    if read.illegible:
        return (f"<div class='rl-plate low'><div class='rl-plate-top'><span>{escape(title)}</span>"
                f"<span class='rl-badge'>Sem leitura possível</span></div>"
                f"<div class='rl-plate-text'>Ilegível</div><div class='rl-alt'>{ILLEGIBLE}</div>"
                f"{tip}{extra}</div>")
    label, kind = _level(best.share)
    alts = [c for c in read.candidates[1:4] if c.share >= 0.01]
    alt_html = ("<div class='rl-alt'>Outras possibilidades: "
                + ", ".join(f"<code>{c.text}</code> {c.share:.0%}" for c in alts)
                + "</div>") if alts else ""
    masked = read.masked()
    if read.mercosul:
        extra = ("<div class='rl-alt'>Faixa azul do Mercosul detectada: a 5ª posição foi lida "
                 "como letra.</div>") + extra
    # o número grande mostra "?" onde a leitura não é confiável, para não parecer certeza
    unsure = (f"<div class='rl-alt'>? = caractere incerto. Leitura mais provável: "
              f"<code>{best.text}</code> {best.share:.0%}</div>" if "?" in masked else "")
    return (f"<div class='rl-plate {kind}'><div class='rl-plate-top'><span>{escape(title)}</span>"
            f"<span class='rl-badge'>{label} · {best.share:.0%}</span></div>"
            f"<div class='rl-plate-text'>{masked}</div>{unsure}{alt_html}{extra}</div>")


def vehicle_line(v) -> str:
    """Linha "Veículo: ..." do cartão da placa."""
    if v is None:
        return ""
    model = v.model_text()
    return (f"<div class='rl-veh'><b>Veículo:</b> {escape(v.summary())}"
            + (f" · {escape(model)}" if model else "")
            + ("<small>Modelo sugerido por semelhança visual: confira na imagem.</small>"
               if model else "") + "</div>")


@ocupa
def read_plate_photo(img, br, do_vehicle=True, progress=gr.Progress()):
    if img is None:
        raise aviso("Envie ou cole uma foto primeiro.")
    progress(0.2, desc="Procurando e lendo placas…")
    src = rgb2bgr(img)
    res = plates.read_plates(src, variants=True, br=br, zoom=True)
    if not res:
        msg = note("Nenhuma placa encontrada. Tente uma foto em que a placa apareça maior ou "
                   "mais nítida.", "low")
        if do_vehicle:  # mesmo sem placa, diz que veículos aparecem na foto
            progress(0.7, desc="Identificando veículos…")
            vs = sorted(vehicle.detect_vehicles(src),
                        key=lambda v: -(v.box[2] - v.box[0]) * (v.box[3] - v.box[1]))[:3]
            msg += "".join(f"<div class='rl-plate'>{vehicle_line(vehicle.describe(src, v))}</div>"
                           for v in vs)
        return bgr2rgb(src), msg
    cards = []
    video_tip = ("<div class='rl-alt'>Se a imagem veio de um vídeo, use <b>Placas no vídeo</b>: "
                 "combinar vários quadros às vezes recupera a leitura.</div>")
    for i, p in enumerate(res, 1):
        extra = ""
        illegible = p.fused.illegible
        if p.angle and not illegible:
            extra += (f"<div class='rl-alt'>A placa estava inclinada e foi endireitada "
                      f"automaticamente ({abs(p.angle)}°).</div>")
        if br and not illegible and p.fused.br_fit is not None and p.fused.br_fit < 0.3:
            extra += ("<div class='rl-alt'>Não parece uma placa brasileira. Se for de outro país, "
                      "desmarque <b>Placa brasileira</b> e leia de novo.</div>")
        if do_vehicle:
            progress(0.7, desc="Identificando o veículo…")
            extra = vehicle_line(vehicle.identify([(src, p.box)])) + extra
        cards.append(plate_card(p.fused, f"Placa {i}", extra, video_tip if illegible else ""))
    return bgr2rgb(plates.draw_plates(src, res)), "".join(cards)


# ---------------- Melhorar vídeo ----------------

@ocupa
def _trecho(ini, fim) -> tuple[float, float | None]:
    ini, fim = float(ini or 0), float(fim or 0)
    if ini < 0 or fim < 0:
        raise aviso("Início e fim não podem ser negativos.")
    if fim and fim <= ini:
        raise aviso("O fim do trecho precisa ser depois do início.")
    return ini, (fim or None)


def improve_video(path, scale_label, ini, fim, progress=gr.Progress()):
    if not path:
        raise aviso("Envie um vídeo primeiro.")
    start, end = _trecho(ini, fim)
    try:
        return video.process_video(path, "realesr-general-x4v3", VIDEO_SCALES[scale_label],
                                   start, end, progress)
    except ValueError as e:
        raise aviso(str(e), "Não deu certo")


# ---------------- Placas no vídeo ----------------

def _sem_placas(seen, start, end) -> str:
    """Explica por que nenhuma placa foi encontrada e o que tentar."""
    trecho = "no vídeo" if not start and not end else \
        f"no trecho de {video.fmt_time(start)} a {video.fmt_time(end) if end else 'o fim'}"
    if seen:
        vistos = "; ".join(f"{s.kind} de {video.fmt_time(s.start)} a {video.fmt_time(s.end)}"
                           for s in sorted(seen, key=lambda s: s.start))
        motivo = (f"Apareceu veículo ({vistos}), mas nenhuma placa legível, mesmo ampliando a "
                  "imagem de cada veículo. A placa pode estar pequena demais, escura, de lado ou "
                  "escondida.")
    else:
        motivo = "Não apareceu nenhum veículo nem placa."
    dicas = ("<ul class='rl-tips'><li>Se o veículo passa mais perto da câmera em algum momento, "
             "marque só esse trecho e procure de novo.</li>"
             "<li>Use o vídeo original da câmera: vídeos enviados pelo WhatsApp perdem muita "
             "definição.</li></ul>")
    return note(f"<b>Nenhuma placa encontrada {trecho}.</b> {motivo}{dicas}", "low")


@ocupa
def find_video_plates(path, br, ini, fim, do_vehicle=True, progress=gr.Progress()):
    if not path:
        raise aviso("Envie um vídeo primeiro.")
    start, end = _trecho(ini, fim)
    try:
        seen = []
        found = video.scan_plates(path, every=3, br=br, start=start, end=end,
                                  progress=progress, vehicles=do_vehicle, seen=seen)
    except ValueError as e:
        raise aviso(str(e), "Não deu certo")
    if not found:
        return (_sem_placas(seen, start, end),
                gr.Dropdown(choices=[], value=None, visible=False), [], gr.Button(interactive=False, visible=False))
    rows, choices, state = [], [], []
    for i, f in enumerate(found, 1):
        best = f.read.best
        text = best.text if best else "?"
        if not f.read.illegible:
            conf = f"{_level(best.share)[0]} · {best.share:.0%}"
        else:
            text, conf = "ilegível", "Não deu para ler rápido: use Ler com mais precisão"
        when = f"{video.fmt_time(f.start)} a {video.fmt_time(f.end)}"
        v = f.vehicle
        veh = escape(v.summary()) if v else "—"
        if v and v.models and v.models[0][1] >= 0.25:
            veh += f"<br><small>{escape(v.models[0][0])}?</small>"
        rows.append(f"<tr><td>{i}</td><td><code>{text}</code></td><td>{conf}</td><td>{veh}</td>"
                    f"<td>{when}</td></tr>")
        choices.append((f"{i}. {text} ({when})", i - 1))
        state.append({"t": f.t_best, "box": list(f.box_best), "read": f.read, "vehicle": f.vehicle})
    table = ("<table class='rl-table'><thead><tr><th>#</th><th>Placa</th><th>Leitura rápida</th>"
             "<th>Veículo</th><th>Aparece em</th></tr></thead><tbody>" + "".join(rows) + "</tbody></table>"
             "<p class='rl-hint'>Escolha uma placa abaixo e clique em <b>Ler com mais precisão</b> "
             "para combinar vários quadros.</p>")
    return table, gr.Dropdown(choices=choices, value=0, visible=True), state, gr.Button(interactive=True, visible=True)


@ocupa
def precise_video_plate(path, choice, br, found, progress=gr.Progress()):
    if not path or not found or choice is None:
        raise aviso("Primeiro clique em Procurar placas.")
    item = found[int(choice)]
    progress(0.2, desc="Combinando vários quadros…")
    try:
        r = plates.read_plate_video(path, item["t"], near_box=tuple(item["box"]), br=br)
    except ValueError as e:
        raise aviso(str(e), "Não deu certo")
    f = r.fusion
    # junta a leitura precisa com a leitura rápida de todos os quadros em que a placa apareceu:
    # uma costuma acertar onde a outra erra
    final = plates.fuse_reads([item["read"], r.final], br, top=2) if item.get("read") else r.final
    legible = not final.illegible
    extra = (f"<div class='rl-alt'>A placa estava inclinada e foi endireitada automaticamente "
             f"({abs(r.angle)}°).</div>" if r.angle and legible else "")
    extra = vehicle_line(item.get("vehicle")) + extra
    card = plate_card(final, f"Placa {int(choice) + 1}, combinando vários quadros", extra)
    return (card, gr.Image(bgr2rgb(side_by_side(*r.view, f.used)), visible=True),
            gr.File(save_png(f.fused, "placa-combinada"), visible=True))


# ---------------- Pessoas no vídeo ----------------

@ocupa
def find_video_people(path, ini, fim, progress=gr.Progress()):
    if not path:
        raise aviso("Envie um vídeo primeiro.")
    start, end = _trecho(ini, fim)
    try:
        found = people.scan_people(path, every=3, start=start, end=end, progress=progress)
    except ValueError as e:
        raise aviso(str(e), "Não deu certo")
    if not found:
        return (note("Nenhuma pessoa encontrada.", "low"), gr.Gallery(value=[], visible=False),
                gr.Dropdown(choices=[], value=None, visible=False), [], gr.Button(interactive=False, visible=False))
    thumbs, choices = [], []
    for i, f in enumerate(found, 1):
        when = f"{video.fmt_time(f.start)} a {video.fmt_time(f.end)}"
        thumbs.append((bgr2rgb(f.thumb), f"{i}. {when}"))
        choices.append((f"Pessoa {i} ({when}, até {f.height} px de altura)", i - 1))
    small = min(f.height for f in found) < 200
    text = (f"<p>{len(found)} pessoa(s) encontrada(s). Escolha uma e clique em <b>Melhorar pessoa</b>."
            "</p>" + ("<p class='rl-hint'>Pessoas com menos de 200 px de altura têm o rosto com poucos "
                      "pixels: a combinação de quadros melhora roupa, boné e contorno, mas não traz "
                      "os traços do rosto.</p>" if small else ""))
    return (note(text), gr.Gallery(value=thumbs, visible=True), gr.Dropdown(choices=choices, value=0, visible=True),
            found, gr.Button(interactive=True, visible=True))


@ocupa
def enhance_video_person(path, choice, found, progress=gr.Progress()):
    if not path or not found or choice is None:
        raise aviso("Primeiro clique em Procurar pessoas.")
    r, t = people.enhance_best(path, found[int(choice)], progress)
    if r.used < 3:
        msg = note(f"Só {r.used} quadro(s) se alinharam (a pessoa se mexe ou vira muito). "
                   "O resultado fica quase igual a um quadro só.", "low")
    else:
        msg = note(f"Cabeça e tronco em {video.fmt_time(t)}, combinando {r.used} quadros do vídeo. "
                   "Nada foi inventado: o detalhe a mais vem dos próprios quadros.")
    up = lambda im: cv2.resize(im, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC) \
        if im.shape[0] < 300 else im
    return (msg, gr.Image(bgr2rgb(side_by_side(up(r.single), up(r.fused), r.used)), visible=True),
            gr.File(save_png(r.fused, "pessoa-combinada"), visible=True))


def side_by_side(single, fused, used: int):
    """Um quadro só e a imagem combinada lado a lado, com legenda, para comparar."""
    h = max(single.shape[0], fused.shape[0], 60)
    pad = lambda im: cv2.copyMakeBorder(im, 0, h - im.shape[0], 0, 0, cv2.BORDER_CONSTANT,
                                        value=(22, 43, 40))
    gap = np.full((h, 12, 3), (22, 43, 40), np.uint8)
    img = np.hstack([pad(single), gap, pad(fused)])
    bar = np.full((28, img.shape[1], 3), (22, 43, 40), np.uint8)
    for x, text in ((6, "Um quadro"), (single.shape[1] + 18, f"{used} quadros combinados")):
        cv2.putText(bar, text, (x, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (230, 241, 238), 1, cv2.LINE_AA)
    return np.vstack([bar, img])


# ---------------- interface ----------------

PASTE = " Também dá para colar com Ctrl+V uma imagem copiada ou um recorte da tela (Win+Shift+S)."

TRECHO = ("Para analisar só uma parte do vídeo: dê play e clique em Início aqui e Fim aqui na "
          "barra abaixo do vídeo, arraste as marcas da barra ou digite os segundos. Deixe o fim em "
          "0 para ir até o final do vídeo.")

# textos dos balões de ajuda (?), por elem_id
HELP = {
    "f_img": "Arraste uma foto para cá ou clique para escolher (JPG, PNG, WEBP…)." + PASTE,
    "f_mode": "Fiel: deixa a foto maior e mais limpa sem criar detalhes que não existem. "
              "IA generativa: fica mais nítida, mas pode inventar texturas, como pele e cabelo.",
    "f_scale": "Quantas vezes a largura e a altura da foto vão aumentar. Escolha Não aumentar "
               "para só melhorar rostos ou remover borrão.",
    "f_faces": "Recria os rostos com IA para deixá-los mais nítidos. O resultado mostra o quanto "
               "cada rosto continua parecido com o original (de 0 a 1; a partir de 0,80 está "
               "preservado).",
    "f_deblur": "Tenta desfazer o borrão de quando a câmera ou a pessoa se mexeu.",
    "f_deint": "Algumas câmeras de segurança gravam as linhas pares e ímpares em instantes "
               "diferentes, e quem está se mexendo aparece com listras horizontais (\"pente\"). "
               "Esta opção remove as listras. O app avisa quando a foto parece ter esse problema.",
    "f_moire": "Quem fotografa a tela do computador ou do celular costuma ver ondas e uma grade "
               "fina sobre a imagem (moiré). Esta opção apaga só esse padrão repetido. O app avisa "
               "quando a foto parece ter sido tirada de uma tela. Melhor ainda: use um print "
               "(Win+Shift+S) ou exporte o quadro do vídeo.",
    "f_fid": "Perto de 1: rosto mais parecido com o original. Perto de 0: mais bonito, porém "
             "mais inventado.",
    "f_out": "Arraste a barra do meio para comparar antes (esquerda) e depois (direita).",
    "p_img": "Envie uma foto em que a placa apareça. Quanto maior a placa na foto, melhor a "
             "leitura." + PASTE,
    "p_br": "Lê no formato brasileiro (Mercosul ABC1D23 ou antigo ABC1234). Desmarque para "
            "placas de outros países.",
    "p_veh": "Diz o tipo (carro, picape, furgão, moto…), a cor e o possível modelo do veículo. "
             "O modelo é sugerido por semelhança visual com uma lista de carros vendidos no "
             "Brasil: confira na imagem. Leva alguns segundos a mais.",
    "pv_veh": "Diz o tipo, a cor e o possível modelo de cada veículo com placa, usando alguns "
              "quadros do vídeo. O modelo é uma sugestão: confira. Desmarque para procurar mais "
              "rápido.",
    "v_in": "Envie o vídeo que você quer melhorar.",
    "v_scale": "Quantas vezes a largura e a altura do vídeo vão aumentar.",
    "pv_vid": "Envie o vídeo em que as placas aparecem.",
    "pv_br": "Lê no formato brasileiro. Desmarque para placas de outros países.",
    "pe_vid": "Envie o vídeo em que a pessoa aparece. Prefira o arquivo original da câmera: "
              "vídeos reenviados pelo WhatsApp perdem bastante qualidade.",
    "pe_pick": "Escolha a pessoa. O app testa alguns momentos em que ela aparece e usa o que "
               "permite combinar mais quadros.",
    "v_ini": TRECHO,
    "pv_ini": TRECHO,
    "pe_ini": TRECHO,
    "pv_pick": "Escolha uma das placas encontradas para ler combinando vários quadros do vídeo. "
               "Isso deixa a leitura bem mais confiável que a leitura rápida.",
}


def device_text() -> str:
    info = gpu_info()
    if info:
        return f"Processando com a placa de vídeo <b>{info[0]}</b> ({info[1]:.0f} GB)."
    from realce import aceleracao

    if "DmlExecutionProvider" in aceleracao.provedores():
        return ("Processando com o <b>processador (CPU)</b>; a busca e a leitura de placas usam "
                "a <b>placa de vídeo</b>. Vídeos levam mais tempo do que com uma placa NVIDIA.")
    return ("Processando com o <b>processador (CPU)</b>: tudo funciona, mas vídeos levam "
            "mais tempo.")


def trim_fields(prefix: str):
    """Início e fim do trecho (a barra de recorte abaixo do vídeo preenche estes campos)."""
    with gr.Row(elem_classes="rl-trim-fields"):
        ini = gr.Number(value=0, minimum=0, precision=1, label="Início do trecho (s)",
                        elem_id=f"{prefix}_ini")
        fim = gr.Number(value=0, minimum=0, precision=1, label="Fim do trecho (s) · 0 = até o final",
                        elem_id=f"{prefix}_fim")
    return ini, fim


def new_button():
    """"Nova análise": aparece depois de um resultado e limpa a ferramenta."""
    return gr.Button("Nova análise", variant="secondary", visible=False, elem_classes="rl-new")


def go_button(text, primary=True, **kw):
    return gr.Button(text, variant="primary" if primary else "secondary", elem_classes="rl-go",
                     **kw)


with gr.Blocks(title=f"{NAME} - {TAGLINE} diretamente no seu computador") as demo:
    gr.HTML(layout.header(NAME, TAGLINE, __version__))

    gr.HTML(layout.hero(device_text()))
    gr.HTML(layout.tool_nav())

    with gr.Tabs(elem_id="tools"):
        # ---------------- Melhorar foto ----------------
        with gr.Tab("Melhorar foto", id="foto"):
            gr.HTML(layout.tool_head(
                "Melhorar foto", "Deixa a foto maior e mais nítida. Se quiser, também melhora "
                "os rostos.",
                ["Envie ou cole (Ctrl+V) uma foto", "Escolha como melhorar",
                 "Clique em Melhorar foto"]))
            with gr.Row(equal_height=False):
                with gr.Column():
                    f_img = gr.Image(label="Foto", type="numpy", elem_id="f_img", height=300)
                    f_mode = gr.Radio(list(MODES), value=list(MODES)[0], label="Tipo de melhoria",
                                      elem_id="f_mode", elem_classes="rl-opts")
                    f_scale = gr.Radio(list(SCALES), value="2 vezes", label="Aumentar a foto",
                                       elem_id="f_scale")
                    f_faces = gr.Checkbox(label="Melhorar rostos com IA (pode deixar o rosto "
                                                "diferente)", elem_id="f_faces")
                    with gr.Accordion("Mais opções", open=False):
                        f_deblur = gr.Checkbox(label="Remover borrão de movimento",
                                               elem_id="f_deblur")
                        f_deint = gr.Checkbox(label="Remover listras horizontais (câmera "
                                                    "entrelaçada)", elem_id="f_deint")
                        f_moire = gr.Checkbox(label="Remover moiré (foto tirada da tela)",
                                              elem_id="f_moire")
                        f_fid = gr.Slider(0, 1, value=0.7, step=0.05,
                                          label="Fidelidade dos rostos", elem_id="f_fid")
                    f_btn = go_button("Melhorar foto")
                    f_new = new_button()
                with gr.Column():
                    f_out = gr.ImageSlider(label="Antes e depois", elem_id="f_out", height=420)
                    f_msg = gr.HTML()
                    f_file = gr.File(label="Baixar foto melhorada", height=90,
                                     elem_classes="rl-file", visible=False)
            # limpa a mensagem anterior e mostra o progresso só no quadro do resultado
            f_btn.click(lambda: ("", gr.File(visible=False)), None, [f_msg, f_file],
                        queue=False, show_progress="hidden").then(
                improve_photo, [f_img, f_mode, f_scale, f_faces, f_deblur, f_fid, f_deint, f_moire],
                [f_out, f_msg, f_file], show_progress_on=f_out).success(
                lambda: gr.Button(visible=True), None, f_new)
            f_new.click(lambda: (None, None, "", gr.File(value=None, visible=False),
                                 gr.Button(visible=False)),
                        None, [f_img, f_out, f_msg, f_file, f_new], queue=False, show_progress="hidden")

        # ---------------- Ler placa ----------------
        with gr.Tab("Ler placa", id="placas"):
            gr.HTML(layout.tool_head(
                "Ler placa", "Encontra as placas de veículos na foto, lê os caracteres e diz "
                "o tipo, a cor e o possível modelo do veículo.",
                ["Envie ou cole (Ctrl+V) uma foto do veículo", "Clique em Ler placa",
                 "Confira a confiança e as outras possibilidades"]))
            with gr.Row(equal_height=False):
                with gr.Column():
                    p_img = gr.Image(label="Foto do veículo", type="numpy", elem_id="p_img",
                                     height=300)
                    p_br = gr.Checkbox(value=True, label="Placa brasileira", elem_id="p_br")
                    p_veh = gr.Checkbox(value=True, label="Identificar o veículo (tipo, cor e modelo)",
                                        elem_id="p_veh")
                    p_btn = go_button("Ler placa")
                    p_new = new_button()
                with gr.Column():
                    p_out = gr.Image(label="Placas encontradas", height=300, elem_classes="rl-zoom")
                    p_cards = gr.HTML()
            p_btn.click(lambda: "", None, p_cards, queue=False, show_progress="hidden").then(
                read_plate_photo, [p_img, p_br, p_veh], [p_out, p_cards],
                show_progress_on=p_out).success(
                lambda: gr.Button(visible=True), None, p_new)
            p_new.click(lambda: (None, None, "", gr.Button(visible=False)), None,
                        [p_img, p_out, p_cards, p_new], queue=False, show_progress="hidden")

        # ---------------- Melhorar vídeo ----------------
        with gr.Tab("Melhorar vídeo", id="video"):
            gr.HTML(layout.tool_head(
                "Melhorar vídeo", "Aumenta a resolução de cada quadro do vídeo e mantém o áudio.",
                ["Envie o vídeo", "Escolha quanto aumentar", "Clique em Melhorar vídeo e baixe"],
                "Cada quadro é processado com IA, então demora: sem placa de vídeo NVIDIA, "
                "teste primeiro com um trecho de poucos segundos."))
            with gr.Row(equal_height=False):
                with gr.Column():
                    v_in = gr.Video(label="Vídeo", elem_id="v_in", height=280, sources=["upload"])
                    v_ini, v_fim = trim_fields("v")
                    v_scale = gr.Radio(list(VIDEO_SCALES), value="2 vezes",
                                       label="Aumentar o vídeo", elem_id="v_scale")
                    v_btn = go_button("Melhorar vídeo")
                    v_new = new_button()
                with gr.Column():
                    v_out = gr.Video(label="Vídeo melhorado", height=320)
            v_btn.click(improve_video, [v_in, v_scale, v_ini, v_fim], v_out).success(
                lambda: gr.Button(visible=True), None, v_new)
            v_new.click(lambda: (None, None, 0, 0, gr.Button(visible=False)), None,
                        [v_in, v_out, v_ini, v_fim, v_new], queue=False, show_progress="hidden")

        # ---------------- Placas no vídeo ----------------
        with gr.Tab("Placas no vídeo", id="placas-video"):
            gr.HTML(layout.tool_head(
                "Placas no vídeo", "Encontra as placas que aparecem no vídeo, inclusive inclinadas. "
                "Depois, lê a placa escolhida combinando vários quadros, o que deixa a leitura "
                "bem mais confiável.",
                ["Envie o vídeo e clique em Procurar placas", "Escolha uma placa da lista",
                 "Clique em Ler com mais precisão"]))
            pv_found = gr.State([])
            with gr.Row(equal_height=False):
                with gr.Column():
                    pv_vid = gr.Video(label="Vídeo", elem_id="pv_vid", height=280, sources=["upload"])
                    pv_ini, pv_fim = trim_fields("pv")
                    pv_br = gr.Checkbox(value=True, label="Placa brasileira", elem_id="pv_br")
                    pv_veh = gr.Checkbox(value=True,
                                         label="Identificar o veículo (tipo, cor e modelo)",
                                         elem_id="pv_veh")
                    pv_scan = go_button("Procurar placas")
                    pv_new = new_button()
                with gr.Column():
                    pv_list = gr.HTML(note("As placas encontradas aparecem aqui."))
                    pv_pick = gr.Dropdown(choices=[], label="Placa para ler com mais precisão",
                                          elem_id="pv_pick", visible=False)
                    pv_read = go_button("Ler com mais precisão", interactive=False, visible=False)
                    pv_card = gr.HTML()
                    pv_gal = gr.Image(label="Comparação", height=220, visible=False,
                                      elem_id="pv_view", elem_classes="rl-zoom")
                    pv_file = gr.File(label="Baixar imagem da placa combinada", height=90,
                                      elem_classes="rl-file", visible=False)
            pv_scan.click(find_video_plates, [pv_vid, pv_br, pv_ini, pv_fim, pv_veh],
                          [pv_list, pv_pick, pv_found, pv_read], show_progress_on=pv_list).success(
                lambda: gr.Button(visible=True), None, pv_new)
            pv_new.click(lambda: (None, 0, 0, note("As placas encontradas aparecem aqui."),
                                  gr.Dropdown(choices=[], value=None, visible=False), [],
                                  gr.Button(interactive=False, visible=False), "",
                                  gr.Image(value=None, visible=False),
                                  gr.File(value=None, visible=False), gr.Button(visible=False)),
                         None, [pv_vid, pv_ini, pv_fim, pv_list, pv_pick, pv_found, pv_read,
                                pv_card, pv_gal, pv_file, pv_new], queue=False, show_progress="hidden")
            pv_read.click(precise_video_plate, [pv_vid, pv_pick, pv_br, pv_found],
                          [pv_card, pv_gal, pv_file], show_progress_on=pv_card)

        # ---------------- Pessoas no vídeo ----------------
        with gr.Tab("Pessoas no vídeo", id="pessoas-video"):
            gr.HTML(layout.tool_head(
                "Pessoas no vídeo", "Encontra as pessoas que aparecem no vídeo e deixa a cabeça e o "
                "tronco mais nítidos combinando vários quadros. Nenhum detalhe é inventado.",
                ["Envie o vídeo e clique em Procurar pessoas", "Escolha uma pessoa",
                 "Clique em Melhorar pessoa e baixe a imagem"],
                "Se a pessoa estiver longe da câmera, o rosto continua sem traços: não existe "
                "ferramenta que recupere um rosto de poucos pixels sem inventá-lo."))
            pe_found = gr.State([])
            with gr.Row(equal_height=False):
                with gr.Column():
                    pe_vid = gr.Video(label="Vídeo", elem_id="pe_vid", height=280, sources=["upload"])
                    pe_ini, pe_fim = trim_fields("pe")
                    pe_scan = go_button("Procurar pessoas")
                    pe_new = new_button()
                with gr.Column():
                    pe_list = gr.HTML(note("As pessoas encontradas aparecem aqui."))
                    pe_gal = gr.Gallery(label="Pessoas encontradas", columns=4, height=200,
                                        visible=False, object_fit="contain", preview=False)
                    pe_pick = gr.Dropdown(choices=[], label="Pessoa para melhorar",
                                          elem_id="pe_pick", visible=False)
                    pe_go = go_button("Melhorar pessoa", interactive=False, visible=False)
                    pe_card = gr.HTML()
                    pe_view = gr.Image(label="Comparação", height=320, visible=False,
                                       elem_classes="rl-zoom")
                    pe_file = gr.File(label="Baixar imagem combinada", height=90,
                                      elem_classes="rl-file", visible=False)
            pe_scan.click(find_video_people, [pe_vid, pe_ini, pe_fim],
                          [pe_list, pe_gal, pe_pick, pe_found, pe_go], show_progress_on=pe_list).success(
                lambda: gr.Button(visible=True), None, pe_new)
            pe_new.click(lambda: (None, 0, 0, note("As pessoas encontradas aparecem aqui."),
                                  gr.Gallery(value=[], visible=False),
                                  gr.Dropdown(choices=[], value=None, visible=False), [],
                                  gr.Button(interactive=False, visible=False), "",
                                  gr.Image(value=None, visible=False),
                                  gr.File(value=None, visible=False), gr.Button(visible=False)),
                         None, [pe_vid, pe_ini, pe_fim, pe_list, pe_gal, pe_pick, pe_found, pe_go,
                                pe_card, pe_view, pe_file, pe_new], queue=False, show_progress="hidden")
            pe_go.click(enhance_video_person, [pe_vid, pe_pick, pe_found],
                        [pe_card, pe_view, pe_file], show_progress_on=pe_card)

    gr.HTML(layout.footer(NAME, __version__))


def launch_options() -> dict:
    """Tema, estilos e scripts da interface (usados por todas as formas de abrir o app)."""
    return dict(theme=theme.build_theme(), css=theme.css(), head=theme.head(HELP, __version__))


# ---------------- servidor: interface + atualização automática ----------------

SAIR_PARA_ATUALIZAR = 3  # o lançador (realceia.pyw) reabre o app quando ele sai com este código


def _sair_depois(codigo: int, segundos: float = 1.5):
    """Sai depois de responder à página (o lançador reabre com a versão nova)."""
    threading.Timer(segundos, lambda: os._exit(codigo)).start()


def create_app():
    from fastapi import FastAPI
    from fastapi.responses import JSONResponse

    api = FastAPI()

    @api.get("/api/saude")
    def saude():
        return {"ok": True, "versao": __version__}

    @api.get("/api/atualizacao")
    def consultar(forcar: int = 0):
        r = atualizacao.verificar(bool(forcar))
        r.pop("info", None)
        r["anterior"] = atualizacao.anterior()
        return r

    @api.get("/api/atualizacao/resultado")
    def resultado():
        # o que aconteceu na última atualização (mostrado uma vez, depois de reabrir)
        return atualizacao.novidade_local() or {}

    def _parado():
        if _ocupado:
            return JSONResponse({"erro": "Há um processamento em andamento. Espere terminar e "
                                         "clique em Atualizar agora de novo."}, status_code=409)
        return None

    @api.post("/api/atualizacao")
    def instalar():
        if (r := _parado()) is not None:
            return r
        try:
            res = atualizacao.instalar()
        except Exception as e:  # noqa: BLE001 - a página explica qualquer falha
            return JSONResponse({"erro": f"A atualização não foi instalada: {e} Nada foi "
                                         "alterado."}, status_code=500)
        if res["status"] == "instalada":
            _sair_depois(SAIR_PARA_ATUALIZAR)
        return res

    @api.post("/api/atualizacao/restaurar")
    def restaurar():
        if (r := _parado()) is not None:
            return r
        try:
            res = atualizacao.restaurar()
        except Exception as e:  # noqa: BLE001
            return JSONResponse({"erro": f"Não foi possível voltar: {e}"}, status_code=500)
        _sair_depois(SAIR_PARA_ATUALIZAR)
        return res

    demo.queue()
    icon = Path(__file__).resolve().parent / "assets" / "realceia-icone-128.png"
    return gr.mount_gradio_app(api, demo, path="/", server_name="127.0.0.1",
                               favicon_path=str(icon) if icon.exists() else None, **launch_options())


def serve(port: int):
    import uvicorn

    print(f"{NAME} {__version__} em http://127.0.0.1:{port}", flush=True)
    # atalhos com o nome e o ícone desta versão (logo depois de uma atualização, sem esperar o
    # app ser fechado e aberto de novo)
    from realce import atalhos

    threading.Thread(target=atalhos.atualizar_se_preciso, daemon=True).start()
    from realce import chave

    # só a janela do Pixel Lab IA (com a senha que o lançador sorteou) usa o servidor
    app = chave.proteger(create_app(), os.environ.get("REALCE_CHAVE"), port)
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning")


if __name__ == "__main__":
    # python app.py [--porta 7860]: o lançador usa a porta que escolheu
    port = int(sys.argv[sys.argv.index("--porta") + 1]) if "--porta" in sys.argv else 7860
    serve(port)
