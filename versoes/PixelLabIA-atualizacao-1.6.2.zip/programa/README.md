# Pixel Lab IA — Melhoria de imagens e vídeos, rostos e placas

App local que melhora imagens e vídeos com IA, restaura rostos e lê placas de veículos.

São 4 ferramentas:

| Ferramenta | O que faz | Modelos |
|---|---|---|
| **Melhorar foto** | aumenta e deixa a foto mais nítida; opcionalmente melhora rostos e confere o quanto cada rosto mudou | Fiel: Real-ESRNet (+ Restormer contra borrão) · IA generativa: Real-ESRGAN · rostos: CodeFormer, conferidos com ArcFace |
| **Ler placa** | lê placas na foto no formato brasileiro, com confiança e outras possibilidades; diz tipo, cor e possível modelo do veículo | YOLOv9 + fast-plate-ocr, 4 versões do recorte combinadas · veículo: Faster R-CNN (torchvision) + OpenCLIP ViT-L/14 |
| **Melhorar vídeo** | aumenta a resolução de cada quadro, mantendo o áudio | Real-ESRGAN general v3 |
| **Placas no vídeo** | encontra as placas do vídeo (e o veículo de cada uma) e lê a escolhida combinando vários quadros | detecção + rastreamento; fusão multiquadro com homografia |
| **Pessoas no vídeo** | encontra as pessoas do vídeo e deixa cabeça e tronco mais nítidos combinando vários quadros, sem inventar detalhes | detector de pessoas + rastreamento; fusão multiquadro afim |

## Instalação no Windows (recomendado)

1. Baixe o [`PixelLabIA.zip`](https://github.com/rla-devv/realceia-versoes/raw/main/PixelLabIA.zip)
   (3 KB, só o `instalar.bat`) e extraia onde quiser (por exemplo, `C:\Pixel Lab IA`). Evite pastas
   sincronizadas com OneDrive.
2. Dê dois cliques em **`instalar.bat`**. Se o Windows mostrar "O Windows protegeu o computador",
   clique em **Mais informações → Executar assim mesmo** (o aviso aparece para qualquer script
   baixado da internet). O instalador:
   - baixa a versão publicada mais nova do programa e confere o SHA-256 antes de usar;
   - o gerenciador de Python (`uv`) e os modelos de IA também têm o SHA-256 fixo no código:
     um arquivo diferente do testado é recusado;
   - baixa o Python 3.12 só para o Pixel Lab IA, sem mexer no resto do Windows;
   - detecta placa NVIDIA: com placa, instala o PyTorch com CUDA; sem placa, a versão para processador;
   - instala as bibliotecas e baixa os modelos (~3,2 GB);
   - cria o atalho **Pixel Lab IA** na Área de Trabalho e no Menu Iniciar.

   Na primeira vez em cada computador leva de 20 a 40 minutos (cerca de 6 GB). Se a internet cair,
   rode de novo: ele continua de onde parou.
3. No fim, o Pixel Lab IA abre sozinho e a tela preta da instalação fecha (se der erro, ela fica
   aberta com a mensagem). Depois, abra pelo atalho. O Pixel Lab IA abre como um programa comum; ao
   fechá-lo, tudo é encerrado.

Funciona nas duas situações:

| Computador | Modo | Observação |
|---|---|---|
| Sem placa de vídeo | CPU | tudo funciona; vídeos são mais lentos |
| NVIDIA GTX 1650 (4 GB) | GPU (CUDA 12.6) | usa precisão total (a série GTX 16 falha em meia precisão), mantém no máximo 2 modelos na GPU e reduz os blocos se faltar memória |

Para a GPU funcionar, o driver NVIDIA precisa ser recente (versão 528 ou mais nova). O instalador
avisa se a placa for encontrada mas não puder ser usada.

### Onde ficam os arquivos

| O quê | Onde | Tamanho |
|---|---|---|
| Programa (código, atalhos, logs) | a pasta onde você extraiu, ex.: `C:\Pixel Lab IA` | ~5 MB + ambiente `.venv` |
| Python, PyTorch, bibliotecas baixadas e modelos de IA | `%LOCALAPPDATA%\RealceIA` | ~6 GB |

Os downloads grandes ficam numa pasta fixa do usuário, compartilhada por qualquer pasta do
Pixel Lab IA no mesmo computador. Assim, reinstalar, atualizar ou extrair uma versão em outra pasta
reaproveita tudo o que já foi baixado. (Até a versão 1.0.0 eles ficavam dentro da pasta do app;
o instalador novo move esses arquivos para o lugar fixo na próxima vez que rodar.)

A pasta do app tem só quatro itens (as pastas técnicas `.venv` e `.runtime` ficam ocultas):
- `instalar.bat`: instala ou repara o Pixel Lab IA.
- `Pixel Lab IA.bat`: abre o app (mesmo que o atalho). `"Pixel Lab IA.bat" --navegador` abre no navegador.
- `LEIA-ME.txt`: guia curto de instalação e uso.
- `programa\`: o código do app (não precisa mexer). Os registros ficam em `programa\logs\pixel-lab-ia.log`.
- Para desinstalar, apague a pasta do app, a pasta `%LOCALAPPDATA%\RealceIA` e os atalhos.

## Instalação manual (Linux, Mac ou para desenvolver)

```bash
python -m venv .venv && source .venv/bin/activate
# PyTorch: com GPU NVIDIA use o comando de https://pytorch.org/get-started/locally/
pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu
pip install -r requirements.txt
python download_weights.py
python realceia.pyw          # abre como programa (ou: python app.py e abra http://127.0.0.1:7860)
```

## Ferramentas

A tela inicial pergunta **"O que você quer fazer?"** e mostra as ferramentas em dois grupos.
Cada opção tem um **?** ao lado que explica, em linguagem simples, o que ela faz. Todos os
arquivos são processados no seu computador; nenhum dado é enviado para a internet.

**Em todas as ferramentas**
- **Soltar arquivo em qualquer lugar**: arraste a foto ou o vídeo para qualquer ponto da página;
  ele vai para a ferramenta aberta. As fotos também aceitam colar com Ctrl+V um recorte da tela.
- **Ampliar o resultado**: clique na imagem do resultado para abrir em tela cheia. Clique de
  novo (ou use a roda do mouse, + e −) para ampliar e reduzir; arraste para mover; Esc fecha.
  Em *Melhorar foto*, os botões *Antes* e *Depois* alternam as duas versões no mesmo zoom.
- **Nova análise**: aparece depois de um resultado e deixa a ferramenta pronta para outro arquivo.

**Fotos**
- **Melhorar foto**: escolha *Fiel* (não inventa detalhes, recomendado) ou *IA generativa* (mais
  nítido, pode inventar texturas) e quanto aumentar. Marque *Melhorar rostos com IA* se quiser;
  o resultado diz o quanto cada rosto continua parecido com o original.
- **Ler placa**: mostra cada placa em destaque, com a confiança (alta, média ou baixa), `?` nos
  caracteres incertos e outras possibilidades. Placas inclinadas são endireitadas sozinhas
  (testado até ~65°). Quando não há detalhe suficiente, o resultado é **Ilegível**: o app não
  inventa caracteres.

- **Fotos em preto e branco** (câmera noturna/infravermelho) são detectadas sozinhas e o
  resultado também sai em preto e branco, sem manchas de cor. O app **não colore** essas fotos:
  a câmera infravermelha não registra cor, então qualquer cor (pele, roupa, carro) seria
  inventada; além disso, no infravermelho uma roupa escura pode aparecer clara.
- **Remover moiré** (em *Mais opções*): para fotos tiradas da tela do computador ou do celular.
  Apaga só as frequências do padrão repetido da tela; o app avisa quando detecta esse padrão.

**Vídeos**
- **Trecho para analisar**: abaixo do vídeo há uma barra para escolher só uma parte. Dê play e
  clique em *Início aqui* e *Fim aqui*, arraste as marcas da barra ou digite os segundos;
  *Vídeo inteiro* desfaz. Durante a análise, o vídeo acompanha o ponto que está sendo analisado.
- **Melhorar vídeo**: aumenta 2 ou 4 vezes, com o áudio do mesmo trecho. Para testar, escolha
  um trecho de poucos segundos.
- **Placas no vídeo**: *Procurar placas* lista as placas e quando aparecem, inclusive placas
  inclinadas (o quadro é analisado reto e girado ±45°); escolha uma e clique em *Ler com mais
  precisão* para combinar vários quadros. Sem trecho escolhido, procura no vídeo inteiro. Sem placa de
  vídeo, a busca leva cerca de 2 minutos por minuto de vídeo.
  Em cada placa, só as leituras mais nítidas contam (quadros estourados pelo farol ou borrados
  pesam pouco), e quando a faixa azul do Mercosul aparece, a 5ª posição é lida como letra.
- **Pessoas no vídeo**: *Procurar pessoas* mostra cada pessoa no quadro em que aparece maior e
  mais nítida; *Melhorar pessoa* testa alguns momentos dela e combina os quadros do que melhor
  se alinha. Melhora roupa, boné e contorno. Pessoas longe da câmera (rosto com menos de ~30 px)
  continuam sem traços no rosto.

O botão **Tema claro / Tema escuro** muda as cores e a escolha fica salva.

## Como ler os resultados

- **Semelhança dos rostos (ArcFace):** em *Melhorar foto*, compara cada rosto do resultado com o original, de 0 a 1.
  As faixas foram calibradas degradando uma foto nítida e comparando cada saída com a foto real:

  | Saída (rosto de 52 px, ampliado 4×) | Medidor | Semelhança com a foto nítida real |
  |---|---|---|
  | Fiel (SwinIR PSNR) | 0,89 | 0,84 |
  | CodeFormer, fidelidade 1,0 | 0,75 | 0,70 |
  | CodeFormer, fidelidade 0,5 | 0,61 | 0,60 |
  | CodeFormer, fidelidade 0,0 | 0,33 | 0,36 |
  | Pessoas diferentes | — | ~0,04 |

  Preservada ≥ 0,80 · alterada 0,55–0,80 · muito alterada < 0,55. Em rostos com menos de 40 px a
  própria medida perde confiabilidade.
- **Rostos (generativo):** a restauração *recria* o rosto a partir de um modelo treinado. Em rostos muito pequenos
  (menos de ~30 px) o resultado é quase todo inventado. O controle **Fidelidade** do CodeFormer
  equilibra nitidez e fidelidade: valores próximos de 1 ficam mais fiéis ao original.
  Não use para identificar pessoas.
- **Placas:** o OCR devolve a probabilidade de cada caractere em cada posição, e a leitura é
  escolhida já dentro do formato brasileiro (Mercosul `LLLNLNN` ou antiga `LLLNNNN`).
  - **Chance:** probabilidade da melhor leitura entre todas as placas brasileiras possíveis.
  - **Incertos (?):** caracteres com menos de 70% de chance.
  - **Alternativas:** as próximas candidatas, para buscar quando a melhor estiver errada.
  - **Parece placa BR:** quanto o OCR acredita que aquilo é uma placa brasileira de 7 caracteres.
    Se for baixo, provavelmente é estrangeira: desmarque "Placa brasileira".
  - **Verde** só quando a chance é ≥ 85%, todas as versões concordam e parece placa BR.
  Exemplo real: a placa tcheca `5AU 5341` no modo brasileiro sai como `?AU5341`, chance 22%,
  "parece placa BR" 0% (antes, a versão anterior mostrava `SAU5341` com 100%).
- **Placas no vídeo:** medido com `tools/eval_plates_video.py` (20 placas sintéticas por tamanho,
  15 quadros com ruído e compressão H.264):

  | Placa | Um quadro | Um quadro, 4 versões | Fusão multiquadro |
  |---|---|---|---|
  | 49×13 px | 90% | 90% | **100%** |
  | 40×11 px | 15% | 35% | **45%** (certa entre as 3 primeiras: 70%; caracteres: 91%) |
  | 35×9 px | 0% | 0% | 0% (caracteres: ~40%) |

  Abaixo de ~10 px de altura nenhuma técnica lê a placa inteira. As placas sintéticas usam uma
  fonte parecida, não a oficial; teste com vídeos reais para saber o desempenho no seu caso.

- **Rostos pequenos:** testamos o PMRF (ICLR 2025), feito para alterar o mínimo o rosto. Em 4
  fotos de câmera de segurança a semelhança com o original ficou entre 0,51 e 0,69, contra 0,40 a
  0,75 do CodeFormer e 0,82 do modo Fiel com *Remover listras*; num rosto de ~8 px de um vídeo,
  ele inventou barba e dentes. Por isso não foi incluído: ele baixaria mais 900 MB e levaria ~2 min
  por rosto sem placa de vídeo, sem ganho real.

- **Veículo:** tipo (carro, picape, furgão/van, caminhão, ônibus, moto), cor e **possível
  modelo**, comparando a imagem com uma lista de ~90 modelos vendidos no Brasil (OpenCLIP, sem
  treino específico). Em fotos de referência acertou o modelo em 15 de 19 casos (17 de 19 entre
  as 3 primeiras opções); em câmeras de segurança o acerto é menor. Quando nenhum modelo se
  destaca, aparece "modelo incerto". Em vídeo, o resultado combina 3 quadros de cada veículo.
- **Ilegível:** aparece quando menos de 3 caracteres da placa são confiáveis.

## Desempenho (medido em CPU de 4 núcleos, sem GPU)

| Operação | Tempo |
|---|---|
| Upscale x4 rápido, 548×342 | ~0,3 s |
| Upscale x4 qualidade, 548×342 | ~7 s |
| Restauração de 1 rosto (CodeFormer / GFPGAN) | ~8 s / ~5 s |
| Ler placa (4 versões), 1 foto | ~3 s |
| Melhorar vídeo, 2 s (30 quadros), 2× | ~10 s |

Com uma GPU NVIDIA, esses tempos devem cair bastante.

No Windows, a detecção e a leitura de placas (e o medidor de rostos) usam qualquer placa de vídeo,
Intel, AMD ou NVIDIA, pelo DirectML (`onnxruntime-directml`). Se a placa não estiver disponível ou
der erro, esses modelos voltam sozinhos para o processador, com o mesmo resultado
(`realce/aceleracao.py`; `REALCE_SEM_GPU=1` força o processador). Os modelos em PyTorch (melhoria
de imagem e detector de veículos) continuam usando só NVIDIA (CUDA) ou o processador.

## Estrutura

```
instalar.bat           instalador para Windows (Python, PyTorch CPU/CUDA, modelos, atalhos)
Pixel Lab IA.bat          abre o app no Windows
LEIA-ME.txt            guia curto para quem usa
                       (no pacote só esses três ficam na raiz; o resto vai para programa/)
realceia.pyw         abre a interface como um programa comum (pywebview)
app.py                 interface: as 5 ferramentas e os textos de ajuda (?)
ui/                    identidade visual: tema, estilos, cabeçalho, cartões e balões de ajuda
download_weights.py    baixa os pesos para weights/
realce/models.py       carregamento dos modelos e escolha do dispositivo (CUDA > MPS > CPU)
realce/upscale.py      super-resolução em blocos
realce/faces.py        detecção, alinhamento e restauração de rostos (generativa)
realce/faithful.py     modo fiel: Restormer + SR PSNR + nitidez clássica
realce/identity.py     medidor de identidade (ArcFace)
realce/multiframe.py   fusão multiquadro (usada em Placas e Pessoas no vídeo)
realce/people.py       pessoas no vídeo: detecção, rastreamento e fusão de cabeça e tronco
realce/plates.py       detecção, OCR com probabilidades, leitura no formato BR, placa em vídeo
realce/video.py        melhorar vídeo e procurar placas no vídeo
realce/vehicle.py      tipo, cor e possível modelo do veículo
realce/atualizacao.py  atualização automática (consulta, confere, troca arquivos, restaura)
empacotar.py           gera os pacotes de uma versão em dist/
publicar.py            publica a versão no repositório público de versões
tools/synth_plates.py  gera placas brasileiras sintéticas e degradações
tools/eval_plates_video.py  mede o acerto de cada método de leitura em vídeo
realce/atalhos.py      atalhos do Windows (nome, ícone) e ícone na barra de tarefas
tools/gerar_icone.py   gera o ícone (SVG, ICO de 16 a 256 px e PNG) no padrão dos ícones da RLA.dev
                       (a pasta tools/ e o SVG ficam só no repositório, fora do pacote do app)
tools/smoke_test.py    teste rápido da instalação (também roda no GitHub Actions em Windows)
```

## Atualizações

O Pixel Lab IA consulta sozinho se há versão nova (ao abrir e a cada 15 minutos) e mostra um aviso
na página inicial com as novidades. Nada é instalado sem você clicar em **Atualizar agora**.
**Agora não** esconde aquele aviso; **Buscar atualização** consulta na hora e mostra de novo.

Ao atualizar:
1. o app baixa só o código do programa (cerca de 100 KB) e confere o pacote;
2. guarda uma cópia da versão atual em `versoes-anteriores\`;
3. troca só os arquivos que mudaram e apaga os que saíram da versão;
4. fecha e abre de novo sozinho, já na versão nova. Se a versão trouxer bibliotecas ou modelos
   novos, eles são instalados nessa hora (pode levar alguns minutos).

Python, bibliotecas, modelos de IA e seus arquivos nunca são tocados. Se algo der errado, o app
volta sozinho para a versão anterior. Depois de atualizar, **Buscar atualização** mostra
**Voltar para a versão X**, caso a versão nova tenha piorado algo. Não instala com um
processamento em andamento. O registro fica em `logs\atualizacao.log`.

**A primeira versão com este sistema (1.2.0) precisa chegar por ZIP**: extraia por cima da
pasta do Pixel Lab IA e rode o `instalar.bat`. Daí em diante, as versões chegam pelo aviso.

### Como funciona

| Peça | Papel |
|---|---|
| Repositório público `rla-devv/realceia-versoes` | Só os pacotes: `atualizacao.json` e `versoes/`. O código continua privado. |
| `atualizacao.json` | `{"versao", "arquivo", "sha256", "tamanho", "novidades"}` |
| `realce/atualizacao.py` | `verificar()`, `instalar()`, `restaurar()` e as etapas com o app fechado. |
| `arquivos-do-app.txt` | O que é código do app (gerado no empacotamento): só isso é trocado ou apagado. |
| `app.py` | `GET /api/atualizacao` (com `?forcar=1`), `POST /api/atualizacao`, `POST /api/atualizacao/restaurar`; depois de instalar, sai com o código 3. |
| `realceia.pyw` | Roda o app num processo à parte. Código 3: conclui a atualização e reabre. Queda: reabre em 2 s, até 5 vezes em 10 min. |
| `empacotar.py` / `publicar.py` | Geram e publicam os pacotes. |

Regras de segurança, todas antes de trocar qualquer arquivo: o SHA-256 do pacote tem de bater
com o `atualizacao.json`; a versão dentro do pacote tem de ser a anunciada; nenhum caminho pode
sair da pasta do app (`..`, caminho absoluto, `:`) nem entrar em pastas protegidas (`.venv`,
`.runtime`, `weights`, `logs`, `samples`, `versoes-anteriores`); a lista do pacote tem de
conferir com o conteúdo. Cada arquivo é gravado como `.novo` e renomeado; arquivos iguais não
são reescritos.

### Publicar uma versão nova

1. Aumente `__version__` em `realce/__init__.py` e faça o commit.
2. Rode `python publicar.py --novidades "O que mudou, em linguagem simples."`

O script recusa se houver alteração sem commit ou se a versão não for maior que a publicada.
Ele gera os pacotes em `dist\` (`empacotar.py`), copia para o clone de
`rla-devv/realceia-versoes` (padrão: pasta vizinha `realceia-versoes`) e faz o push. Os apps
abertos mostram o aviso em alguns minutos (o GitHub guarda cópia por cerca de 5 min).
O `PixelLabIA.zip` (nome fixo, na raiz do repositório de versões) serve para instalar pela primeira vez: leva só o `instalar.bat`, que baixa o pacote publicado mais novo.

## Licenças dos modelos

CodeFormer (licença S-Lab) e os pesos ArcFace da InsightFace são só para uso **não comercial**, o que
cobre o uso pessoal e de pesquisa deste projeto. SwinIR, Restormer, Real-ESRGAN/ESRNet, GFPGAN, YuNet
e fast-alpr têm licenças permissivas, assim como o detector de veículos do torchvision (BSD) e o OpenCLIP com pesos DataComp (MIT). Se o projeto um dia virar produto, troque o CodeFormer pelo GFPGAN e revise as licenças.
