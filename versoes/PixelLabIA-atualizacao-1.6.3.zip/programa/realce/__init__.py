__version__ = "1.6.3"

# as versões novas são publicadas em rla-devv/realceia-versoes (ver realce/atualizacao.py)
