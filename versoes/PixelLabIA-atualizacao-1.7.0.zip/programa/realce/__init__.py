__version__ = "1.7.0"

# as versões novas são publicadas em rla-devv/realceia-versoes (ver realce/atualizacao.py)
