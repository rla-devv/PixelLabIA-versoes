@echo off
rem abre o Pixel Lab IA (o mesmo que o atalho). Fica em "programa" desde a 1.7.3; antes, na pasta do app.
set "PROG=%~dp0"
set "APP=%~dp0"
if exist "%~dp0realceia.pyw" if exist "%~dp0..\.venv\Scripts\pythonw.exe" set "APP=%~dp0..\"
if exist "%~dp0programa\realceia.pyw" set "PROG=%~dp0programa\"
cd /d "%APP%"
if exist ".venv\Scripts\pythonw.exe" goto :abrir
echo O Pixel Lab IA ainda nao foi instalado. Rode "Instalar Pixel Lab IA.bat" primeiro.
pause
exit /b 1
:abrir
start "" ".venv\Scripts\pythonw.exe" "%PROG%realceia.pyw" %*
