"""Pacote de provas de um achado no vídeo: trecho, quadro e SHA-256, ligados ao original.

O vídeo original nunca é alterado: o trecho é copiado sem recompressão quando possível (o corte
começa no quadro-chave mais próximo antes do pedido) e só é recomprimido quando o formato não
permite a cópia direta. Tudo vai num .zip com um arquivo de texto que descreve cada item e o
SHA-256 dele, para conferir depois que nada mudou.
"""

import hashlib
import subprocess
import tempfile
import time
import zipfile
from pathlib import Path

import cv2

from . import __version__
from .video import _ffmpeg, fmt_time


def sha256(caminho) -> str:
    h = hashlib.sha256()
    with open(caminho, "rb") as f:
        for bloco in iter(lambda: f.read(1 << 20), b""):
            h.update(bloco)
    return h.hexdigest()


def _rodar(cmd) -> bool:
    flags = subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0
    r = subprocess.run(cmd, capture_output=True, creationflags=flags)
    return r.returncode == 0


def recortar(src: str, ini: float, fim: float, pasta: Path) -> tuple[Path, str] | None:
    """Trecho [ini, fim] do vídeo. Devolve (arquivo, como foi feito) ou None sem FFmpeg."""
    ff = _ffmpeg()
    if not ff:
        return None
    ext = Path(src).suffix.lower() or ".mp4"
    copia = pasta / f"trecho{ext}"
    base = [ff, "-hide_banner", "-loglevel", "error", "-y", "-ss", f"{ini:.3f}", "-i", src,
            "-t", f"{max(fim - ini, 0.1):.3f}", "-map", "0"]
    if _rodar(base + ["-c", "copy", "-avoid_negative_ts", "make_zero", str(copia)]) \
            and copia.exists() and copia.stat().st_size > 0:
        return copia, ("cópia sem recompressão (a imagem é a mesma do original; o início vai "
                       "para o quadro-chave mais próximo antes do horário pedido)")
    copia.unlink(missing_ok=True)
    mp4 = pasta / "trecho.mp4"
    if _rodar([ff, "-hide_banner", "-loglevel", "error", "-y", "-ss", f"{ini:.3f}", "-i", src,
               "-t", f"{max(fim - ini, 0.1):.3f}", "-c:v", "libx264", "-crf", "12",
               "-preset", "medium", "-pix_fmt", "yuv420p", "-an", str(mp4)]):
        return mp4, ("recomprimido em H.264 com alta qualidade, porque o formato do original não "
                     "permite copiar o trecho direto")
    return None


def quadro(src: str, t: float, destino: Path) -> bool:
    cap = cv2.VideoCapture(src)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    cap.set(cv2.CAP_PROP_POS_FRAMES, int(round(t * fps)))
    ok, img = cap.read()
    cap.release()
    return bool(ok) and cv2.imwrite(str(destino), img)


def pacote(src: str, nome: str, achado: list[str], ini: float, fim: float, t_quadro: float,
           extras: dict[str, Path] | None = None) -> Path:
    """Monta o .zip: trecho, quadro, imagens extras e provas.txt com os SHA-256.

    achado: linhas que descrevem o que foi encontrado (placa lida, confiança, horários).
    extras: {nome no zip: arquivo} (ex.: a imagem combinada da placa).
    """
    pasta = Path(tempfile.mkdtemp(prefix="provas_"))
    original = Path(src)
    cap = cv2.VideoCapture(src)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 0
    cap.release()
    duracao = total / fps if total else None
    ini = max(0.0, ini)
    fim = min(fim, duracao) if duracao else fim

    itens: list[tuple[str, Path, str]] = []  # (nome no zip, arquivo, descrição)
    trecho = recortar(src, ini, fim, pasta)
    if trecho:
        arq, como = trecho
        itens.append((f"trecho-{fmt_time(ini).replace(':', 'm')}s-a-{fmt_time(fim).replace(':', 'm')}s{arq.suffix}",
                      arq, f"Trecho de {fmt_time(ini)} a {fmt_time(fim)} do vídeo: {como}."))
    png = pasta / "quadro.png"
    if quadro(src, t_quadro, png):
        itens.append((f"quadro-{fmt_time(t_quadro).replace(':', 'm')}s.png", png,
                      f"Quadro inteiro do original em {fmt_time(t_quadro)}, sem nenhum ajuste."))
    for nome_zip, arq in (extras or {}).items():
        if arq and Path(arq).exists():
            itens.append((nome_zip, Path(arq), "Imagem gerada pelo Pixel Lab IA (ver abaixo)."))

    linhas = [
        f"PROVAS DO ACHADO - Pixel Lab IA {__version__}",
        f"Gerado em {time.strftime('%d/%m/%Y %H:%M:%S')} (horário deste computador)",
        "",
        "VÍDEO ORIGINAL (não foi alterado)",
        f"  Arquivo: {original.name}",
        f"  Tamanho: {original.stat().st_size:,} bytes".replace(",", "."),
        f"  SHA-256: {sha256(src)}",
        "",
        "ACHADO",
        *[f"  {linha}" for linha in achado],
        "  Os resultados são pistas: confira sempre nas imagens.",
        "",
        "ARQUIVOS DESTE PACOTE",
    ]
    for nome_zip, arq, desc in itens:
        linhas += [f"  {nome_zip}", f"    {desc}", f"    SHA-256: {sha256(arq)}"]
    if not trecho:
        linhas.append("  (o trecho do vídeo não pôde ser gerado: o FFmpeg não abriu este formato)")
    linhas += [
        "",
        "Imagens combinadas: vêm de vários quadros do próprio vídeo, alinhados e somados. Nenhum",
        "detalhe é inventado por IA generativa.",
        "Para conferir um arquivo depois: no PowerShell, Get-FileHash <arquivo> -Algorithm SHA256",
    ]
    destino = pasta / f"{nome}.zip"
    with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("provas.txt", "\r\n".join(linhas) + "\r\n")
        for nome_zip, arq, _ in itens:
            z.write(arq, nome_zip)
    return destino
