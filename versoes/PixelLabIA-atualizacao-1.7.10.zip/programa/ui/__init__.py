"""Identidade visual do Pixel Lab IA (tema, estilos, cabeçalho e balões de ajuda)."""
