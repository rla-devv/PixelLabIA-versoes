"""Tema do Gradio no padrão visual dos apps da RLA.dev (base: Enxuto IA 1.13.2)."""

import base64
import json
from pathlib import Path

import gradio as gr

HERE = Path(__file__).resolve().parent
FONTES = HERE.parent / "assets" / "fontes"

# paleta do padrão RLA.dev (os mesmos valores dos tokens em style.css)
DARK = dict(bg="#0a1120", surface="#111b2e", surface2="#182540", line="#24324d",
            text="#e6ecf5", muted="#93a3bb", accent="#58c4ff", accent_strong="#8ad8ff",
            accent_ink="#05162e")
LIGHT = dict(bg="#f2f5fa", surface="#ffffff", surface2="#e7ecf4", line="#d8e0ec",
             text="#0f1a2e", muted="#5a6578", accent="#2a52d6", accent_strong="#1f3fae",
             accent_ink="#ffffff")


def _pair(key):
    return LIGHT[key], DARK[key]


def build_theme() -> gr.themes.Base:
    t = gr.themes.Base(
        primary_hue=gr.themes.colors.blue,
        neutral_hue=gr.themes.colors.slate,
        # fontes embutidas no app (style.css), sem buscar nada na internet
        font=[gr.themes.Font("Figtree"), "Segoe UI", "system-ui", "sans-serif"],
        font_mono=[gr.themes.Font("JetBrains Mono"), "Consolas", "monospace"],
        radius_size=gr.themes.sizes.radius_lg,
    )
    values = {}
    for name, key in [
        ("body_background_fill", "bg"),
        ("background_fill_primary", "surface"),
        ("background_fill_secondary", "surface2"),
        ("block_background_fill", "surface"),
        ("block_border_color", "line"),
        ("border_color_primary", "line"),
        ("body_text_color", "text"),
        ("block_title_text_color", "text"),
        ("block_label_text_color", "muted"),
        ("body_text_color_subdued", "muted"),
        ("input_background_fill", "surface2"),
        ("input_border_color", "line"),
        ("block_label_background_fill", "surface2"),
        ("button_secondary_background_fill", "surface2"),
        ("button_secondary_background_fill_hover", "line"),
        ("button_secondary_border_color", "line"),
        ("button_secondary_text_color", "text"),
        ("button_primary_background_fill", "accent"),
        ("button_primary_background_fill_hover", "accent_strong"),
        ("button_primary_text_color", "accent_ink"),
        ("slider_color", "accent"),
        ("checkbox_background_color_selected", "accent"),
        ("checkbox_border_color_selected", "accent"),
        ("color_accent_soft", "surface2"),
        ("table_even_background_fill", "surface"),
        ("table_odd_background_fill", "surface2"),
        ("table_border_color", "line"),
    ]:
        light, dark = _pair(key)
        values[name] = light
        values[name + "_dark"] = dark
    # o app sempre abre escuro: o fundo que a página do Gradio pinta antes de tudo carregar é
    # escuro mesmo com o Windows no tema claro (o estilo do app assume depois)
    values["body_background_fill"] = DARK["bg"]
    t.set(**values, color_accent=DARK["accent"], block_shadow="none", block_shadow_dark="none",
          button_large_radius="9px", button_medium_radius="9px",
          button_small_radius="9px", block_border_width="1px", block_radius="16px")
    return t


def _fontes() -> str:
    """As três fontes do padrão embutidas na página (o app funciona sem internet)."""
    regras = []
    for familia, arquivo, pesos in (("Bricolage Grotesque", "bricolage-grotesque.woff2", "700 800"),
                                    ("Figtree", "figtree.woff2", "400 800"),
                                    ("JetBrains Mono", "jetbrains-mono.woff2", "400 700")):
        p = FONTES / arquivo
        if p.exists():
            dados = base64.b64encode(p.read_bytes()).decode()
            regras.append(f"@font-face {{ font-family: '{familia}'; font-style: normal; "
                          f"font-weight: {pesos}; font-display: swap; "
                          f"src: url(data:font/woff2;base64,{dados}) format('woff2'); }}")
    return "\n".join(regras)


def css() -> str:
    return _fontes() + "\n" + (HERE / "style.css").read_text(encoding="utf-8")


def head(help_texts: dict[str, str], version: str) -> str:
    """Script dos balões de ajuda, do tema e da busca de atualização, com os dados embutidos."""
    js = (HERE / "ui.js").read_text(encoding="utf-8")
    data = {"help": help_texts, "version": version}
    return f"<script>window.PIXELLAB = {json.dumps(data, ensure_ascii=False)};\n{js}</script>"
