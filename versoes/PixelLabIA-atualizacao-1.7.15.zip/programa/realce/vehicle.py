"""Identificação do veículo: tipo, cor e possível modelo.

- Tipo: detector de veículos do torchvision (Faster R-CNN MobileNet, treinado no COCO).
- Cor e modelo: OpenCLIP, que compara a imagem com descrições em texto. Não existe modelo
  treinado só com carros brasileiros; por isso a lista abaixo é comparada "por semelhança".
  O resultado é uma sugestão ("possível modelo"), não uma identificação certa.
"""

from dataclasses import dataclass
from functools import lru_cache

import cv2
import numpy as np
import torch

from .models import device, gpu_info, weight_path

CLIP_ARCH = "ViT-L-14"  # pesos DataComp-XL; acertou 15 de 19 modelos em fotos de referência

# modelos comuns no Brasil (marca, modelo, carroceria)
MODELS = [
    ("Fiat", "Uno", "hatch"), ("Fiat", "Mobi", "hatch"), ("Fiat", "Palio", "hatch"),
    ("Fiat", "Argo", "hatch"), ("Fiat", "Punto", "hatch"), ("Fiat", "Siena", "sedã"),
    ("Fiat", "Cronos", "sedã"), ("Fiat", "Grand Siena", "sedã"), ("Fiat", "Idea", "monovolume"),
    ("Fiat", "Doblò", "monovolume"), ("Fiat", "Strada", "picape"), ("Fiat", "Toro", "picape"),
    ("Fiat", "Fiorino", "furgão"), ("Fiat", "Ducato", "van"), ("Fiat", "Pulse", "SUV"),
    ("Fiat", "Fastback", "SUV"),
    ("Volkswagen", "Gol", "hatch"), ("Volkswagen", "Fox", "hatch"), ("Volkswagen", "up!", "hatch"),
    ("Volkswagen", "Polo", "hatch"), ("Volkswagen", "Golf", "hatch"), ("Volkswagen", "Voyage", "sedã"),
    ("Volkswagen", "Virtus", "sedã"), ("Volkswagen", "Jetta", "sedã"), ("Volkswagen", "Saveiro", "picape"),
    ("Volkswagen", "Amarok", "picape"), ("Volkswagen", "T-Cross", "SUV"), ("Volkswagen", "Nivus", "SUV"),
    ("Volkswagen", "Taos", "SUV"), ("Volkswagen", "Kombi", "van"), ("Volkswagen", "Fusca", "clássico"),
    ("Chevrolet", "Onix", "hatch"), ("Chevrolet", "Celta", "hatch"), ("Chevrolet", "Corsa", "hatch"),
    ("Chevrolet", "Agile", "hatch"), ("Chevrolet", "Prisma", "sedã"), ("Chevrolet", "Onix Plus", "sedã"),
    ("Chevrolet", "Cobalt", "sedã"), ("Chevrolet", "Classic", "sedã"), ("Chevrolet", "Cruze", "sedã"),
    ("Chevrolet", "Spin", "monovolume"), ("Chevrolet", "Meriva", "monovolume"),
    ("Chevrolet", "Zafira", "monovolume"), ("Chevrolet", "Montana", "picape"),
    ("Chevrolet", "S10", "picape"), ("Chevrolet", "Tracker", "SUV"),
    ("Ford", "Ka", "hatch"), ("Ford", "Fiesta", "hatch"), ("Ford", "Focus", "hatch"),
    ("Ford", "EcoSport", "SUV"), ("Ford", "Ranger", "picape"),
    ("Hyundai", "HB20", "hatch"), ("Hyundai", "HB20S", "sedã"), ("Hyundai", "Creta", "SUV"),
    ("Hyundai", "Tucson", "SUV"),
    ("Toyota", "Etios", "hatch"), ("Toyota", "Yaris", "hatch"), ("Toyota", "Corolla", "sedã"),
    ("Toyota", "Corolla Cross", "SUV"), ("Toyota", "Hilux", "picape"), ("Toyota", "SW4", "SUV"),
    ("Honda", "Fit", "hatch"), ("Honda", "City", "sedã"), ("Honda", "Civic", "sedã"),
    ("Honda", "HR-V", "SUV"), ("Honda", "WR-V", "SUV"),
    ("Renault", "Kwid", "hatch"), ("Renault", "Sandero", "hatch"), ("Renault", "Clio", "hatch"),
    ("Renault", "Logan", "sedã"), ("Renault", "Duster", "SUV"), ("Renault", "Captur", "SUV"),
    ("Renault", "Oroch", "picape"), ("Renault", "Master", "van"),
    ("Nissan", "March", "hatch"), ("Nissan", "Versa", "sedã"), ("Nissan", "Kicks", "SUV"),
    ("Nissan", "Frontier", "picape"),
    ("Jeep", "Renegade", "SUV"), ("Jeep", "Compass", "SUV"),
    ("Peugeot", "208", "hatch"), ("Peugeot", "207", "hatch"), ("Peugeot", "2008", "SUV"),
    ("Citroën", "C3", "hatch"), ("Citroën", "C4 Cactus", "SUV"),
    ("Mitsubishi", "L200 Triton", "picape"), ("Mitsubishi", "Pajero", "SUV"),
    ("Kia", "Sportage", "SUV"), ("Mercedes-Benz", "Sprinter", "van"),
]

COLORS = {
    "branco": "white", "prata": "silver", "cinza": "gray", "preto": "black",
    "vermelho": "red", "azul": "blue", "verde": "green", "amarelo": "yellow",
    "laranja": "orange", "marrom": "brown", "bege": "beige", "vinho": "dark red",
}

# classes do COCO usadas pelo detector do torchvision (só para localizar o veículo: o tipo é
# decidido pelo OpenCLIP, porque o COCO chama picapes e SUVs de "truck")
COCO_VEHICLES = {3: "carro", 4: "moto", 6: "ônibus", 8: "caminhão"}

# tipo do veículo: nome mostrado -> descrições em inglês para o OpenCLIP
KINDS = {
    "carro": ["a photo of a passenger car.", "a photo of a hatchback, sedan or SUV."],
    "picape": ["a photo of a pickup truck.", "a photo of a small pickup truck with a cargo bed."],
    "furgão / van": ["a photo of a panel van.", "a photo of a delivery van."],
    "caminhão": ["a photo of a big truck.", "a photo of a cargo truck."],
    "ônibus": ["a photo of a bus.", "a photo of a city bus."],
    "moto": ["a photo of a motorcycle.", "a photo of a motorbike."],
}
# carrocerias da lista de modelos aceitas para cada tipo
KIND_BODIES = {"carro": {"hatch", "sedã", "SUV", "monovolume", "clássico"}, "picape": {"picape"},
               "furgão / van": {"furgão", "van", "monovolume"}}


@dataclass
class Vehicle:
    kind: str                                   # carro, moto, ônibus, caminhão
    box: tuple[int, int, int, int]              # x1, y1, x2, y2
    score: float
    color: str | None = None
    color_share: float = 0.0
    models: list[tuple[str, float]] | None = None   # [(nome, chance)], do mais provável
    cut: bool = False                           # cortado pela borda da imagem: modelo não estimado

    def summary(self) -> str:
        parts = [self.kind]
        if self.color:
            parts.append(self.color)
        return " · ".join(parts)

    def model_text(self) -> str:
        """Modelo para mostrar: com chance, ou "incerto" quando nenhum se destaca."""
        if self.cut:
            return "modelo não estimado: o veículo aparece cortado pela borda da imagem"
        if not self.models:
            return ""
        # todo modelo citado vai com a sua chance, para ninguém tomar um palpite fraco como certeza
        citados = [f"{m} ({p:.0%})" for m, p in self.models]
        if self.models[0][1] < 0.25:
            return "modelo incerto: " + ", ".join(citados)
        txt = f"possível modelo: {citados[0]}"
        if len(citados) > 1:
            txt += "; outras possibilidades: " + ", ".join(citados[1:])
        return txt


# ---------------- detector de veículos ----------------

@lru_cache(maxsize=1)
def _detector():
    from torchvision.models.detection import fasterrcnn_mobilenet_v3_large_fpn

    model = fasterrcnn_mobilenet_v3_large_fpn(weights=None, weights_backbone=None, num_classes=91,
                                              box_score_thresh=0.3)
    model.load_state_dict(torch.load(weight_path("vehicle-detector"), map_location="cpu", weights_only=True))
    return model.to(device()).eval()


def plausivel(v: Vehicle) -> bool:
    """Descarta o que não tem forma de veículo inteiro: caixas minúsculas e faixas compridas, como
    o relógio que o DVR imprime na imagem (que o detector chegou a chamar de moto)."""
    w, h = v.box[2] - v.box[0], v.box[3] - v.box[1]
    if min(w, h) < 24 or w > 4 * h or h > 3 * w:
        return False
    # faixa achatada com pouca certeza (ou "moto" achatada): texto, não veículo
    return not (w > 2.5 * h and v.score < 0.6) and not (v.kind == "moto" and w > 2.2 * h)


def detect_vehicles(img_bgr: np.ndarray, min_score: float = 0.4,
                    plausiveis: bool = True) -> list[Vehicle]:
    """plausiveis=False mantém também os muito pequenos (a busca ampliada de placas precisa dos
    carros distantes)."""
    found = _detect_vehicles(img_bgr, min_score)
    if not found and max(img_bgr.shape[:2]) > 900:
        # foto da tela de um monitor: reduzir apaga o padrão de interferência (moiré)
        half = cv2.resize(img_bgr, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)
        found = [Vehicle(v.kind, tuple(c * 2 for c in v.box), v.score)
                 for v in _detect_vehicles(half, min_score)]
    return [v for v in found if plausivel(v)] if plausiveis else found


def cortado(box, shape) -> bool:
    """Veículo cortado pela lateral da imagem: só um pedaço aparece (fica mais alto que largo,
    o que um carro inteiro nunca é). Um carro que enche a foto toca as bordas mas continua largo."""
    x1, y1, x2, y2 = box
    w, h = x2 - x1, y2 - y1
    m = max(3, shape[1] // 100)
    return (x1 <= m or x2 >= shape[1] - m) and w < 0.9 * h


@torch.inference_mode()
def _detect_vehicles(img_bgr: np.ndarray, min_score: float) -> list[Vehicle]:
    rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    x = torch.from_numpy(rgb).permute(2, 0, 1).float().div(255).to(device())
    out = _detector()([x])[0]
    found = []
    for box, label, score in zip(out["boxes"].cpu().numpy(), out["labels"].cpu().numpy(),
                                 out["scores"].cpu().numpy()):
        if int(label) in COCO_VEHICLES and score >= min_score:
            found.append(Vehicle(COCO_VEHICLES[int(label)], tuple(int(v) for v in box), float(score)))
    return found


def around_plate(img_bgr: np.ndarray, plate_box) -> Vehicle:
    """Quando o detector não acha o veículo (ex.: atrás de um portão), estima a região dele a
    partir da placa: um carro tem por volta de 5 a 6 larguras de placa."""
    x1, y1, x2, y2 = plate_box
    pw = max(x2 - x1, 1)
    cx = (x1 + x2) / 2
    h, w = img_bgr.shape[:2]
    box = (int(max(cx - 3.2 * pw, 0)), int(max(y2 - 3.6 * pw, 0)),
           int(min(cx + 3.2 * pw, w)), int(min(y2 + 0.8 * pw, h)))
    return Vehicle("carro", box, 0.0)


def vehicle_of_plate(vehicles: list[Vehicle], plate_box) -> Vehicle | None:
    """O veículo a que a placa pertence: o que contém o centro da placa (o menor, se houver vários)."""
    cx, cy = (plate_box[0] + plate_box[2]) / 2, (plate_box[1] + plate_box[3]) / 2
    inside = [v for v in vehicles if v.box[0] <= cx <= v.box[2] and v.box[1] <= cy <= v.box[3]]
    return min(inside, key=lambda v: (v.box[2] - v.box[0]) * (v.box[3] - v.box[1]), default=None)


# ---------------- OpenCLIP: cor e modelo ----------------

def _clip_device() -> torch.device:
    # o OpenCLIP grande ocupa ~1,7 GB: em placas de vídeo pequenas fica no processador
    # (leva uns 2 s por veículo) para não disputar memória com os outros modelos
    info = gpu_info()
    return device() if not info or info[1] >= 6 else torch.device("cpu")


@lru_cache(maxsize=1)
def _clip():
    import open_clip

    model, _, preprocess = open_clip.create_model_and_transforms(
        CLIP_ARCH, pretrained=str(weight_path("clip")), device=_clip_device())
    tokenizer = open_clip.get_tokenizer(CLIP_ARCH)
    return model.eval(), preprocess, tokenizer


@lru_cache(maxsize=8)
def _text_features(prompts: tuple[str, ...]) -> torch.Tensor:
    model, _, tokenizer = _clip()
    with torch.inference_mode():
        f = model.encode_text(tokenizer(list(prompts)).to(_clip_device())).float()
    return f / f.norm(dim=-1, keepdim=True)


def _image_features(img_bgr: np.ndarray) -> torch.Tensor:
    from PIL import Image

    model, preprocess, _ = _clip()
    pil = Image.fromarray(cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB))
    with torch.inference_mode():
        f = model.encode_image(preprocess(pil).unsqueeze(0).to(_clip_device())).float()
    return f / f.norm(dim=-1, keepdim=True)


def _rank(img_feat: torch.Tensor, groups: list[list[str]]) -> np.ndarray:
    """Probabilidade de cada grupo de descrições (média das frases de cada grupo)."""
    flat = tuple(p for g in groups for p in g)
    sims = (img_feat @ _text_features(flat).T).squeeze(0)
    idx, scores = 0, []
    for g in groups:
        scores.append(sims[idx:idx + len(g)].mean())
        idx += len(g)
    return torch.softmax(torch.stack(scores) * 100, 0).cpu().numpy()


def _model_prompts(brand, name, body):
    full = f"{brand} {name}"
    en = {"hatch": "hatchback", "sedã": "sedan", "picape": "pickup truck", "furgão": "panel van",
          "monovolume": "minivan", "van": "van", "clássico": "classic car"}.get(body, body)
    return [f"a photo of a {full}, a type of car.", f"a photo of the {full}.",
            f"a {full} {en}.", f"a security camera photo of a {full}."]


def white_balance(img_bgr: np.ndarray, reference_bgr: np.ndarray | None) -> np.ndarray:
    """Corrige a cor da imagem usando uma referência que deveria ser branca (ex.: a placa)."""
    if reference_bgr is None or reference_bgr.size == 0:
        return img_bgr
    c = reference_bgr.reshape(-1, 3).astype(np.float32)
    v = c.max(1)
    ref = c[v >= np.percentile(v, 60)].mean(0)
    gain = ref.mean() / np.maximum(ref, 1)
    return np.clip(img_bgr.astype(np.float32) * gain, 0, 255).astype(np.uint8)


def _scores(img_bgr: np.ndarray, vehicle: Vehicle, plate_crop: np.ndarray | None):
    """Probabilidades de tipo, cor e modelo para um veículo (ou None se o recorte for vazio)."""
    x1, y1, x2, y2 = vehicle.box
    crop = img_bgr[max(y1, 0):y2, max(x1, 0):x2]
    if crop.size == 0:
        return None
    feat = _image_features(white_balance(crop, plate_crop))
    kinds = _rank(feat, list(KINDS.values()))
    colors = _rank(feat, [[f"a photo of a {COLORS[n]} car.", f"a {COLORS[n]} vehicle."] for n in COLORS])
    models = _rank(feat, [_model_prompts(*m) for m in MODELS])
    return kinds, colors, models


# tipos que a comparação por semelhança pode escolher, conforme o que o detector viu (o COCO chama
# picapes, SUVs e vans de "caminhão"; um "carro" do detector só vira picape ou van com folga)
TIPOS_POSSIVEIS = {"carro": ("carro", "picape", "furgão / van"),
                   "caminhão": ("carro", "picape", "furgão / van", "caminhão"),
                   "ônibus": ("ônibus", "furgão / van", "caminhão")}


def _tipo(detector: str, kinds) -> str:
    if detector not in TIPOS_POSSIVEIS:  # moto: o detector reconhece bem
        return detector
    nomes = list(KINDS)
    p = {n: float(kinds[i]) for i, n in enumerate(nomes)}
    melhor = max(TIPOS_POSSIVEIS[detector], key=p.get)
    if detector == "carro" and melhor != "carro" and not (p[melhor] >= 0.85 and p[melhor] >= 6 * p["carro"]):
        return "carro"
    return melhor


def _finish(vehicle: Vehicle, kinds, colors, models, top: int) -> Vehicle:
    vehicle.kind = _tipo(vehicle.kind, kinds)
    i = int(colors.argmax())
    vehicle.color, vehicle.color_share = list(COLORS)[i], float(colors[i])
    if vehicle.kind in KIND_BODIES and not vehicle.cut:
        order = np.argsort(-models)[:top]
        vehicle.models = [(f"{MODELS[j][0]} {MODELS[j][1]}", float(models[j])) for j in order]
    return vehicle


def describe(img_bgr: np.ndarray, vehicle: Vehicle, plate_crop: np.ndarray | None = None,
             top: int = 3) -> Vehicle:
    """Preenche tipo, cor e possíveis modelos de um veículo detectado."""
    vehicle.cut = cortado(vehicle.box, img_bgr.shape)
    sc = _scores(img_bgr, vehicle, plate_crop)
    return _finish(vehicle, *sc, top) if sc else vehicle


def identify(samples: list[tuple[np.ndarray, tuple]], top: int = 3) -> Vehicle | None:
    """Identifica o veículo de uma placa a partir de uma ou mais imagens.

    samples: [(imagem, caixa da placa x1, y1, x2, y2)]. Em vídeo, usar alguns quadros deixa o
    resultado mais estável: as probabilidades de cada quadro são somadas (em média).
    """
    acc, best = [], None
    for img, pbox in samples:
        veh = vehicle_of_plate(detect_vehicles(img), pbox) or around_plate(img, pbox)
        x1, y1, x2, y2 = pbox
        sc = _scores(img, veh, img[max(y1, 0):y2, max(x1, 0):x2])
        if sc is None:
            continue
        acc.append(sc)
        veh.cut = cortado(veh.box, img.shape)
        # o melhor quadro é o de veículo inteiro e maior
        area = (veh.box[2] - veh.box[0]) * (veh.box[3] - veh.box[1]) * (0.1 if veh.cut else 1)
        if best is None or area > best[0]:
            best = (area, veh)
    if not acc:
        return None
    mean = [np.mean([a[i] for a in acc], axis=0) for i in range(3)]
    return _finish(best[1], *mean, top)
