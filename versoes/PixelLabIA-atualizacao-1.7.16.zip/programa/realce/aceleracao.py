"""Onde rodam os modelos ONNX (detecção e leitura de placas, medidor de rostos).

No Windows, o onnxruntime-directml usa qualquer placa de vídeo (Intel, AMD ou NVIDIA) pelo
DirectML. Se a placa não estiver disponível ou der erro, tudo volta para o processador, sem
mudar o resultado. REALCE_SEM_GPU=1 força o processador.
"""

import os
import threading

CPU = ["CPUExecutionProvider"]
# o DirectML não aceita a mesma sessão rodando em duas threads ao mesmo tempo
TRAVA = threading.RLock()
_falhou = False  # a placa de vídeo deu erro nesta sessão do app: daqui em diante, processador


def provedores() -> list[str]:
    """Provedores na ordem de preferência; o processador sempre por último."""
    if _falhou or os.environ.get("REALCE_SEM_GPU"):
        return CPU
    try:
        import onnxruntime as ort

        disponiveis = ort.get_available_providers()
    except Exception:  # noqa: BLE001
        return CPU
    for p in ("CUDAExecutionProvider", "DmlExecutionProvider"):
        if p in disponiveis:
            return [p, *CPU]
    return CPU


def usa_placa_de_video() -> bool:
    return provedores() != CPU


def desistir_da_placa(erro: Exception) -> None:
    """Chamado quando a placa de vídeo falha: o app continua pelo processador."""
    global _falhou
    if not _falhou:
        print("placa de vídeo indisponível para os modelos ONNX; usando o processador:",
              str(erro)[:300], flush=True)
    _falhou = True


def sessao(caminho: str):
    """InferenceSession na placa de vídeo, se houver; senão (ou se falhar), no processador."""
    import onnxruntime as ort

    from . import privacidade

    privacidade.onnxruntime()  # antes de criar a sessão

    prov = provedores()
    if prov != CPU:
        try:
            return ort.InferenceSession(caminho, providers=prov)
        except Exception as e:  # noqa: BLE001
            desistir_da_placa(e)
    return ort.InferenceSession(caminho, providers=CPU)
