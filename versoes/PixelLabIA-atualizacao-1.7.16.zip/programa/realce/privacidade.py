"""Sem telemetria: as bibliotecas de IA não mandam nada para fora do computador.

O aviso de privacidade do app diz que a internet só é usada para instalar, ver se há versão nova e
baixar a versão nova. Algumas bibliotecas mandam dados de uso por conta própria, então:
- Gradio e Hugging Face: leem as variáveis de ambiente quando são importados, por isso este módulo
  tem de ser importado antes deles (no app.py e no lançador; o lançador passa o ambiente para o app
  e para a instalação dos componentes);
- ONNX Runtime: ORT_DISABLE_TELEMETRY também é lida no import (no Linux, a versão 1.31 agenda o envio
  para uns 10 a 30 s depois do import, e disable_telemetry_events() sozinho não o impede); e
  onnxruntime() roda antes de criar qualquer sessão dos modelos.
tools/teste_sem_telemetria.py falha se alguma dessas conexões voltar.

Só usa a biblioteca padrão (o lançador importa este arquivo sem carregar o resto do app).
"""

import os

SEM_TELEMETRIA = {
    "GRADIO_ANALYTICS_ENABLED": "False",  # Gradio: consulta de versão e dados de uso (api.gradio.app, huggingface.co)
    "HF_HUB_DISABLE_TELEMETRY": "1",      # Hugging Face Hub: dados de uso (huggingface.co)
    "ORT_DISABLE_TELEMETRY": "1",         # ONNX Runtime: dados de uso (mobile.events.data.microsoft.com)
}


def ambiente() -> None:
    os.environ.update(SEM_TELEMETRIA)


def onnxruntime() -> None:
    """Desliga a telemetria do ONNX Runtime (mobile.events.data.microsoft.com). Pode chamar várias vezes."""
    try:
        import onnxruntime as ort

        ort.disable_telemetry_events()
    except Exception:  # noqa: BLE001 - sem onnxruntime (ou numa versão sem a função) não há o que desligar
        pass


ambiente()  # já no import: vale para tudo o que for importado depois
