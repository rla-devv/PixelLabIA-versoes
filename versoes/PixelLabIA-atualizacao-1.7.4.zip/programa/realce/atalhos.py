"""Atalhos do Pixel Lab IA no Windows: "Pixel Lab IA" na Área de Trabalho e no Menu Iniciar e
"Abrir Pixel Lab IA" na pasta do app.

Criados pelo "Instalar Pixel Lab IA.bat" e refeitos pelo lançador quando uma versão muda o nome ou o ícone
(ATALHOS_VERSAO). O ícone tem um nome de arquivo novo a cada troca: o Windows guarda os ícones
em cache pelo caminho, e com o mesmo caminho o atalho continuaria com o ícone antigo.

Só usa a biblioteca padrão (o lançador importa sem carregar o resto do app).
"""

import os
import subprocess
import sys
from pathlib import Path

PROG = Path(__file__).resolve().parent.parent           # pasta do código
ROOT = PROG.parent if PROG.name == "programa" else PROG  # pasta do app (com o .venv)
NOME = "Pixel Lab IA"
DESCRICAO = "Pixel Lab IA - Melhoria de fotos e vídeos e leitura de placas"
ICONE = PROG / "assets" / "pixel-lab-ia.ico"
ANTIGOS = ("Realce.lnk", "RealceIA.lnk", "Realce IA.lnk")  # nomes usados por versões anteriores
NA_PASTA = "Abrir " + NOME
# muda quando o nome, o ícone ou o lugar do lançador mudam (aqui, também com a pasta do código e
# com o lugar da pasta do app: se ela for movida, os atalhos são refeitos ao abrir)
ATALHOS_VERSAO = "7-" + ("programa" if PROG.name == "programa" else "raiz") + "-" + str(ROOT)
MARCA = ROOT / ".runtime" / "atalhos-versao.txt"
# identificador do app na barra de tarefas (separa o Pixel Lab IA do ícone do Python)
APP_ID = "RLAdev.RealceIA"


def _ps(texto: str) -> str:
    return texto.replace("'", "''")


def criar(todos: bool = True) -> bool:
    """Cria ou refaz os atalhos. todos=False (atualização): na Área de Trabalho só refaz se já
    havia um atalho do app lá; no Menu Iniciar sempre."""
    if os.name != "nt":
        return False
    pyw = ROOT / ".venv" / "Scripts" / "pythonw.exe"
    script = f"""
$ErrorActionPreference = 'Stop'
$s = New-Object -ComObject WScript.Shell
$desk = [Environment]::GetFolderPath('Desktop')
$prog = [Environment]::GetFolderPath('Programs')
$raiz = '{_ps(str(ROOT))}'
foreach ($d in @($desk, $prog, $raiz)) {{
  $nome = if ($d -eq $raiz) {{ '{_ps(NA_PASTA)}' }} else {{ '{_ps(NOME)}' }}
  $tinha = $false
  foreach ($n in @({", ".join(f"'{_ps(n)}'" for n in (*ANTIGOS, NOME + '.lnk'))}, "$nome.lnk")) {{
    $p = Join-Path $d $n
    if (Test-Path -LiteralPath $p) {{ $tinha = $true; Remove-Item -LiteralPath $p -ErrorAction SilentlyContinue }}
  }}
  if ($d -eq $desk -and -not $tinha -and '{'1' if todos else '0'}' -eq '0') {{ continue }}
  $l = $s.CreateShortcut((Join-Path $d "$nome.lnk"))
  $l.TargetPath = '{_ps(str(pyw))}'
  $l.Arguments = '"{_ps(str(PROG / "realceia.pyw"))}"'
  $l.WorkingDirectory = '{_ps(str(PROG))}'
  $l.IconLocation = '{_ps(str(ICONE))},0'
  $l.Description = '{_ps(DESCRICAO)}'
  $l.Save()
}}
# pasta do app mais limpa: as pastas técnicas ficam ocultas (continuam funcionando)
if ('{'1' if PROG != ROOT else '0'}' -eq '1') {{
  foreach ($n in @('.venv', '.runtime', 'logs', 'versoes-anteriores')) {{
    $p = Join-Path '{_ps(str(ROOT))}' $n
    if (Test-Path $p) {{ $i = Get-Item $p -Force; $i.Attributes = $i.Attributes -bor [IO.FileAttributes]::Hidden }}
  }}
}}
# pede ao Windows para redesenhar os ícones
Start-Process -FilePath "$env:SystemRoot\\System32\\ie4uinit.exe" -ArgumentList '-show' -WindowStyle Hidden -ErrorAction SilentlyContinue
"""
    r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
                       capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW)
    if r.returncode:
        print("não consegui criar os atalhos:", (r.stderr or r.stdout)[-400:], flush=True)
        return False
    MARCA.parent.mkdir(exist_ok=True)
    MARCA.write_text(ATALHOS_VERSAO, encoding="utf-8")
    return True


def atualizar_se_preciso() -> None:
    """Chamado pelo lançador: refaz os atalhos uma vez quando o nome ou o ícone mudam."""
    if os.name != "nt" or (ROOT / ".git").exists():
        return
    try:
        if MARCA.exists() and MARCA.read_text(encoding="utf-8").strip() == ATALHOS_VERSAO:
            return
        criar(todos=False)
    except Exception as e:  # noqa: BLE001 - atalho nunca impede o app de abrir
        print("atalhos:", e, flush=True)


def identificar_processo() -> None:
    """Faz a barra de tarefas mostrar o Pixel Lab IA (nome e ícone) em vez do Python."""
    if os.name != "nt":
        return
    try:
        import ctypes

        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
    except Exception:  # noqa: BLE001
        pass


if __name__ == "__main__":
    sys.exit(0 if criar(todos="--atualizacao" not in sys.argv) else 1)
