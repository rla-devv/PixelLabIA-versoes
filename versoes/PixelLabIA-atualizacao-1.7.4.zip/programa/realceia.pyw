"""Abre o Pixel Lab IA numa janela própria, como um programa comum.

Uso: dois cliques no atalho "Pixel Lab IA" (criado pelo "Instalar Pixel Lab IA.bat"), ou
     .venv\\Scripts\\pythonw.exe realceia.pyw [--navegador]
--navegador abre no navegador padrão em vez da janela própria.

O app (app.py) roda num processo à parte, só neste computador (127.0.0.1). Se ele sair com o
código 3 (atualização instalada), este lançador conclui a atualização e o abre de novo, já
com a versão nova. Se ele cair, abre de novo em 2 s, até 5 vezes em 10 minutos.
"""

import os
import secrets
import socket
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
# a pasta do app (com o .venv); desde a 1.5.0 o código fica na subpasta "programa"
BASE = ROOT.parent if ROOT.name == "programa" else ROOT
# versão deste lançador: o servidor só instala versões que pedem um lançador até esta
LANCADOR = "2"
# mesma pasta de dados usada pelo instalador (modelos compartilhados entre instalações)
if sys.platform == "win32" and os.environ.get("LOCALAPPDATA"):
    os.environ.setdefault("REALCE_DADOS", str(Path(os.environ["LOCALAPPDATA"]) / "RealceIA"))
sys.path.insert(0, str(ROOT))

# sem console (pythonw), as mensagens vão para logs/pixel-lab-ia.log
LOGS = ROOT / "logs"
LOGS.mkdir(exist_ok=True)
LOG_FILE = LOGS / "pixel-lab-ia.log"
(LOGS / "realceia.log").unlink(missing_ok=True)  # registro com o nome antigo do app
if sys.stdout is None or sys.executable.lower().endswith("pythonw.exe"):
    sys.stdout = sys.stderr = open(LOG_FILE, "w", encoding="utf-8", buffering=1)

# mesmas cores do app (tema escuro do padrão RLA.dev), para a abertura não "piscar" outra identidade
BG = "#0a1120"
PAGE = """<!doctype html><html><head><meta charset="utf-8"><style>
body{{margin:0;height:100vh;display:flex;align-items:center;justify-content:center;
font-family:"Segoe UI",system-ui,sans-serif;color:#e6ecf5;
background:radial-gradient(1100px 420px at 15% -120px,#12264a,transparent 70%),#0a1120}}
.box{{text-align:center;max-width:560px;padding:24px}}
.logo{{width:64px;height:64px;margin:0 auto 18px;border-radius:16px;background:#58c4ff;
color:#05162e;display:flex;align-items:center;justify-content:center}}
.logo svg{{width:36px;height:36px}}
.icon{{display:block;margin:0 auto 14px}}
h1{{font-size:38px;margin:0 0 6px;letter-spacing:-.02em}}
p{{font-size:16px;line-height:1.55;color:#93a3bb}}
.tag{{margin:0;font-size:17px}}
.spin{{width:36px;height:36px;margin:26px auto 14px;border:3px solid #24324d;
border-top-color:#58c4ff;border-radius:50%;animation:s .9s linear infinite}}
@keyframes s{{to{{transform:rotate(360deg)}}}}
.err{{color:#e6ecf5}}
code{{background:#182540;border:1px solid #24324d;color:#e6ecf5;padding:2px 6px;
border-radius:6px;word-break:break-all}}
</style></head><body><div class="box">{body}</div></body></html>"""

TITLE = "Pixel Lab IA"
def _logo() -> str:
    """O ícone do app (o mesmo do atalho); sem o arquivo, a lupa desenhada."""
    png = ROOT / "assets" / "pixel-lab-ia-icone-128.png"
    if png.exists():
        import base64

        data = base64.b64encode(png.read_bytes()).decode()
        return f'<img class="icon" src="data:image/png;base64,{data}" alt="" width="76" height="76">'
    return ('<div class="logo"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" '
            'stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" '
            'r="7"/><path d="m21 21-4.3-4.3"/><path d="M11 8v6M8 11h6"/></svg></div>')


LOGO = _logo()
HEADER = LOGO + "<h1>Pixel Lab IA</h1><p class='tag'>Melhoria de fotos e vídeos e leitura de placas diretamente no seu computador.</p>"

LOADING = PAGE.format(body=HEADER + "<div class='spin'></div>"
                           "<p>Carregando os modelos de IA…<br>"
                           "A primeira abertura pode levar até 1 minuto.</p>")


def error_page(msg: str) -> str:
    return PAGE.format(body=HEADER + f"<p class='err'>Não foi possível iniciar o app.</p>"
                            f"<p><code>{msg}</code></p>"
                            f"<p>Detalhes em <code>{LOGS / 'servidor.log'}</code></p>")


def message_page(msg: str) -> str:
    return PAGE.format(body=HEADER + f"<div class='spin'></div><p>{msg}</p>")


SAIR_PARA_ATUALIZAR = 3
MAX_QUEDAS, JANELA_QUEDAS = 5, 600  # até 5 quedas em 10 minutos


def free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


class Server:
    """O app num processo à parte, que pode ser reaberto sem fechar a janela."""

    def __init__(self, show):
        self.port = free_port()  # a mesma porta em todas as reaberturas: a página só recarrega
        self.url = f"http://127.0.0.1:{self.port}"
        # senha da sessão: só esta janela usa o servidor (ver realce/chave.py)
        self.chave = secrets.token_urlsafe(32)
        # já no tema escuro desde o primeiro quadro
        self.entrada = f"{self.url}/?__theme=dark&chave={self.chave}"
        self.show = show          # show(html=None, url=None): atualiza a janela ou o navegador
        self.proc = None
        self.closing = False
        self.falls: list[float] = []

    def start(self) -> bool:
        py = sys.executable  # pythonw.exe no Windows: o servidor também roda sem janela preta
        try:  # o registro do servidor cresce a cada abertura: passou de 256 KB, fica só o fim
            from realce.atualizacao import limitar_log
            limitar_log(LOGS / "servidor.log")
        except Exception:
            pass
        log = open(LOGS / "servidor.log", "a", encoding="utf-8")
        log.write(time.strftime("\n==== %Y-%m-%d %H:%M:%S ====\n"))
        log.flush()
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        # procura o app a cada abertura: uma atualização pode ter mudado a pasta do código
        nova = BASE / "programa"
        prog = nova if (nova / "app.py").is_file() else BASE
        env = dict(os.environ, REALCE_LANCADOR=LANCADOR, REALCE_CHAVE=self.chave)
        self.proc = subprocess.Popen([py, str(prog / "app.py"), "--porta", str(self.port)],
                                     cwd=str(prog), env=env, stdout=log, stderr=subprocess.STDOUT,
                                     creationflags=flags)
        deadline = time.time() + 300  # a primeira abertura carrega bibliotecas pesadas
        while time.time() < deadline:
            if self.proc.poll() is not None:
                return False
            try:
                urllib.request.urlopen(self.url + "/api/saude", timeout=2)
                return True
            except OSError:
                time.sleep(0.4)
        return False

    def finish_update(self):
        """Bibliotecas e modelos novos pedidos pela atualização, com o app fechado."""
        from realce import atualizacao

        try:
            r = atualizacao.concluir_pendente(lambda m: self.show(html=message_page(m)))
        except Exception:  # noqa: BLE001 - o app abre mesmo assim
            traceback.print_exc()
            return "Abrindo o Pixel Lab IA…"
        if r and r.get("falhou"):
            return "A atualização não deu certo e o Pixel Lab IA voltou para a versão anterior.<br>Abrindo…"
        return "Abrindo a versão nova…"

    def run(self):
        """Abre o app e o mantém aberto até a janela fechar."""
        self.finish_update()  # se uma atualização ficou pela metade, conclui antes
        while not self.closing:
            if not self.start():
                code = self.proc.poll()
                if self.closing:
                    return
                if not self._may_retry():
                    self.show(html=error_page(f"o app parou ao abrir (código {code})."))
                    return
                time.sleep(2)
                continue
            self.show(url=self.entrada)
            code = self.proc.wait()
            if self.closing:
                return
            print("app saiu com código", code, flush=True)
            if code == SAIR_PARA_ATUALIZAR:
                self.show(html=message_page("Aplicando a atualização…"))
                self.show(html=message_page(self.finish_update()))
                continue
            if not self._may_retry():
                self.show(html=error_page(f"o app parou {MAX_QUEDAS} vezes em pouco tempo "
                                          f"(último código {code})."))
                return
            self.show(html=message_page("O app parou inesperadamente. Abrindo de novo…"))
            time.sleep(2)

    def _may_retry(self) -> bool:
        now = time.time()
        self.falls = [t for t in self.falls if now - t < JANELA_QUEDAS] + [now]
        return len(self.falls) <= MAX_QUEDAS

    def stop(self):
        self.closing = True
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(5)
            except subprocess.TimeoutExpired:
                self.proc.kill()


def main():
    use_browser = "--navegador" in sys.argv
    webview = None
    if not use_browser:
        try:
            import webview
        except ImportError:
            print("pywebview não instalado; abrindo no navegador.", flush=True)

    if webview is None:
        opened = []

        def show(html=None, url=None):
            if html:
                print(html.split("<p>")[-1].split("</p>")[0].replace("<br>", " "), flush=True)
            if url and not opened:  # nas reaberturas a própria página recarrega
                opened.append(url)
                webbrowser.open(url)
                print("Pixel Lab IA em", url.split("?")[0], flush=True)

        server = Server(show)
        try:
            server.run()  # feche pela janela de comandos (Ctrl+C)
        except KeyboardInterrupt:
            server.stop()
        return

    from realce import atalhos

    atalhos.identificar_processo()  # barra de tarefas: nome e ícone do app, não do Python
    # atalhos com o nome e o ícone atuais (só quando mudaram; não atrasa a abertura)
    threading.Thread(target=atalhos.atualizar_se_preciso, daemon=True).start()
    webview.settings["ALLOW_DOWNLOADS"] = True  # permite baixar os resultados
    opcoes = dict(html=LOADING, width=1400, height=900, min_size=(900, 600), text_select=True,
                  background_color=BG)
    try:  # sempre abre maximizada
        window = webview.create_window(TITLE, maximized=True, **opcoes)
    except TypeError:  # pywebview antigo, sem a opção: maximiza ao mostrar
        window = webview.create_window(TITLE, **opcoes)
        window.events.shown += window.maximize

    def show(html=None, url=None):
        if url:
            window.load_url(url)
        elif html:
            window.load_html(html)

    server = Server(show)
    window.events.closed += server.stop

    def worker():
        try:
            server.run()
        except Exception as e:  # noqa: BLE001 - mostrar qualquer falha ao usuário
            traceback.print_exc()
            window.load_html(error_page(str(e)[:300]))

    begin = lambda: threading.Thread(target=worker, daemon=True).start()  # noqa: E731
    icon = ROOT / "assets" / "pixel-lab-ia.ico"
    try:
        webview.start(begin, icon=str(icon) if icon.exists() else None)
    except TypeError:  # pywebview antigo, sem ícone próprio
        webview.start(begin)
    # janela fechada: encerra tudo, inclusive o servidor
    server.stop()
    os._exit(0)


if __name__ == "__main__":
    main()
