__version__ = "1.7.5"

# as versões novas são publicadas em rla-devv/PixelLabIA-versoes (ver realce/atualizacao.py)
