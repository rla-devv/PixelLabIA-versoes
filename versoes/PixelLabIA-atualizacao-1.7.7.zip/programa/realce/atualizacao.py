"""Atualização automática do Pixel Lab IA (mesmo sistema do DegravaIA).

As versões ficam num repositório público só de pacotes (o código continua privado):
    atualizacao.json                       {"versao", "arquivo", "sha256", "tamanho", "novidades"}
    versoes/PixelLabIA-atualizacao-X.Y.Z.zip só o código do programa, com arquivos-do-app.txt

verificar() consulta o atualizacao.json. instalar() baixa o pacote, confere e troca os arquivos
do programa; o que precisa do app fechado (bibliotecas e modelos novos) fica anotado em
.runtime/pendente.json e o lançador (realceia.pyw) faz isso antes de abrir o app de novo.
restaurar() volta para a versão anterior. Python, bibliotecas, modelos e dados do usuário nunca
são tocados.

Só usa a biblioteca padrão: o lançador importa este arquivo sem carregar o resto do app.
"""

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

REPO_VERSOES = "rla-devv/PixelLabIA-versoes"
BASE = os.environ.get("REALCE_VERSOES_URL",
                      f"https://raw.githubusercontent.com/{REPO_VERSOES}/main").rstrip("/")
# PROG: a pasta com o código (app.py, realce/, ui/…). Desde a 1.5.0 ela é a subpasta "programa"
# e a pasta do app (ROOT) fica só com o "Instalar Pixel Lab IA.bat", o LEIA-ME.txt e o atalho "Abrir Pixel Lab IA".
# Até a 1.4.x as duas eram a mesma pasta. O código funciona nas duas organizações.
PROG = Path(__file__).resolve().parent.parent
ROOT = PROG.parent if PROG.name == "programa" else PROG
MANIFESTO = "arquivos-do-app.txt"
# onde o pacote e a pasta do app guardam a lista e a versão (organização nova primeiro)
LISTAS = ("programa/arquivos-do-app.txt", MANIFESTO)
VERSOES = ("programa/realce/__init__.py", "realce/__init__.py")
# versão do lançador (realceia.pyw) que está rodando; ele avisa o servidor por esta variável
LANCADOR = int(os.environ.get("REALCE_LANCADOR", "1") or 1)
# nunca trocadas nem apagadas (modelos, ambiente Python, logs, cópias de segurança…)
PROTEGIDAS = {".venv", ".runtime", ".git", "weights", "logs", "samples", "versoes-anteriores",
              "dist", "__pycache__"}
RUNTIME = ROOT / ".runtime"
PENDENTE = RUNTIME / "pendente.json"
ATUALIZADO = RUNTIME / "atualizado.json"
ANTERIORES = RUNTIME / "versoes-anteriores"   # cópia da versão anterior (oculta)
ANTERIORES_ANTIGA = ROOT / "versoes-anteriores"  # onde ficava até a 1.4.x
CONSULTA_VALIDADE = 15 * 60  # segundos

_cache: dict = {}
_trava = threading.Lock()


LOG_MAXIMO = 256 * 1024   # passou disso ao abrir, o registro fica só com o fim
LOG_FIM = 64 * 1024


def limitar_log(p: Path) -> None:
    """Corta um registro que cresce a cada abertura (servidor.log, atualizacao.log)."""
    try:
        if p.stat().st_size <= LOG_MAXIMO:
            return
        with open(p, "rb") as f:
            f.seek(-LOG_FIM, os.SEEK_END)
            fim = f.read()
        corte = fim.find(b"\n")
        p.write_bytes(fim[corte + 1:] if corte >= 0 else fim)
    except OSError:
        pass


# ---------------- versões ----------------

def versao_atual() -> str:
    texto = (PROG / "realce" / "__init__.py").read_text(encoding="utf-8")
    return _versao_em(texto)


def _prog_atual() -> Path:
    """Pasta do código agora (muda de lugar quando uma versão reorganiza as pastas)."""
    nova = ROOT / "programa"
    return nova if (nova / "app.py").is_file() else ROOT


def _versao_em(texto: str) -> str:
    m = re.search(r'^__version__\s*=\s*["\']([^"\']+)["\']', texto, re.M)
    if not m:
        raise ValueError("versão não encontrada")
    return m.group(1)


def numeros(v: str) -> tuple[int, ...]:
    """Comparação por números: 0.1.10 é maior que 0.1.9."""
    return tuple(int(re.sub(r"\D", "", p) or 0) for p in v.strip().lstrip("vV").split("."))


def maior(a: str, b: str) -> bool:
    x, y = numeros(a), numeros(b)
    n = max(len(x), len(y))
    return x + (0,) * (n - len(x)) > y + (0,) * (n - len(y))


# ---------------- consulta ----------------

def _baixar(url: str, timeout: int = 20) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "RealceIA-atualizacao",
                                               "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def desenvolvimento() -> bool:
    return (PROG / ".git").exists() and not os.environ.get("REALCE_VERSOES_URL")


def verificar(forcar: bool = False) -> dict:
    """{"status": "nova" | "atual" | "erro" | "dev", "atual", "versao", "novidades", "tamanho"}.

    Guarda a resposta por 15 min; forcar=True consulta na hora (botão Buscar atualização).
    """
    atual = versao_atual()
    if desenvolvimento():
        return {"status": "dev", "atual": atual}
    with _trava:
        if not forcar and _cache and time.time() - _cache["quando"] < CONSULTA_VALIDADE:
            return dict(_cache["resposta"], atual=atual)
    try:
        # o parâmetro evita a cópia guardada pelo GitHub quando a pessoa pede para consultar
        url = f"{BASE}/atualizacao.json" + (f"?t={int(time.time())}" if forcar else "")
        info = json.loads(_baixar(url))
        status = "nova" if maior(info["versao"], atual) else "atual"
        # versão que precisa de um lançador mais novo: antes, fechar e abrir o app uma vez
        if status == "nova" and int(info.get("lancador_minimo", 1)) > LANCADOR:
            status = "reiniciar"
        resposta = {"status": status, "versao": info["versao"],
                    "novidades": info.get("novidades", ""),
                    "tamanho": info.get("tamanho", 0), "info": info}
    except Exception as e:  # noqa: BLE001 - sem internet a consulta falha em silêncio
        return {"status": "erro", "atual": atual, "erro": str(e)[:200]}
    with _trava:
        _cache.update(quando=time.time(), resposta=resposta)
    return dict(resposta, atual=atual)


# ---------------- conferência do pacote ----------------

def _protegido(rel: str) -> bool:
    return any(p in PROTEGIDAS for p in rel.split("/"))


def _caminho_seguro(nome: str) -> bool:
    """Dentro da pasta do app: sem .., sem caminho absoluto, sem unidade (C:)."""
    if not nome or nome.startswith(("/", "\\")) or ":" in nome or "\\" in nome:
        return False
    partes = nome.split("/")
    return ".." not in partes and "" not in partes[:-1]


def conferir_pacote(dados: bytes, info: dict) -> tuple[zipfile.ZipFile, list[str]]:
    """Todas as regras de segurança, antes de trocar qualquer arquivo."""
    if "tamanho" in info and len(dados) != int(info["tamanho"]):
        raise ValueError("o pacote baixado não confere (tamanho diferente). Tente de novo.")
    if hashlib.sha256(dados).hexdigest() != info["sha256"].lower():
        raise ValueError("o pacote baixado não confere (SHA-256 diferente). Tente de novo.")
    import io

    z = zipfile.ZipFile(io.BytesIO(dados))
    nomes = [n for n in z.namelist() if not n.endswith("/")]
    ruins = [n for n in nomes if not _caminho_seguro(n) or _protegido(n)]
    if ruins:
        raise ValueError(f"o pacote tem caminhos não permitidos: {ruins[:3]}")
    lista_nome = next((n for n in LISTAS if n in nomes), None)
    versao_nome = next((n for n in VERSOES if n in nomes), None)
    if not lista_nome or not versao_nome:
        raise ValueError("o pacote não parece ser do Pixel Lab IA.")
    versao = _versao_em(z.read(versao_nome).decode("utf-8"))
    if versao != info["versao"]:
        raise ValueError(f"o pacote é da versão {versao}, mas foi anunciada a {info['versao']}.")
    lista = [n for n in z.read(lista_nome).decode("utf-8").splitlines() if n.strip()]
    if sorted(set(lista) | {lista_nome}) != sorted(nomes):
        raise ValueError("a lista de arquivos do pacote não confere com o conteúdo.")
    return z, nomes


# ---------------- troca dos arquivos ----------------

def _manifesto_local() -> list[str] | None:
    """Lista dos arquivos do programa instalado, com a própria lista (para ela sair junto
    quando muda de lugar)."""
    for nome in LISTAS:
        p = ROOT / nome
        if p.exists():
            return [n for n in p.read_text(encoding="utf-8").splitlines() if n.strip()] + [nome]
    return None


def _anteriores() -> Path:
    """Pasta da cópia da versão anterior (a nova, oculta, ou a antiga, visível)."""
    for pasta in (ANTERIORES, ANTERIORES_ANTIGA):
        if pasta.is_dir():
            return pasta
    return ANTERIORES


def _requisitos() -> bytes:
    return _ler(_prog_atual() / "requirements.txt")


def _arquivos_de_modelos() -> bytes:
    p = _prog_atual()
    return _ler(p / "download_weights.py") + _ler(p / "realce" / "models.py")


def _gravar(dest: Path, dados: bytes) -> None:
    """Grava como .novo e renomeia: o arquivo nunca fica pela metade."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.name + ".novo")
    tmp.write_bytes(dados)
    os.replace(tmp, dest)


def _copia_de_seguranca(versao: str, arquivos: list[str]) -> Path:
    """Guarda os arquivos atuais em versoes-anteriores/<versão>/ (fica só a última)."""
    destino = ANTERIORES / versao
    for pasta in (ANTERIORES, ANTERIORES_ANTIGA):
        if pasta.exists():
            shutil.rmtree(pasta)
    destino.mkdir(parents=True)
    existentes = []
    for rel in arquivos:
        src = ROOT / rel
        if src.is_file():
            (destino / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, destino / rel)
            existentes.append(rel)
    (destino / ".arquivos-guardados.txt").write_text("\n".join(existentes) + "\n", encoding="utf-8")
    return destino


def _aplicar(z: zipfile.ZipFile, nomes: list[str], antigos: list[str] | None) -> list[str]:
    """Troca os arquivos que mudaram e apaga os que saíram. Devolve os que mudaram."""
    mudaram = []
    for rel in nomes:
        dados = z.read(rel)
        dest = ROOT / rel
        # arquivos iguais não são reescritos (no Windows, reescrever um .bat em uso dá problema)
        if dest.is_file() and dest.read_bytes() == dados:
            continue
        _gravar(dest, dados)
        mudaram.append(rel)
    apagados = []
    for rel in sorted(set(antigos or []) - set(nomes)):
        p = ROOT / rel
        if not _protegido(rel) and _caminho_seguro(rel) and p.is_file():
            p.unlink()
            apagados.append(rel)
    _limpar_pastas(apagados)
    return mudaram + apagados


def _limpar_pastas(apagados: list[str]) -> None:
    """Remove as pastas que ficaram vazias (ou só com __pycache__) depois de apagar arquivos,
    como as pastas antigas do código quando ele muda para a subpasta "programa"."""
    pastas = {Path(rel).parent for rel in apagados}
    for pasta in sorted(pastas, key=lambda p: -len(p.parts)):
        while pasta.parts and not _protegido(pasta.as_posix()):
            alvo = ROOT / pasta
            if not alvo.is_dir():
                pasta = pasta.parent
                continue
            resto = [c for c in alvo.iterdir() if c.name != "__pycache__"]
            if resto:
                break
            shutil.rmtree(alvo, ignore_errors=True)
            pasta = pasta.parent


def _guardados(copia: Path) -> list[str]:
    """Arquivos guardados na cópia, um por linha (há nomes com espaço, como "Pixel Lab IA.bat")."""
    texto = (copia / ".arquivos-guardados.txt").read_text(encoding="utf-8")
    return [n for n in texto.splitlines() if n.strip()]


def _voltar(copia: Path, novos: list[str]) -> None:
    """Desfaz uma troca de arquivos a partir da cópia de segurança."""
    guardados = _guardados(copia)
    for rel in novos:
        p = ROOT / rel
        if rel not in guardados and p.is_file() and not _protegido(rel):
            p.unlink()  # arquivo que só existe na versão nova
    for rel in guardados:
        _gravar(ROOT / rel, (copia / rel).read_bytes())


def instalar(progresso=None) -> dict:
    """Baixa, confere e troca os arquivos do programa. O app deve fechar com o código 3 depois."""
    def passo(frac, texto):
        if progresso is not None:
            progresso(frac, texto)

    if desenvolvimento():
        raise RuntimeError("esta pasta é uma cópia de desenvolvimento (git): use git pull.")
    consulta = verificar(forcar=True)
    if consulta["status"] == "erro":
        raise RuntimeError("não foi possível consultar as versões. Confira a internet.")
    if consulta["status"] == "reiniciar":
        raise RuntimeError("feche o Pixel Lab IA e abra de novo pelo atalho; depois clique em "
                           "Atualizar agora.")
    if consulta["status"] != "nova":
        return {"status": "atual", "versao": consulta["atual"]}
    info = consulta["info"]
    atual = consulta["atual"]

    passo(0.1, f"Baixando a versão {info['versao']}…")
    dados = _baixar(f"{BASE}/versoes/{info['arquivo']}", timeout=120)
    passo(0.5, "Conferindo o pacote…")
    z, nomes = conferir_pacote(dados, info)

    antigos = _manifesto_local()
    # sem lista antiga (instalação feita por um zip antigo): guarda o que vai ser sobrescrito
    guardar = sorted(set(antigos or []) | {n for n in nomes if (ROOT / n).is_file()})
    passo(0.6, "Guardando uma cópia da versão atual…")
    copia = _copia_de_seguranca(atual, guardar)
    reqs_antes, modelos_antes = _requisitos(), _arquivos_de_modelos()
    passo(0.7, "Trocando os arquivos do programa…")
    try:
        mudaram = _aplicar(z, nomes, antigos)
    except Exception:
        _voltar(copia, nomes)
        raise
    # compara o conteúdo, não o caminho: numa reorganização os arquivos mudam de pasta
    pendente = {"de": atual, "para": info["versao"],
                "dependencias": _requisitos() != reqs_antes,
                "modelos": _arquivos_de_modelos() != modelos_antes}
    RUNTIME.mkdir(exist_ok=True)
    PENDENTE.write_text(json.dumps(pendente), encoding="utf-8")
    passo(1.0, "Pronto.")
    return {"status": "instalada", "versao": info["versao"], "arquivos": len(mudaram), **pendente}


def _ler(p: Path) -> bytes:
    return p.read_bytes() if p.is_file() else b""


def anterior() -> str | None:
    """Versão guardada em versoes-anteriores/, se houver."""
    pasta = _anteriores()
    if not pasta.is_dir():
        return None
    pastas = [p.name for p in pasta.iterdir() if (p / ".arquivos-guardados.txt").exists()]
    return pastas[0] if pastas else None


def restaurar() -> dict:
    """Volta para a versão guardada em versoes-anteriores/. O app deve fechar com o código 3."""
    versao = anterior()
    if not versao:
        raise RuntimeError("não há versão anterior guardada.")
    copia = _anteriores() / versao
    atual = versao_atual()
    reqs_antes = _requisitos()
    guardados = _guardados(copia)
    # lê tudo antes de mexer: se faltar algo na cópia, nada é apagado
    dados = {rel: (copia / rel).read_bytes() for rel in guardados if _caminho_seguro(rel)}
    apagados = []
    for rel in _manifesto_local() or []:
        p = ROOT / rel
        if rel not in guardados and p.is_file() and not _protegido(rel) and _caminho_seguro(rel):
            p.unlink()
            apagados.append(rel)
    _limpar_pastas(apagados)
    for rel, conteudo in dados.items():
        _gravar(ROOT / rel, conteudo)
    shutil.rmtree(copia.parent)
    pendente = {"de": atual, "para": versao, "restaurada": True,
                "dependencias": _requisitos() != reqs_antes, "modelos": False}
    RUNTIME.mkdir(exist_ok=True)
    PENDENTE.write_text(json.dumps(pendente), encoding="utf-8")
    return pendente


# ---------------- etapas com o app fechado (feitas pelo lançador) ----------------

def _python() -> str:
    exe = Path(sys.executable)
    if exe.name.lower() == "pythonw.exe":
        exe = exe.with_name("python.exe")
    return str(exe)


def _uv() -> str | None:
    dados = os.environ.get("REALCE_DADOS")
    for cand in ([Path(dados) / "uv" / ("uv.exe" if os.name == "nt" else "uv")] if dados else []):
        if cand.is_file():
            return str(cand)
    return shutil.which("uv")


def _rodar(cmd: list[str], log) -> None:
    flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    r = subprocess.run(cmd, cwd=str(_prog_atual()), stdout=log, stderr=subprocess.STDOUT,
                       creationflags=flags)
    if r.returncode:
        raise RuntimeError("não foi possível instalar os componentes novos (código "
                           f"{r.returncode}); detalhes em logs/atualizacao.log")


def _tirar_onnxruntime_comum(uv: str | None, log) -> bool:
    """No Windows, o onnxruntime comum dá lugar ao onnxruntime-directml (placa de vídeo). Os dois
    usam a mesma pasta: o comum sai antes da instalação das bibliotecas."""
    if os.name != "nt" or b"onnx-directml" not in _requisitos():
        return False
    import importlib.metadata as md

    try:
        md.distribution("onnxruntime")
    except md.PackageNotFoundError:
        return False
    _rodar(([uv, "pip", "uninstall", "--python", _python()] if uv
            else [_python(), "-m", "pip", "uninstall", "-y"]) + ["onnxruntime"], log)
    return True


def concluir_pendente(avisar=None) -> dict | None:
    """Instala bibliotecas e modelos novos, se a última atualização pediu. Se falhar, volta
    para a versão anterior. Chamado pelo lançador, com o servidor do app fechado."""
    if not PENDENTE.exists():
        return None
    pend = json.loads(PENDENTE.read_text(encoding="utf-8"))
    LOGS = _prog_atual() / "logs"
    LOGS.mkdir(exist_ok=True)
    limitar_log(LOGS / "atualizacao.log")
    with open(LOGS / "atualizacao.log", "a", encoding="utf-8") as log:
        log.write(time.strftime("\n%Y-%m-%d %H:%M:%S ") + json.dumps(pend) + "\n")
        log.flush()
        try:
            if pend.get("dependencias"):
                if avisar:
                    avisar("Instalando componentes novos…<br>Pode levar alguns minutos.")
                uv = _uv()
                bibliotecas = _prog_atual() / "bibliotecas"  # pacotes prontos levados no app
                extra = ["--find-links", str(bibliotecas)] if bibliotecas.is_dir() else []
                cmd = ([uv, "pip", "install", "--python", _python()] if uv
                       else [_python(), "-m", "pip", "install"])
                trocou = _tirar_onnxruntime_comum(uv, log)
                _rodar(cmd + ["-r", "requirements.txt", *extra], log)
                if trocou:
                    # os arquivos que eram dos dois saíram junto com o comum: instala de novo
                    _rodar(cmd + (["--reinstall"] if uv else ["--force-reinstall"])
                           + ["--no-deps", "onnxruntime-directml"], log)
            if pend.get("modelos"):
                if avisar:
                    avisar("Baixando modelos de IA novos…<br>Pode levar alguns minutos.")
                _rodar([_python(), "download_weights.py"], log)
        except Exception as e:  # noqa: BLE001 - qualquer falha volta para a versão anterior
            log.write(f"falhou: {e}\n")
            PENDENTE.unlink()
            if not pend.get("restaurada") and anterior():
                volta = restaurar()
                volta["dependencias"] = volta["modelos"] = False  # o ambiente antigo continua lá
                PENDENTE.unlink()
                ATUALIZADO.write_text(json.dumps({"falhou": pend["para"], "versao": volta["para"],
                                                  "erro": str(e)[:200]}), encoding="utf-8")
            return {"falhou": True, "erro": str(e)}
    PENDENTE.unlink()
    ATUALIZADO.write_text(json.dumps(pend), encoding="utf-8")
    return pend


def novidade_local() -> dict | None:
    """Resultado da última atualização, mostrado uma vez na tela depois de reabrir."""
    if not ATUALIZADO.exists():
        return None
    try:
        return json.loads(ATUALIZADO.read_text(encoding="utf-8"))
    finally:
        ATUALIZADO.unlink()
