"""Pessoas no vídeo: encontra cada pessoa e melhora cabeça e tronco combinando vários quadros.

Não usa modelo generativo: o detalhe a mais vem só dos quadros do próprio vídeo. Em pessoas
longe da câmera, o rosto continua sem traços (poucos pixels); roupa, boné e silhueta ganham
definição. Não serve para reconhecer quem é a pessoa.
"""

from dataclasses import dataclass

import cv2
import numpy as np
import torch

from .models import device
from .multiframe import fuse_region
from .vehicle import _detector
from .video import _iou, _open

PERSON = 1  # rótulo "pessoa" do COCO


@torch.inference_mode()
def detect_people(img_bgr: np.ndarray, min_score: float = 0.5) -> list[tuple[tuple, float]]:
    """Lista de ((x1, y1, x2, y2), confiança) para cada pessoa."""
    rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    x = torch.from_numpy(rgb).permute(2, 0, 1).float().div(255).to(device())
    out = _detector()([x])[0]
    return [(tuple(int(v) for v in b), float(s))
            for b, l, s in zip(out["boxes"].cpu().numpy(), out["labels"].cpu().numpy(),
                               out["scores"].cpu().numpy())
            if int(l) == PERSON and s >= min_score]


def upper_box(box: tuple) -> tuple:
    """Cabeça e tronco (x, y, w, h): a parte que muda menos de um quadro para o outro."""
    x1, y1, x2, y2 = box
    h = (y2 - y1) * 0.45
    return int(x1), int(y1), int(x2 - x1), max(int(h), 8)


@dataclass
class FoundPerson:
    start: float
    end: float
    t_best: float
    box_best: tuple  # x1, y1, x2, y2 no quadro t_best
    height: int      # altura da pessoa, em pixels, no melhor quadro
    thumb: np.ndarray
    candidates: list  # (t, caixa) de outros bons momentos, para a combinação de quadros


@dataclass
class _Track:
    box: tuple
    first: int
    last: int
    best: int
    best_box: tuple
    best_q: float
    thumb: np.ndarray
    hits: int = 1
    heights: list = None
    samples: list = None  # (quadro, caixa, qualidade)


def scan_people(src: str, every: int = 3, max_seconds: float | None = None,
                progress=None) -> list[FoundPerson]:
    """Segue cada pessoa pelo vídeo e guarda o quadro em que ela aparece maior e mais nítida."""
    cap, fps, total = _open(src, max_seconds)
    tracks: list[_Track] = []
    idx = 0
    while not total or idx < total:
        ok, frame = cap.read()
        if not ok:
            break
        if idx % every == 0:
            for box, score in detect_people(frame):
                match = max(tracks, key=lambda t: _iou(t.box, box), default=None)
                if match is None or _iou(match.box, box) < 0.2 or idx - match.last > every * 10:
                    match = _Track(box, idx, idx, idx, box, -1, None, 0)
                    tracks.append(match)
                match.box, match.last = box, idx
                match.hits += 1
                x1, y1, x2, y2 = box
                match.heights = (match.heights or []) + [y2 - y1]
                # caixa que cresce de repente costuma juntar a pessoa com outra coisa
                jump = len(match.heights) >= 3 and y2 - y1 > 1.35 * np.median(match.heights[-6:-1])
                crop = frame[max(y1, 0):y2, max(x1, 0):x2]
                sharp = cv2.Laplacian(cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY), cv2.CV_32F).var() \
                    if crop.size else 0
                # maior e mais nítida; pessoa cortada pela borda vale menos
                cut = x1 <= 4 or x2 >= frame.shape[1] - 4 or y2 >= frame.shape[0] - 4
                q = (y2 - y1) * score * (1 + min(sharp, 500) / 500) * (0.5 if cut else 1) \
                    * (0.3 if jump else 1)
                match.samples = (match.samples or []) + [(idx, box, q)]
                if q > match.best_q:
                    match.best, match.best_box, match.best_q = idx, box, q
                    match.thumb = crop.copy()
        idx += 1
        if progress and total:
            progress(idx / total, desc=f"Procurando pessoas: quadro {idx} de {total}")
    cap.release()
    return [FoundPerson(t.first / fps, t.last / fps, t.best / fps, t.best_box,
                        t.best_box[3] - t.best_box[1], t.thumb, _candidates(t, fps))
            for t in sorted(tracks, key=lambda t: t.first) if t.hits >= 3 and t.thumb is not None]


def _candidates(t: _Track, fps: float, parts: int = 3) -> list:
    """O melhor quadro e o melhor de cada trecho do caminho da pessoa.

    O quadro em que ela aparece maior nem sempre é bom para combinar: se ela está virando ou
    se abaixando, os quadros vizinhos não se alinham. Vale testar momentos diferentes.
    """
    out = [(t.best, t.best_box)]
    samples = t.samples or []
    for k in range(parts):
        chunk = samples[k * len(samples) // parts:(k + 1) * len(samples) // parts]
        if chunk:
            i, box, _ = max(chunk, key=lambda s: s[2])
            if all(abs(i - j) > 6 for j, _ in out):
                out.append((i, box))
    return [(i / fps, box) for i, box in out]


def enhance_best(src: str, person: FoundPerson, progress=None):
    """Combina quadros em cada bom momento da pessoa e fica com o que aproveitou mais quadros."""
    best = None
    for k, (t, box) in enumerate(person.candidates):
        if progress:
            progress(0.1 + 0.8 * k / len(person.candidates),
                     desc=f"Combinando quadros: momento {k + 1} de {len(person.candidates)}")
        r = enhance_person(src, t, box)
        # mais quadros aproveitados vence; empate fica com a pessoa maior
        key = (r.used, r.roi[3])
        if best is None or key > best[0]:
            best = key, r, t
    return best[1], best[2]


def enhance_person(src: str, t: float, box: tuple, n: int = 15, scale: int = 4):
    """Cabeça e tronco da pessoa, combinando os quadros em torno do instante t."""
    from .multiframe import read_frames

    frames, ref_i, _ = read_frames(src, t, n)
    ref = frames[ref_i]
    # a pessoa no quadro de referência: a detecção mais parecida com a caixa escolhida
    dets = detect_people(ref, 0.3)
    if dets:
        near = max(dets, key=lambda d: _iou(d[0], box))
        if _iou(near[0], box) > 0.3:
            box = near[0]
    region = upper_box(box)
    anchor = np.array([region[0] + region[2] / 2, region[1] + region[3] / 2])
    top = np.array([(box[0] + box[2]) / 2, box[1]])  # meio do topo da caixa
    offset = anchor - top

    boxes = {}
    prev = box
    for i in range(ref_i + 1, len(frames)), range(ref_i - 1, -1, -1):
        prev = box
        for j in i:
            d = detect_people(frames[j], 0.3)
            if d:
                cand = max(d, key=lambda d: _iou(d[0], prev))
                if _iou(cand[0], prev) > 0.2:
                    prev = cand[0]
                    boxes[id(frames[j])] = prev

    def centers(frame):
        b = boxes.get(id(frame))
        return [np.array([(b[0] + b[2]) / 2, b[1]]) + offset] if b else []

    # quadros sem a pessoa (ou com outra) seriam descartados pelo alinhamento, mas custam tempo
    keep = [k for k in range(len(frames)) if k == ref_i or id(frames[k]) in boxes]
    return fuse_region([frames[k] for k in keep], keep.index(ref_i), region, centers, scale=scale, margin=(0.35, 0.25))
