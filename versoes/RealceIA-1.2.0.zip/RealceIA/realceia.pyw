"""Abre o RealceIA numa janela própria, como um programa comum.

Uso: dois cliques no atalho "RealceIA" (criado pelo instalar.bat), ou
     .venv\\Scripts\\pythonw.exe realceia.pyw [--navegador]
--navegador abre no navegador padrão em vez da janela própria.

O app (app.py) roda num processo à parte, só neste computador (127.0.0.1). Se ele sair com o
código 3 (atualização instalada), este lançador conclui a atualização e o abre de novo, já
com a versão nova. Se ele cair, abre de novo em 2 s, até 5 vezes em 10 minutos.
"""

import os
import socket
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
# mesma pasta de dados usada pelo instalador (modelos compartilhados entre instalações)
if sys.platform == "win32" and os.environ.get("LOCALAPPDATA"):
    os.environ.setdefault("REALCE_DADOS", str(Path(os.environ["LOCALAPPDATA"]) / "RealceIA"))
sys.path.insert(0, str(ROOT))

# sem console (pythonw), as mensagens vão para logs/realceia.log
LOGS = ROOT / "logs"
LOGS.mkdir(exist_ok=True)
LOG_FILE = LOGS / "realceia.log"
if sys.stdout is None or sys.executable.lower().endswith("pythonw.exe"):
    sys.stdout = sys.stderr = open(LOG_FILE, "w", encoding="utf-8", buffering=1)

# mesmas cores do app (tema escuro, verde-azulado), para a abertura não "piscar" outra identidade
BG = "#0b1716"
PAGE = """<!doctype html><html><head><meta charset="utf-8"><style>
body{{margin:0;height:100vh;display:flex;align-items:center;justify-content:center;
font-family:"Segoe UI",system-ui,sans-serif;background:#0b1716;color:#e6f1ee}}
.box{{text-align:center;max-width:560px;padding:24px}}
.logo{{width:64px;height:64px;margin:0 auto 18px;border-radius:16px;background:#41d1b6;
color:#05231d;display:flex;align-items:center;justify-content:center}}
.logo svg{{width:36px;height:36px}}
h1{{font-size:38px;margin:0 0 6px;letter-spacing:-.02em}}
p{{font-size:16px;line-height:1.55;color:#93ada8}}
.tag{{margin:0;font-size:17px}}
.spin{{width:36px;height:36px;margin:26px auto 14px;border:3px solid #22413c;
border-top-color:#41d1b6;border-radius:50%;animation:s .9s linear infinite}}
@keyframes s{{to{{transform:rotate(360deg)}}}}
.err{{color:#e6f1ee}}
code{{background:#152b28;border:1px solid #22413c;color:#e6f1ee;padding:2px 6px;
border-radius:6px;word-break:break-all}}
</style></head><body><div class="box">{body}</div></body></html>"""

TITLE = "RealceIA — Melhoria de imagens e vídeos, rostos e placas"
LOGO = ('<div class="logo"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" '
        'stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" '
        'r="7"/><path d="m21 21-4.3-4.3"/><path d="M11 8v6M8 11h6"/></svg></div>')
HEADER = LOGO + "<h1>RealceIA</h1><p class='tag'>Melhoria de imagens e vídeos, rostos e placas</p>"

LOADING = PAGE.format(body=HEADER + "<div class='spin'></div>"
                           "<p>Carregando os modelos de IA…<br>"
                           "A primeira abertura pode levar até 1 minuto.</p>")


def error_page(msg: str) -> str:
    return PAGE.format(body=HEADER + f"<p class='err'>Não foi possível iniciar o app.</p>"
                            f"<p><code>{msg}</code></p>"
                            f"<p>Detalhes em <code>{LOGS / 'servidor.log'}</code></p>")


def message_page(msg: str) -> str:
    return PAGE.format(body=HEADER + f"<div class='spin'></div><p>{msg}</p>")


SAIR_PARA_ATUALIZAR = 3
MAX_QUEDAS, JANELA_QUEDAS = 5, 600  # até 5 quedas em 10 minutos


def free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


class Server:
    """O app num processo à parte, que pode ser reaberto sem fechar a janela."""

    def __init__(self, show):
        self.port = free_port()  # a mesma porta em todas as reaberturas: a página só recarrega
        self.url = f"http://127.0.0.1:{self.port}"
        self.show = show          # show(html=None, url=None): atualiza a janela ou o navegador
        self.proc = None
        self.closing = False
        self.falls: list[float] = []

    def start(self) -> bool:
        py = sys.executable  # pythonw.exe no Windows: o servidor também roda sem janela preta
        log = open(LOGS / "servidor.log", "a", encoding="utf-8")
        log.write(time.strftime("\n==== %Y-%m-%d %H:%M:%S ====\n"))
        log.flush()
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        self.proc = subprocess.Popen([py, str(ROOT / "app.py"), "--porta", str(self.port)],
                                     cwd=str(ROOT), stdout=log, stderr=subprocess.STDOUT,
                                     creationflags=flags)
        deadline = time.time() + 300  # a primeira abertura carrega bibliotecas pesadas
        while time.time() < deadline:
            if self.proc.poll() is not None:
                return False
            try:
                urllib.request.urlopen(self.url + "/api/saude", timeout=2)
                return True
            except OSError:
                time.sleep(0.4)
        return False

    def finish_update(self):
        """Bibliotecas e modelos novos pedidos pela atualização, com o app fechado."""
        from realce import atualizacao

        try:
            r = atualizacao.concluir_pendente(lambda m: self.show(html=message_page(m)))
        except Exception:  # noqa: BLE001 - o app abre mesmo assim
            traceback.print_exc()
            return "Abrindo o RealceIA…"
        if r and r.get("falhou"):
            return "A atualização não deu certo e o RealceIA voltou para a versão anterior.<br>Abrindo…"
        return "Abrindo a versão nova…"

    def run(self):
        """Abre o app e o mantém aberto até a janela fechar."""
        self.finish_update()  # se uma atualização ficou pela metade, conclui antes
        while not self.closing:
            if not self.start():
                code = self.proc.poll()
                if self.closing:
                    return
                if not self._may_retry():
                    self.show(html=error_page(f"o app parou ao abrir (código {code})."))
                    return
                time.sleep(2)
                continue
            self.show(url=self.url)
            code = self.proc.wait()
            if self.closing:
                return
            print("app saiu com código", code, flush=True)
            if code == SAIR_PARA_ATUALIZAR:
                self.show(html=message_page("Aplicando a atualização…"))
                self.show(html=message_page(self.finish_update()))
                continue
            if not self._may_retry():
                self.show(html=error_page(f"o app parou {MAX_QUEDAS} vezes em pouco tempo "
                                          f"(último código {code})."))
                return
            self.show(html=message_page("O app parou inesperadamente. Abrindo de novo…"))
            time.sleep(2)

    def _may_retry(self) -> bool:
        now = time.time()
        self.falls = [t for t in self.falls if now - t < JANELA_QUEDAS] + [now]
        return len(self.falls) <= MAX_QUEDAS

    def stop(self):
        self.closing = True
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(5)
            except subprocess.TimeoutExpired:
                self.proc.kill()


def main():
    use_browser = "--navegador" in sys.argv
    webview = None
    if not use_browser:
        try:
            import webview
        except ImportError:
            print("pywebview não instalado; abrindo no navegador.", flush=True)

    if webview is None:
        opened = []

        def show(html=None, url=None):
            if html:
                print(html.split("<p>")[-1].split("</p>")[0].replace("<br>", " "), flush=True)
            if url and not opened:  # nas reaberturas a própria página recarrega
                opened.append(url)
                webbrowser.open(url)
                print("RealceIA em", url, flush=True)

        server = Server(show)
        try:
            server.run()  # feche pela janela de comandos (Ctrl+C)
        except KeyboardInterrupt:
            server.stop()
        return

    webview.settings["ALLOW_DOWNLOADS"] = True  # permite baixar os resultados
    window = webview.create_window(TITLE, html=LOADING, width=1400, height=900,
                                   min_size=(900, 600), text_select=True,
                                   background_color=BG)

    def show(html=None, url=None):
        if url:
            window.load_url(url)
        elif html:
            window.load_html(html)

    server = Server(show)
    window.events.closed += server.stop

    def worker():
        try:
            server.run()
        except Exception as e:  # noqa: BLE001 - mostrar qualquer falha ao usuário
            traceback.print_exc()
            window.load_html(error_page(str(e)[:300]))

    webview.start(lambda: threading.Thread(target=worker, daemon=True).start())
    # janela fechada: encerra tudo, inclusive o servidor
    server.stop()
    os._exit(0)


if __name__ == "__main__":
    main()
