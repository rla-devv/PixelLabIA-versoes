// RealceIA: tema, navegação pelos cartões e balões de ajuda (?).
(function () {
  const THEME_KEY = "realceia-tema";

  // ---------- tema ----------
  function applyTheme(mode) {
    document.body.classList.toggle("dark", mode === "dark");
    document.querySelectorAll("[data-action=theme] span").forEach((s) => {
      s.textContent = mode === "dark" ? "Tema claro" : "Tema escuro";
    });
  }
  function savedTheme() {
    try { return localStorage.getItem(THEME_KEY) || "dark"; } catch (e) { return "dark"; }
  }
  function toggleTheme() {
    const next = document.body.classList.contains("dark") ? "light" : "dark";
    try { localStorage.setItem(THEME_KEY, next); } catch (e) { /* sem armazenamento */ }
    applyTheme(next);
  }

  // ---------- navegação ----------
  function openTool(id, scroll) {
    const tab = document.querySelector(`#tools [role=tab][data-tab-id="${id}"]`);
    if (tab) tab.click();
    document.querySelectorAll(".rl-card[data-tab]").forEach((c) => {
      const on = c.dataset.tab === id;
      c.classList.toggle("active", on);
      c.setAttribute("aria-pressed", on ? "true" : "false");
    });
    if (scroll) {
      const panel = document.getElementById("tools");
      if (panel) panel.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  // ---------- balões de ajuda ----------
  let tip, tipOwner = null;
  function ensureTip() {
    if (!tip) {
      tip = document.createElement("div");
      tip.id = "rl-tip";
      tip.setAttribute("role", "tooltip");
      document.body.appendChild(tip);
    }
    return tip;
  }
  function showTip(btn) {
    const t = ensureTip();
    t.textContent = btn.dataset.tip;
    t.classList.add("show");
    tipOwner = btn;
    btn.setAttribute("aria-expanded", "true");
    const r = btn.getBoundingClientRect();
    const w = t.offsetWidth, h = t.offsetHeight;
    let left = Math.min(Math.max(8, r.left + r.width / 2 - w / 2), window.innerWidth - w - 8);
    let top = r.bottom + 8;
    if (top + h > window.innerHeight - 8) top = r.top - h - 8;
    t.style.left = left + "px";
    t.style.top = top + "px";
  }
  function hideTip() {
    if (tip) tip.classList.remove("show");
    if (tipOwner) tipOwner.setAttribute("aria-expanded", "false");
    tipOwner = null;
  }
  function labelOf(el) {
    return el.querySelector("[data-testid=block-info]")
      || el.querySelector(".label-text")
      || el.querySelector("label[data-testid=block-label]")
      || el.querySelector("label");
  }
  function attachHelp() {
    const help = (window.REALCE || {}).help || {};
    for (const [id, text] of Object.entries(help)) {
      const el = document.getElementById(id);
      if (!el || el.dataset.rlHelp) continue;
      const label = labelOf(el);
      if (!label) continue;
      const b = document.createElement("button");
      b.type = "button";
      b.className = "rl-help";
      b.textContent = "?";
      b.dataset.tip = text;
      b.setAttribute("aria-label", "Ajuda: " + text);
      b.setAttribute("aria-expanded", "false");
      label.appendChild(b);
      el.dataset.rlHelp = "1";
    }
  }

  // ---------- atualização automática ----------
  // O servidor do app consulta o repositório de versões (GET /api/atualizacao) e instala
  // (POST). Depois de instalar, o app fecha com o código 3 e o lançador o abre de novo.
  const DISMISS_KEY = "realceia-agora-nao";
  const close = '<button class="rl-btn rl-btn-ghost" type="button" data-action="update-close">Fechar</button>';
  let last = null;      // última resposta da consulta
  let installing = false;
  function esc(t) {
    return String(t).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  }
  function box(html) {
    const el = document.getElementById("rl-update");
    if (!el) return;
    el.innerHTML = html;
    el.classList.add("open");
  }
  function hideBox() { document.getElementById("rl-update")?.classList.remove("open"); }
  function dismissed(v) { try { return localStorage.getItem(DISMISS_KEY) === v; } catch (e) { return false; } }
  function dismiss(v) { try { localStorage.setItem(DISMISS_KEY, v); } catch (e) { /* sem armazenamento */ } }
  function kb(n) { return n ? ` (${Math.max(1, Math.round(n / 1024))} KB)` : ""; }
  function backRow(r) {
    return r && r.anterior
      ? `<p class="rl-upd-back">Algo piorou? <button class="rl-link" type="button" data-action="update-restore">Voltar para a versão ${esc(r.anterior)}</button></p>`
      : "";
  }
  function newsHtml(r) {
    return `<p><b>Nova versão do RealceIA: ${esc(r.versao)}</b> (você usa a ${esc(r.atual)}).</p>` +
      (r.novidades ? `<p>${esc(r.novidades).replace(/\n/g, "<br>")}</p>` : "") +
      `<p class="rl-muted">Só o programa é trocado${kb(r.tamanho)}. Modelos de IA e arquivos não são tocados. ` +
      "O RealceIA fecha e abre de novo sozinho.</p>" +
      '<div class="rl-row"><button class="rl-btn rl-btn-solid" type="button" data-action="update-now">Atualizar agora</button>' +
      '<button class="rl-btn rl-btn-ghost" type="button" data-action="update-later">Agora não</button></div>';
  }
  async function api(path, opts) {
    const r = await fetch(path, Object.assign({ cache: "no-store" }, opts || {}));
    let data = {};
    try { data = await r.json(); } catch (e) { /* resposta sem JSON */ }
    if (!r.ok) throw Object.assign(new Error(data.erro || "http-" + r.status), { data: data, server: true });
    return data;
  }
  // consulta automática: ao abrir e a cada 15 min; avisa só se houver versão nova
  async function autoCheck() {
    if (installing) return;
    try {
      const r = await api("/api/atualizacao");
      last = r;
      if (r.status === "nova" && !dismissed(r.versao)) box(newsHtml(r));
    } catch (e) { /* sem internet ou servidor ocupado: tenta de novo mais tarde */ }
  }
  // botão "Buscar atualização": consulta na hora e sempre responde
  async function checkUpdate() {
    box("<p>Procurando versões novas…</p>");
    try {
      const r = await api("/api/atualizacao?forcar=1");
      last = r;
      if (r.status === "nova") box(newsHtml(r));
      else if (r.status === "atual") box(`<p><b>Você já usa a versão mais recente (${esc(r.atual)}).</b></p>${backRow(r)}<div class="rl-row">${close}</div>`);
      else if (r.status === "dev") box(`<p><b>Esta pasta é uma cópia de desenvolvimento (git).</b> Atualize com <code>git pull</code>.</p><div class="rl-row">${close}</div>`);
      else box("<p><b>Não foi possível consultar as versões agora.</b> Confira a conexão com a internet e tente de novo.</p>" + `${backRow(r)}<div class="rl-row">${close}</div>`);
    } catch (e) {
      box(serverDown());
    }
  }
  function serverDown() {
    return "<p><b>O RealceIA não respondeu.</b> Feche a janela e abra de novo pelo atalho. " +
      "Se continuar, rode o <code>instalar.bat</code> da pasta do programa.</p>" + `<div class="rl-row">${close}</div>`;
  }
  async function waitRestart(version) {
    // o app fecha e o lançador o abre de novo; espera responder com a versão nova
    const start = Date.now();
    await new Promise((ok) => setTimeout(ok, 2500));
    while (Date.now() - start < 15 * 60 * 1000) {
      try {
        const r = await api("/api/saude");
        if (!version || r.versao === version) { location.reload(); return; }
      } catch (e) { /* ainda reiniciando */ }
      await new Promise((ok) => setTimeout(ok, 1500));
    }
    box("<p><b>O RealceIA demorou para voltar.</b> Feche a janela e abra de novo pelo atalho.</p>");
  }
  async function install(path, label) {
    if (installing) return;
    installing = true;
    box(`<p><b>${label}</b> Não feche o RealceIA.</p><div class="rl-spin" aria-hidden="true"></div>`);
    try {
      const r = await api(path, { method: "POST" });
      if (r.status === "atual") {
        installing = false;
        box(`<p><b>Você já usa a versão mais recente (${esc(r.versao)}).</b></p><div class="rl-row">${close}</div>`);
        return;
      }
      const extra = r.dependencias || r.modelos
        ? " Ela traz componentes novos: pode levar alguns minutos."
        : "";
      box(`<p><b>Versão ${esc(r.para)} instalada.</b> O RealceIA está reabrindo…${extra}</p><div class="rl-spin" aria-hidden="true"></div>`);
      waitRestart(r.para);
    } catch (e) {
      installing = false;
      box(e.server
        ? `<p><b>${esc(e.message)}</b></p><div class="rl-row">${close}</div>`
        : serverDown());
    }
  }
  // depois de reabrir: conta o que aconteceu na última atualização
  async function afterRestart() {
    try {
      const r = await api("/api/atualizacao/resultado");
      if (r.falhou) {
        box(`<p><b>A versão ${esc(r.falhou)} não pôde ser concluída</b> e o RealceIA voltou para a ${esc(r.versao)}. Detalhe: ${esc(r.erro || "")}</p>` +
            "<p>Tente de novo mais tarde ou rode o <code>instalar.bat</code>. O registro fica em <code>logs\\atualizacao.log</code>.</p>" +
            `<div class="rl-row">${close}</div>`);
      } else if (r.para) {
        const what = r.restaurada ? `Voltou para a versão ${esc(r.para)}.` : `RealceIA atualizado para a versão ${esc(r.para)}.`;
        toast(what);
      }
    } catch (e) { /* nada a mostrar */ }
  }

  // ---------- colar imagem (Ctrl+V), ex.: recorte do Windows (Win+Shift+S) ----------
  let lastImageBox = null;  // último campo de imagem em que o mouse passou ou que recebeu clique
  function imageInput(box) {
    return box && box.querySelector('input[type=file][accept^="image"]');
  }
  function visibleImageInput() {
    if (lastImageBox && lastImageBox.offsetParent !== null && imageInput(lastImageBox)) {
      return imageInput(lastImageBox);
    }
    const panels = [...document.querySelectorAll('#tools [role=tabpanel]')]
      .filter((p) => p.offsetParent !== null);
    for (const p of panels) {
      const inp = p.querySelector('input[type=file][accept^="image"]');
      if (inp) return inp;
    }
    return null;
  }
  function toast(msg) {
    let t = document.getElementById("rl-toast");
    if (!t) {
      t = document.createElement("div");
      t.id = "rl-toast";
      t.setAttribute("role", "status");
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add("show");
    clearTimeout(t._h);
    t._h = setTimeout(() => t.classList.remove("show"), 2600);
  }
  document.addEventListener("paste", (ev) => {
    const items = [...((ev.clipboardData && ev.clipboardData.items) || [])];
    const item = items.find((i) => i.kind === "file" && i.type.startsWith("image/"));
    if (!item) return;  // texto: deixa colar normalmente
    const blob = item.getAsFile();
    if (!blob) return;
    ev.preventDefault();
    const input = visibleImageInput();
    if (!input) {
      toast("Esta ferramenta trabalha com vídeo. Para colar uma imagem, abra Melhorar foto, Rostos ou Ler placas.");
      return;
    }
    const ext = (blob.type.split("/")[1] || "png").replace("jpeg", "jpg");
    const file = new File([blob], `recorte-colado.${ext}`, { type: blob.type });
    const dt = new DataTransfer();
    dt.items.add(file);
    input.files = dt.files;
    input.dispatchEvent(new Event("change", { bubbles: true }));
    toast("Imagem colada.");
  });
  document.addEventListener("pointerover", (ev) => {
    const box = ev.target.closest && ev.target.closest("[id$=_img]");
    if (box && imageInput(box)) lastImageBox = box;
  });

  // ---------- eventos ----------
  document.addEventListener("click", (ev) => {
    const help = ev.target.closest(".rl-help");
    if (help) {
      // não deixa o clique marcar a caixa ou abrir o seletor de arquivo
      ev.preventDefault();
      ev.stopPropagation();
      if (tipOwner === help) hideTip(); else showTip(help);
      return;
    }
    hideTip();
    const act = ev.target.closest("[data-action]");
    if (act) {
      const a = act.dataset.action;
      if (a === "theme") toggleTheme();
      if (a === "donate") document.getElementById("rl-donate")?.classList.toggle("open");
      if (a === "donate-close") document.getElementById("rl-donate")?.classList.remove("open");
      if (a === "update") checkUpdate();
      if (a === "update-now") install("/api/atualizacao", "Baixando e instalando a versão nova…");
      if (a === "update-restore") install("/api/atualizacao/restaurar", "Voltando para a versão anterior…");
      if (a === "update-later") {
        if (last && last.versao) dismiss(last.versao);  // o botão Buscar atualização mostra de novo
        hideBox();
      }
      if (a === "update-close") hideBox();
    }
    const card = ev.target.closest(".rl-card[data-tab]");
    if (card) openTool(card.dataset.tab, true);
  }, true);
  document.addEventListener("mouseover", (ev) => {
    const help = ev.target.closest && ev.target.closest(".rl-help");
    if (help && tipOwner !== help) showTip(help);
  });
  document.addEventListener("mouseout", (ev) => {
    const help = ev.target.closest && ev.target.closest(".rl-help");
    if (help && !help.contains(ev.relatedTarget)) hideTip();
  });
  document.addEventListener("focusin", (ev) => {
    if (ev.target.classList && ev.target.classList.contains("rl-help")) showTip(ev.target);
  });
  document.addEventListener("focusout", (ev) => {
    if (ev.target.classList && ev.target.classList.contains("rl-help")) hideTip();
  });
  document.addEventListener("keydown", (ev) => { if (ev.key === "Escape") hideTip(); });
  window.addEventListener("scroll", hideTip, true);

  let observer = null;
  let updateTimer = null;
  function init() {
    applyTheme(savedTheme());
    if (!observer) {
      observer = new MutationObserver(attachHelp);
      observer.observe(document.body, { childList: true, subtree: true });
    }
    attachHelp();
    const first = document.querySelector(".rl-card[data-tab]");
    if (first) openTool(first.dataset.tab, false);
    // só depois que o Gradio montou o cabeçalho (onde fica o aviso)
    if (!updateTimer && document.getElementById("rl-update")) {
      afterRestart();
      autoCheck();
      updateTimer = setInterval(autoCheck, 15 * 60 * 1000);
    }
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
  // o Gradio monta a página depois: repete quando os cartões aparecerem
  const wait = setInterval(() => {
    if (document.querySelector(".rl-card[data-tab]") && document.querySelector("#tools [role=tab]")) {
      clearInterval(wait);
      init();
    }
  }, 200);
})();
