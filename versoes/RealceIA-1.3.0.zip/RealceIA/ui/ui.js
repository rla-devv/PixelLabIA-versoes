// RealceIA: tema, navegação pelos cartões e balões de ajuda (?).
(function () {
  const THEME_KEY = "realceia-tema";

  // ---------- tema ----------
  function applyTheme(mode) {
    document.body.classList.toggle("dark", mode === "dark");
    document.querySelectorAll("[data-action=theme] span").forEach((s) => {
      s.textContent = mode === "dark" ? "Tema claro" : "Tema escuro";
    });
  }
  function savedTheme() {
    try { return localStorage.getItem(THEME_KEY) || "dark"; } catch (e) { return "dark"; }
  }
  function toggleTheme() {
    const next = document.body.classList.contains("dark") ? "light" : "dark";
    try { localStorage.setItem(THEME_KEY, next); } catch (e) { /* sem armazenamento */ }
    applyTheme(next);
  }

  // ---------- navegação ----------
  function openTool(id, scroll) {
    const tab = document.querySelector(`#tools [role=tab][data-tab-id="${id}"]`);
    if (tab) tab.click();
    document.querySelectorAll(".rl-card[data-tab]").forEach((c) => {
      const on = c.dataset.tab === id;
      c.classList.toggle("active", on);
      c.setAttribute("aria-pressed", on ? "true" : "false");
    });
    if (scroll) {
      const panel = document.getElementById("tools");
      if (panel) panel.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  // ---------- balões de ajuda ----------
  let tip, tipOwner = null;
  function ensureTip() {
    if (!tip) {
      tip = document.createElement("div");
      tip.id = "rl-tip";
      tip.setAttribute("role", "tooltip");
      document.body.appendChild(tip);
    }
    return tip;
  }
  function showTip(btn) {
    const t = ensureTip();
    t.textContent = btn.dataset.tip;
    t.classList.add("show");
    tipOwner = btn;
    btn.setAttribute("aria-expanded", "true");
    const r = btn.getBoundingClientRect();
    const w = t.offsetWidth, h = t.offsetHeight;
    let left = Math.min(Math.max(8, r.left + r.width / 2 - w / 2), window.innerWidth - w - 8);
    let top = r.bottom + 8;
    if (top + h > window.innerHeight - 8) top = r.top - h - 8;
    t.style.left = left + "px";
    t.style.top = top + "px";
  }
  function hideTip() {
    if (tip) tip.classList.remove("show");
    if (tipOwner) tipOwner.setAttribute("aria-expanded", "false");
    tipOwner = null;
  }
  function labelOf(el) {
    return el.querySelector("[data-testid=block-info]")
      || el.querySelector(".label-text")
      || el.querySelector("label[data-testid=block-label]")
      || el.querySelector("label");
  }
  function attachHelp() {
    const help = (window.REALCE || {}).help || {};
    for (const [id, text] of Object.entries(help)) {
      const el = document.getElementById(id);
      if (!el || el.dataset.rlHelp) continue;
      const label = labelOf(el);
      if (!label) continue;
      const b = document.createElement("button");
      b.type = "button";
      b.className = "rl-help";
      b.textContent = "?";
      b.dataset.tip = text;
      b.setAttribute("aria-label", "Ajuda: " + text);
      b.setAttribute("aria-expanded", "false");
      label.appendChild(b);
      el.dataset.rlHelp = "1";
    }
  }

  // ---------- atualização automática ----------
  // O servidor do app consulta o repositório de versões (GET /api/atualizacao) e instala
  // (POST). Depois de instalar, o app fecha com o código 3 e o lançador o abre de novo.
  const DISMISS_KEY = "realceia-agora-nao";
  const close = '<button class="rl-btn rl-btn-ghost" type="button" data-action="update-close">Fechar</button>';
  let last = null;      // última resposta da consulta
  let installing = false;
  function esc(t) {
    return String(t).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  }
  function box(html) {
    const el = document.getElementById("rl-update");
    if (!el) return;
    el.innerHTML = html;
    el.classList.add("open");
  }
  function hideBox() { document.getElementById("rl-update")?.classList.remove("open"); }
  function dismissed(v) { try { return localStorage.getItem(DISMISS_KEY) === v; } catch (e) { return false; } }
  function dismiss(v) { try { localStorage.setItem(DISMISS_KEY, v); } catch (e) { /* sem armazenamento */ } }
  function kb(n) { return n ? ` (${Math.max(1, Math.round(n / 1024))} KB)` : ""; }
  function backRow(r) {
    return r && r.anterior
      ? `<p class="rl-upd-back">Algo piorou? <button class="rl-link" type="button" data-action="update-restore">Voltar para a versão ${esc(r.anterior)}</button></p>`
      : "";
  }
  function newsHtml(r) {
    return `<p><b>Nova versão do RealceIA: ${esc(r.versao)}</b> (você usa a ${esc(r.atual)}).</p>` +
      (r.novidades ? `<p>${esc(r.novidades).replace(/\n/g, "<br>")}</p>` : "") +
      `<p class="rl-muted">Só o programa é trocado${kb(r.tamanho)}. Modelos de IA e arquivos não são tocados. ` +
      "O RealceIA fecha e abre de novo sozinho.</p>" +
      '<div class="rl-row"><button class="rl-btn rl-btn-solid" type="button" data-action="update-now">Atualizar agora</button>' +
      '<button class="rl-btn rl-btn-ghost" type="button" data-action="update-later">Agora não</button></div>';
  }
  async function api(path, opts) {
    const r = await fetch(path, Object.assign({ cache: "no-store" }, opts || {}));
    let data = {};
    try { data = await r.json(); } catch (e) { /* resposta sem JSON */ }
    if (!r.ok) throw Object.assign(new Error(data.erro || "http-" + r.status), { data: data, server: true });
    return data;
  }
  // consulta automática: ao abrir e a cada 15 min; avisa só se houver versão nova
  async function autoCheck() {
    if (installing) return;
    try {
      const r = await api("/api/atualizacao");
      last = r;
      if (r.status === "nova" && !dismissed(r.versao)) box(newsHtml(r));
    } catch (e) { /* sem internet ou servidor ocupado: tenta de novo mais tarde */ }
  }
  // botão "Buscar atualização": consulta na hora e sempre responde
  async function checkUpdate() {
    box("<p>Procurando versões novas…</p>");
    try {
      const r = await api("/api/atualizacao?forcar=1");
      last = r;
      if (r.status === "nova") box(newsHtml(r));
      else if (r.status === "atual") box(`<p><b>Você já usa a versão mais recente (${esc(r.atual)}).</b></p>${backRow(r)}<div class="rl-row">${close}</div>`);
      else if (r.status === "dev") box(`<p><b>Esta pasta é uma cópia de desenvolvimento (git).</b> Atualize com <code>git pull</code>.</p><div class="rl-row">${close}</div>`);
      else box("<p><b>Não foi possível consultar as versões agora.</b> Confira a conexão com a internet e tente de novo.</p>" + `${backRow(r)}<div class="rl-row">${close}</div>`);
    } catch (e) {
      box(serverDown());
    }
  }
  function serverDown() {
    return "<p><b>O RealceIA não respondeu.</b> Feche a janela e abra de novo pelo atalho. " +
      "Se continuar, rode o <code>instalar.bat</code> da pasta do programa.</p>" + `<div class="rl-row">${close}</div>`;
  }
  async function waitRestart(version) {
    // o app fecha e o lançador o abre de novo; espera responder com a versão nova
    const start = Date.now();
    await new Promise((ok) => setTimeout(ok, 2500));
    while (Date.now() - start < 15 * 60 * 1000) {
      try {
        const r = await api("/api/saude");
        if (!version || r.versao === version) { location.reload(); return; }
      } catch (e) { /* ainda reiniciando */ }
      await new Promise((ok) => setTimeout(ok, 1500));
    }
    box("<p><b>O RealceIA demorou para voltar.</b> Feche a janela e abra de novo pelo atalho.</p>");
  }
  async function install(path, label) {
    if (installing) return;
    installing = true;
    box(`<p><b>${label}</b> Não feche o RealceIA.</p><div class="rl-spin" aria-hidden="true"></div>`);
    try {
      const r = await api(path, { method: "POST" });
      if (r.status === "atual") {
        installing = false;
        box(`<p><b>Você já usa a versão mais recente (${esc(r.versao)}).</b></p><div class="rl-row">${close}</div>`);
        return;
      }
      const extra = r.dependencias || r.modelos
        ? " Ela traz componentes novos: pode levar alguns minutos."
        : "";
      box(`<p><b>Versão ${esc(r.para)} instalada.</b> O RealceIA está reabrindo…${extra}</p><div class="rl-spin" aria-hidden="true"></div>`);
      waitRestart(r.para);
    } catch (e) {
      installing = false;
      box(e.server
        ? `<p><b>${esc(e.message)}</b></p><div class="rl-row">${close}</div>`
        : serverDown());
    }
  }
  // depois de reabrir: conta o que aconteceu na última atualização
  async function afterRestart() {
    try {
      const r = await api("/api/atualizacao/resultado");
      if (r.falhou) {
        box(`<p><b>A versão ${esc(r.falhou)} não pôde ser concluída</b> e o RealceIA voltou para a ${esc(r.versao)}. Detalhe: ${esc(r.erro || "")}</p>` +
            "<p>Tente de novo mais tarde ou rode o <code>instalar.bat</code>. O registro fica em <code>logs\\atualizacao.log</code>.</p>" +
            `<div class="rl-row">${close}</div>`);
      } else if (r.para) {
        const what = r.restaurada ? `Voltou para a versão ${esc(r.para)}.` : `RealceIA atualizado para a versão ${esc(r.para)}.`;
        toast(what);
      }
    } catch (e) { /* nada a mostrar */ }
  }

  // ---------- colar imagem (Ctrl+V), ex.: recorte do Windows (Win+Shift+S) ----------
  let lastImageBox = null;  // último campo de imagem em que o mouse passou ou que recebeu clique
  function imageInput(box) {
    return box && box.querySelector('input[type=file][accept^="image"]');
  }
  function visibleImageInput() {
    if (lastImageBox && lastImageBox.offsetParent !== null && imageInput(lastImageBox)) {
      return imageInput(lastImageBox);
    }
    const panels = [...document.querySelectorAll('#tools [role=tabpanel]')]
      .filter((p) => p.offsetParent !== null);
    for (const p of panels) {
      const inp = p.querySelector('input[type=file][accept^="image"]');
      if (inp) return inp;
    }
    return null;
  }
  function toast(msg) {
    let t = document.getElementById("rl-toast");
    if (!t) {
      t = document.createElement("div");
      t.id = "rl-toast";
      t.setAttribute("role", "status");
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add("show");
    clearTimeout(t._h);
    t._h = setTimeout(() => t.classList.remove("show"), 2600);
  }
  document.addEventListener("paste", (ev) => {
    const items = [...((ev.clipboardData && ev.clipboardData.items) || [])];
    const item = items.find((i) => i.kind === "file" && i.type.startsWith("image/"));
    if (!item) return;  // texto: deixa colar normalmente
    const blob = item.getAsFile();
    if (!blob) return;
    ev.preventDefault();
    const input = visibleImageInput();
    if (!input) {
      toast("Esta ferramenta trabalha com vídeo. Para colar uma imagem, abra Melhorar foto, Rostos ou Ler placas.");
      return;
    }
    const ext = (blob.type.split("/")[1] || "png").replace("jpeg", "jpg");
    const file = new File([blob], `recorte-colado.${ext}`, { type: blob.type });
    const dt = new DataTransfer();
    dt.items.add(file);
    input.files = dt.files;
    input.dispatchEvent(new Event("change", { bubbles: true }));
    toast("Imagem colada.");
  });
  document.addEventListener("pointerover", (ev) => {
    const box = ev.target.closest && ev.target.closest("[id$=_img]");
    if (box && imageInput(box)) lastImageBox = box;
  });

  // ---------- soltar arquivo em qualquer lugar da página ----------
  // O arquivo vai para o campo da ferramenta aberta (foto ou vídeo), não só para a caixa.
  function visiblePanel() {
    return [...document.querySelectorAll("#tools [role=tabpanel]")].find((p) => p.offsetParent !== null) || null;
  }
  function panelInput(kind) {
    const p = visiblePanel();
    return p ? p.querySelector(`input[type=file][accept^="${kind}"]`) : null;
  }
  function hasFiles(ev) {
    return ev.dataTransfer && [...(ev.dataTransfer.types || [])].includes("Files");
  }
  function sendFile(input, file) {
    const dt = new DataTransfer();
    dt.items.add(file);
    input.files = dt.files;
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }
  let dropOverlay = null, dragDepth = 0;
  function overlay(show) {
    if (!dropOverlay) {
      dropOverlay = document.createElement("div");
      dropOverlay.id = "rl-drop";
      dropOverlay.innerHTML = "<div><b>Solte o arquivo aqui</b><span></span></div>";
      document.body.appendChild(dropOverlay);
    }
    if (show) {
      const tool = visiblePanel() ? (document.querySelector(".rl-card.active b") || {}).textContent : "";
      dropOverlay.querySelector("span").textContent = tool ? `Ele vai para ${tool}.` : "";
    }
    dropOverlay.classList.toggle("show", show);
  }
  document.addEventListener("dragenter", (ev) => {
    if (!hasFiles(ev)) return;
    dragDepth++;
    overlay(true);
  });
  document.addEventListener("dragleave", (ev) => {
    if (!hasFiles(ev)) return;
    dragDepth = Math.max(0, dragDepth - 1);
    if (!dragDepth) overlay(false);
  });
  document.addEventListener("dragover", (ev) => { if (hasFiles(ev)) ev.preventDefault(); });
  document.addEventListener("drop", (ev) => {
    dragDepth = 0;
    overlay(false);
    if (!hasFiles(ev)) return;
    // dentro de uma caixa de envio o próprio campo cuida do arquivo
    const block = ev.target.closest && ev.target.closest(".block");
    if (ev.defaultPrevented && block && block.querySelector("input[type=file]")) return;
    ev.preventDefault();
    const file = ev.dataTransfer.files[0];
    if (!file) return;
    const kind = file.type.startsWith("video/") ? "video" : file.type.startsWith("image/") ? "image" : "";
    const input = kind && panelInput(kind);
    if (input) {
      sendFile(input, file);
      toast(kind === "video" ? "Vídeo recebido." : "Imagem recebida.");
    } else if (!visiblePanel()) {
      toast("Escolha uma ferramenta antes de soltar o arquivo.");
    } else if (kind === "video") {
      toast("Esta ferramenta trabalha com fotos. Para vídeo, abra Melhorar vídeo, Placas no vídeo ou Pessoas no vídeo.");
    } else if (kind === "image") {
      toast("Esta ferramenta trabalha com vídeo. Para foto, abra Melhorar foto ou Ler placa.");
    } else {
      toast("Este tipo de arquivo não é aceito. Use uma foto (JPG, PNG…) ou um vídeo (MP4…).");
    }
  });

  // ---------- ampliar o resultado (clique na imagem) ----------
  let lb = null;
  const zoomState = { k: 1, x: 0, y: 0, srcs: [], i: 0 };
  function lbApply() {
    const img = lb.querySelector("img");
    img.style.transform = `translate(${zoomState.x}px, ${zoomState.y}px) scale(${zoomState.k})`;
    lb.querySelector("[data-z=level]").textContent = Math.round(zoomState.k * 100) + "%";
    lb.classList.toggle("zoomed", zoomState.k > 1);
  }
  function lbZoom(factor, cx, cy) {
    // amplia mantendo o ponto (cx, cy) da tela no mesmo lugar
    const r = lb.querySelector("img").getBoundingClientRect();
    const c0x = r.left + r.width / 2 - zoomState.x, c0y = r.top + r.height / 2 - zoomState.y;
    const px = cx === undefined ? r.left + r.width / 2 : cx;
    const py = cy === undefined ? r.top + r.height / 2 : cy;
    const k = Math.min(16, Math.max(1, zoomState.k * factor));
    const f = k / zoomState.k;
    if (k === 1) { zoomState.x = zoomState.y = 0; }
    else {
      zoomState.x = (px - c0x) - f * (px - c0x - zoomState.x);
      zoomState.y = (py - c0y) - f * (py - c0y - zoomState.y);
    }
    zoomState.k = k;
    lbApply();
  }
  function lbShow(i) {
    zoomState.i = i;
    lb.querySelector("img").src = zoomState.srcs[i].src;
    lb.querySelectorAll("[data-z=pick]").forEach((b, j) => b.classList.toggle("on", j === i));
  }
  function openZoom(srcs, i) {
    if (!lb) {
      lb = document.createElement("div");
      lb.id = "rl-zoom";
      lb.setAttribute("role", "dialog");
      lb.setAttribute("aria-label", "Imagem ampliada");
      lb.innerHTML =
        '<div class="rl-zoom-stage"><img alt="Resultado ampliado"></div>' +
        '<div class="rl-zoom-bar">' +
        '<span class="rl-zoom-picks"></span>' +
        '<button type="button" data-z="out" aria-label="Reduzir">−</button>' +
        '<span data-z="level">100%</span>' +
        '<button type="button" data-z="in" aria-label="Ampliar">+</button>' +
        '<button type="button" data-z="fit">Ajustar</button>' +
        '<button type="button" data-z="close">Fechar</button></div>' +
        '<p class="rl-zoom-hint">Clique para ampliar ou reduzir · roda do mouse para ajustar · arraste para mover · Esc fecha</p>';
      document.body.appendChild(lb);
      const stage = lb.querySelector(".rl-zoom-stage");
      let drag = null, moved = false;
      stage.addEventListener("pointerdown", (ev) => {
        drag = { x: ev.clientX, y: ev.clientY, ox: zoomState.x, oy: zoomState.y,
                 onImg: ev.target.tagName === "IMG" };
        moved = false;
        stage.setPointerCapture(ev.pointerId);
      });
      stage.addEventListener("pointermove", (ev) => {
        if (!drag) return;
        const dx = ev.clientX - drag.x, dy = ev.clientY - drag.y;
        if (Math.abs(dx) + Math.abs(dy) > 4) moved = true;
        if (moved && zoomState.k > 1) {
          zoomState.x = drag.ox + dx;
          zoomState.y = drag.oy + dy;
          lbApply();
        }
      });
      stage.addEventListener("pointerup", (ev) => {
        const wasDrag = moved, onImg = drag && drag.onImg;
        drag = null;
        if (wasDrag) return;
        if (!onImg) { closeZoom(); return; }  // clique fora da imagem fecha
        if (zoomState.k > 1) { zoomState.k = 1; zoomState.x = zoomState.y = 0; lbApply(); }
        else lbZoom(2.5, ev.clientX, ev.clientY);
      });
      stage.addEventListener("wheel", (ev) => {
        ev.preventDefault();
        lbZoom(ev.deltaY < 0 ? 1.25 : 0.8, ev.clientX, ev.clientY);
      }, { passive: false });
      lb.querySelector(".rl-zoom-bar").addEventListener("click", (ev) => {
        const b = ev.target.closest("button");
        if (!b) return;
        const z = b.dataset.z;
        if (z === "in") lbZoom(1.5);
        if (z === "out") lbZoom(1 / 1.5);
        if (z === "fit") { zoomState.k = 1; zoomState.x = zoomState.y = 0; lbApply(); }
        if (z === "close") closeZoom();
        if (z === "pick") lbShow(+b.dataset.i);
      });
    }
    zoomState.srcs = srcs;
    zoomState.k = 1; zoomState.x = zoomState.y = 0;
    lb.querySelector(".rl-zoom-picks").innerHTML = srcs.length > 1
      ? srcs.map((s, j) => `<button type="button" data-z="pick" data-i="${j}">${s.label}</button>`).join("")
      : "";
    lbShow(i);
    lbApply();
    lb.classList.add("show");
    lb.querySelector("[data-z=close]").focus();
  }
  function closeZoom() { if (lb) lb.classList.remove("show"); }
  // clique simples (sem arrastar) numa imagem de resultado abre a ampliação
  let press = null;
  document.addEventListener("pointerdown", (ev) => {
    press = { x: ev.clientX, y: ev.clientY, t: Date.now(), target: ev.target };
  }, true);
  document.addEventListener("pointerup", (ev) => {
    const p = press;
    press = null;
    if (!p || ev.button !== 0) return;
    if (Math.abs(ev.clientX - p.x) + Math.abs(ev.clientY - p.y) > 5 || Date.now() - p.t > 600) return;
    const img = p.target.closest && p.target.closest(".rl-zoom img, #f_out img");
    if (!img || !img.src) return;
    if (img.closest("#f_out")) {
      // comparação: a ampliação mostra o depois e deixa alternar com o antes
      const imgs = [...document.querySelectorAll("#f_out img")].filter((i) => i.src);
      if (imgs.length >= 2) {
        openZoom([{ src: imgs[0].src, label: "Antes" }, { src: imgs[1].src, label: "Depois" }], 1);
        return;
      }
    }
    openZoom([{ src: img.src, label: "" }], 0);
  }, true);

  // ---------- recorte do vídeo (início e fim do trecho) ----------
  const TRIMS = { v_in: "v", pv_vid: "pv", pe_vid: "pe" };
  function fmt(t) {
    t = Math.max(0, t || 0);
    return `${Math.floor(t / 60)}:${(t % 60).toFixed(1).padStart(4, "0")}`;
  }
  function numInput(id) { return document.querySelector(`#${id} input[type=number]`); }
  function setNum(id, v) {
    const inp = numInput(id);
    if (!inp) return;
    const val = String(Math.round(v * 10) / 10);
    if (inp.value === val) return;
    inp.value = val;
    inp.dispatchEvent(new Event("input", { bubbles: true }));
    inp.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function readNum(id) {
    const inp = numInput(id);
    const v = inp ? parseFloat(inp.value) : 0;
    return isNaN(v) ? 0 : v;
  }
  function trimBar(boxId, prefix) {
    const box = document.getElementById(boxId);
    if (!box) return;
    let bar = document.getElementById(`rl-trim-${prefix}`);
    if (!bar) {
      bar = document.createElement("div");
      bar.id = `rl-trim-${prefix}`;
      bar.className = "rl-trim";
      bar.hidden = true;
      bar.innerHTML =
        '<div class="rl-trim-head"><b>Trecho para analisar</b><span class="rl-trim-info"></span></div>' +
        '<div class="rl-trim-track" aria-label="Trecho do vídeo"><div class="rl-trim-sel"></div>' +
        '<div class="rl-trim-play"></div>' +
        '<button type="button" class="rl-trim-h" data-h="a" aria-label="Arraste para escolher o início"></button>' +
        '<button type="button" class="rl-trim-h" data-h="b" aria-label="Arraste para escolher o fim"></button></div>' +
        '<div class="rl-trim-row">' +
        '<button type="button" class="rl-btn" data-trim="a">Início aqui</button>' +
        '<button type="button" class="rl-btn" data-trim="b">Fim aqui</button>' +
        '<button type="button" class="rl-btn rl-btn-ghost" data-trim="all">Vídeo inteiro</button></div>';
      box.after(bar);
      const track = bar.querySelector(".rl-trim-track");
      let handle = null;
      const timeAt = (x) => {
        const r = track.getBoundingClientRect();
        return Math.min(1, Math.max(0, (x - r.left) / r.width)) * (bar._dur || 0);
      };
      track.addEventListener("pointerdown", (ev) => {
        const v = bar._video;
        if (!v || !bar._dur) return;
        handle = ev.target.dataset.h || null;
        track.setPointerCapture(ev.pointerId);
        const t = timeAt(ev.clientX);
        if (!handle) v.currentTime = t;  // clique na barra: vai para esse ponto
      });
      track.addEventListener("pointermove", (ev) => {
        if (!handle || !bar._video) return;
        const t = timeAt(ev.clientX);
        setRange(prefix, handle === "a" ? t : null, handle === "b" ? t : null);
        bar._video.currentTime = t;  // mostra o quadro do ponto escolhido
      });
      track.addEventListener("pointerup", () => { handle = null; });
      bar.addEventListener("click", (ev) => {
        const b = ev.target.closest("[data-trim]");
        if (!b || !bar._video) return;
        const t = bar._video.currentTime;
        if (b.dataset.trim === "a") setRange(prefix, t, null);
        if (b.dataset.trim === "b") setRange(prefix, null, t);
        if (b.dataset.trim === "all") { setNum(`${prefix}_ini`, 0); setNum(`${prefix}_fim`, 0); }
        drawTrim(prefix);
      });
    }
    const video = box.querySelector("video");
    if (video !== bar._video) {
      bar._video = video;
      if (video) {
        video.addEventListener("loadedmetadata", () => drawTrim(prefix));
        video.addEventListener("timeupdate", () => drawTrim(prefix));
      }
    }
    bar._dur = video && isFinite(video.duration) ? video.duration : 0;
    bar.hidden = !video || !bar._dur;
    drawTrim(prefix);
  }
  function setRange(prefix, a, b) {
    const bar = document.getElementById(`rl-trim-${prefix}`);
    const dur = bar._dur;
    let ini = readNum(`${prefix}_ini`), fim = readNum(`${prefix}_fim`) || dur;
    if (a !== null) ini = Math.min(a, fim - 0.5);
    if (b !== null) fim = Math.max(b, ini + 0.5);
    ini = Math.max(0, ini);
    fim = Math.min(dur, fim);
    setNum(`${prefix}_ini`, ini);
    setNum(`${prefix}_fim`, fim >= dur - 0.05 ? 0 : fim);  // até o final = 0
    drawTrim(prefix);
  }
  function drawTrim(prefix) {
    const bar = document.getElementById(`rl-trim-${prefix}`);
    if (!bar || bar.hidden || !bar._dur) return;
    const dur = bar._dur;
    const ini = Math.min(readNum(`${prefix}_ini`), dur);
    const fim = Math.min(readNum(`${prefix}_fim`) || dur, dur);
    const pa = (ini / dur) * 100, pb = (fim / dur) * 100;
    bar.querySelector(".rl-trim-sel").style.cssText = `left:${pa}%;width:${Math.max(0, pb - pa)}%`;
    bar.querySelector("[data-h=a]").style.left = pa + "%";
    bar.querySelector("[data-h=b]").style.left = pb + "%";
    const cur = bar._video ? bar._video.currentTime : 0;
    bar.querySelector(".rl-trim-play").style.left = (cur / dur) * 100 + "%";
    const whole = ini === 0 && fim >= dur - 0.05;
    bar.querySelector(".rl-trim-info").textContent = whole
      ? `vídeo inteiro (${fmt(dur)})`
      : `${fmt(ini)} até ${fmt(fim)} · ${(fim - ini).toFixed(1).replace(".", ",")} s`;
  }
  // o vídeo acompanha a análise: o progresso mostra "0:12.4 de 0:45.0"
  function followAnalysis() {
    const panel = visiblePanel();
    if (!panel) return;
    for (const [boxId, prefix] of Object.entries(TRIMS)) {
      const box = panel.querySelector(`#${boxId}`);
      const bar = document.getElementById(`rl-trim-${prefix}`);
      if (!box || !bar || !bar._video) continue;
      const busy = [...panel.querySelectorAll('[data-testid="status-tracker"] .progress-text, [data-testid="status-tracker"] .progress-level')]
        .map((e) => e.textContent).join(" ");
      const m = busy.match(/(\d+):(\d+(?:\.\d+)?) de (\d+):(\d+(?:\.\d+)?)/);
      bar.classList.toggle("following", !!m);
      if (!m) continue;
      const t = +m[1] * 60 + +m[2];
      const v = bar._video;
      if (!v.paused) v.pause();
      if (Math.abs(v.currentTime - t) > 0.15) v.currentTime = t;
    }
  }
  setInterval(() => {
    for (const [boxId, prefix] of Object.entries(TRIMS)) trimBar(boxId, prefix);
    followAnalysis();
  }, 400);
  document.addEventListener("input", (ev) => {
    const m = ev.target.closest && ev.target.closest("[id$=_ini], [id$=_fim]");
    if (m) drawTrim(m.id.replace(/_(ini|fim)$/, ""));
  });

  // ---------- eventos ----------
  document.addEventListener("click", (ev) => {
    const help = ev.target.closest(".rl-help");
    if (help) {
      // não deixa o clique marcar a caixa ou abrir o seletor de arquivo
      ev.preventDefault();
      ev.stopPropagation();
      if (tipOwner === help) hideTip(); else showTip(help);
      return;
    }
    hideTip();
    const act = ev.target.closest("[data-action]");
    if (act) {
      const a = act.dataset.action;
      if (a === "theme") toggleTheme();
      if (a === "donate") document.getElementById("rl-donate")?.classList.toggle("open");
      if (a === "donate-close") document.getElementById("rl-donate")?.classList.remove("open");
      if (a === "update") checkUpdate();
      if (a === "update-now") install("/api/atualizacao", "Baixando e instalando a versão nova…");
      if (a === "update-restore") install("/api/atualizacao/restaurar", "Voltando para a versão anterior…");
      if (a === "update-later") {
        if (last && last.versao) dismiss(last.versao);  // o botão Buscar atualização mostra de novo
        hideBox();
      }
      if (a === "update-close") hideBox();
    }
    const card = ev.target.closest(".rl-card[data-tab]");
    if (card) openTool(card.dataset.tab, true);
  }, true);
  document.addEventListener("mouseover", (ev) => {
    const help = ev.target.closest && ev.target.closest(".rl-help");
    if (help && tipOwner !== help) showTip(help);
  });
  document.addEventListener("mouseout", (ev) => {
    const help = ev.target.closest && ev.target.closest(".rl-help");
    if (help && !help.contains(ev.relatedTarget)) hideTip();
  });
  document.addEventListener("focusin", (ev) => {
    if (ev.target.classList && ev.target.classList.contains("rl-help")) showTip(ev.target);
  });
  document.addEventListener("focusout", (ev) => {
    if (ev.target.classList && ev.target.classList.contains("rl-help")) hideTip();
  });
  document.addEventListener("keydown", (ev) => {
    if (ev.key === "Escape") { hideTip(); closeZoom(); }
    if (lb && lb.classList.contains("show") && (ev.key === "+" || ev.key === "=")) lbZoom(1.5);
    if (lb && lb.classList.contains("show") && ev.key === "-") lbZoom(1 / 1.5);
  });
  window.addEventListener("scroll", hideTip, true);

  let observer = null;
  let updateTimer = null;
  function init() {
    applyTheme(savedTheme());
    if (!observer) {
      observer = new MutationObserver(attachHelp);
      observer.observe(document.body, { childList: true, subtree: true });
    }
    attachHelp();
    const first = document.querySelector(".rl-card[data-tab]");
    if (first) openTool(first.dataset.tab, false);
    // só depois que o Gradio montou o cabeçalho (onde fica o aviso)
    if (!updateTimer && document.getElementById("rl-update")) {
      afterRestart();
      autoCheck();
      updateTimer = setInterval(autoCheck, 15 * 60 * 1000);
    }
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
  // o Gradio monta a página depois: repete quando os cartões aparecerem
  const wait = setInterval(() => {
    if (document.querySelector(".rl-card[data-tab]") && document.querySelector("#tools [role=tab]")) {
      clearInterval(wait);
      init();
    }
  }, 200);
})();
