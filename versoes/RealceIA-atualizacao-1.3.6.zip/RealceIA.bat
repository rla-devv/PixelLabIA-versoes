@echo off
cd /d "%~dp0"
if exist ".venv\Scripts\pythonw.exe" goto :abrir
echo O RealceIA ainda nao foi instalado. Rode instalar.bat primeiro.
pause
exit /b 1
:abrir
start "" ".venv\Scripts\pythonw.exe" "realceia.pyw" %*
