"""Atualização automática do RealceIA (mesmo sistema do DegravaIA).

As versões ficam num repositório público só de pacotes (o código continua privado):
    atualizacao.json                       {"versao", "arquivo", "sha256", "tamanho", "novidades"}
    versoes/RealceIA-atualizacao-X.Y.Z.zip só o código do programa, com arquivos-do-app.txt

verificar() consulta o atualizacao.json. instalar() baixa o pacote, confere e troca os arquivos
do programa; o que precisa do app fechado (bibliotecas e modelos novos) fica anotado em
.runtime/pendente.json e o lançador (realceia.pyw) faz isso antes de abrir o app de novo.
restaurar() volta para a versão anterior. Python, bibliotecas, modelos e dados do usuário nunca
são tocados.

Só usa a biblioteca padrão: o lançador importa este arquivo sem carregar o resto do app.
"""

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

REPO_VERSOES = "rla-devv/realceia-versoes"
BASE = os.environ.get("REALCE_VERSOES_URL",
                      f"https://raw.githubusercontent.com/{REPO_VERSOES}/main").rstrip("/")
ROOT = Path(__file__).resolve().parent.parent
MANIFESTO = "arquivos-do-app.txt"
# nunca trocadas nem apagadas (modelos, ambiente Python, logs, cópias de segurança…)
PROTEGIDAS = {".venv", ".runtime", ".git", "weights", "logs", "samples", "versoes-anteriores",
              "dist", "__pycache__"}
RUNTIME = ROOT / ".runtime"
PENDENTE = RUNTIME / "pendente.json"
ATUALIZADO = RUNTIME / "atualizado.json"
ANTERIORES = ROOT / "versoes-anteriores"
CONSULTA_VALIDADE = 15 * 60  # segundos

_cache: dict = {}
_trava = threading.Lock()


# ---------------- versões ----------------

def versao_atual() -> str:
    texto = (ROOT / "realce" / "__init__.py").read_text(encoding="utf-8")
    return _versao_em(texto)


def _versao_em(texto: str) -> str:
    m = re.search(r'^__version__\s*=\s*["\']([^"\']+)["\']', texto, re.M)
    if not m:
        raise ValueError("versão não encontrada")
    return m.group(1)


def numeros(v: str) -> tuple[int, ...]:
    """Comparação por números: 0.1.10 é maior que 0.1.9."""
    return tuple(int(re.sub(r"\D", "", p) or 0) for p in v.strip().lstrip("vV").split("."))


def maior(a: str, b: str) -> bool:
    x, y = numeros(a), numeros(b)
    n = max(len(x), len(y))
    return x + (0,) * (n - len(x)) > y + (0,) * (n - len(y))


# ---------------- consulta ----------------

def _baixar(url: str, timeout: int = 20) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "RealceIA-atualizacao",
                                               "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def desenvolvimento() -> bool:
    return (ROOT / ".git").exists() and not os.environ.get("REALCE_VERSOES_URL")


def verificar(forcar: bool = False) -> dict:
    """{"status": "nova" | "atual" | "erro" | "dev", "atual", "versao", "novidades", "tamanho"}.

    Guarda a resposta por 15 min; forcar=True consulta na hora (botão Buscar atualização).
    """
    atual = versao_atual()
    if desenvolvimento():
        return {"status": "dev", "atual": atual}
    with _trava:
        if not forcar and _cache and time.time() - _cache["quando"] < CONSULTA_VALIDADE:
            return dict(_cache["resposta"], atual=atual)
    try:
        # o parâmetro evita a cópia guardada pelo GitHub quando a pessoa pede para consultar
        url = f"{BASE}/atualizacao.json" + (f"?t={int(time.time())}" if forcar else "")
        info = json.loads(_baixar(url))
        resposta = {"status": "nova" if maior(info["versao"], atual) else "atual",
                    "versao": info["versao"], "novidades": info.get("novidades", ""),
                    "tamanho": info.get("tamanho", 0), "info": info}
    except Exception as e:  # noqa: BLE001 - sem internet a consulta falha em silêncio
        return {"status": "erro", "atual": atual, "erro": str(e)[:200]}
    with _trava:
        _cache.update(quando=time.time(), resposta=resposta)
    return dict(resposta, atual=atual)


# ---------------- conferência do pacote ----------------

def _protegido(rel: str) -> bool:
    return any(p in PROTEGIDAS for p in rel.split("/"))


def _caminho_seguro(nome: str) -> bool:
    """Dentro da pasta do app: sem .., sem caminho absoluto, sem unidade (C:)."""
    if not nome or nome.startswith(("/", "\\")) or ":" in nome or "\\" in nome:
        return False
    partes = nome.split("/")
    return ".." not in partes and "" not in partes[:-1]


def conferir_pacote(dados: bytes, info: dict) -> tuple[zipfile.ZipFile, list[str]]:
    """Todas as regras de segurança, antes de trocar qualquer arquivo."""
    if hashlib.sha256(dados).hexdigest() != info["sha256"].lower():
        raise ValueError("o pacote baixado não confere (SHA-256 diferente). Tente de novo.")
    import io

    z = zipfile.ZipFile(io.BytesIO(dados))
    nomes = [n for n in z.namelist() if not n.endswith("/")]
    ruins = [n for n in nomes if not _caminho_seguro(n) or _protegido(n)]
    if ruins:
        raise ValueError(f"o pacote tem caminhos não permitidos: {ruins[:3]}")
    if MANIFESTO not in nomes or "realce/__init__.py" not in nomes:
        raise ValueError("o pacote não parece ser do RealceIA.")
    versao = _versao_em(z.read("realce/__init__.py").decode("utf-8"))
    if versao != info["versao"]:
        raise ValueError(f"o pacote é da versão {versao}, mas foi anunciada a {info['versao']}.")
    lista = [n for n in z.read(MANIFESTO).decode("utf-8").splitlines() if n.strip()]
    if sorted(set(lista) | {MANIFESTO}) != sorted(nomes):
        raise ValueError("a lista de arquivos do pacote não confere com o conteúdo.")
    return z, nomes


# ---------------- troca dos arquivos ----------------

def _manifesto_local() -> list[str] | None:
    p = ROOT / MANIFESTO
    if not p.exists():
        return None
    return [n for n in p.read_text(encoding="utf-8").splitlines() if n.strip()]


def _gravar(dest: Path, dados: bytes) -> None:
    """Grava como .novo e renomeia: o arquivo nunca fica pela metade."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.name + ".novo")
    tmp.write_bytes(dados)
    os.replace(tmp, dest)


def _copia_de_seguranca(versao: str, arquivos: list[str]) -> Path:
    """Guarda os arquivos atuais em versoes-anteriores/<versão>/ (fica só a última)."""
    destino = ANTERIORES / versao
    if ANTERIORES.exists():
        shutil.rmtree(ANTERIORES)
    destino.mkdir(parents=True)
    existentes = []
    for rel in arquivos:
        src = ROOT / rel
        if src.is_file():
            (destino / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, destino / rel)
            existentes.append(rel)
    (destino / ".arquivos-guardados.txt").write_text("\n".join(existentes) + "\n", encoding="utf-8")
    return destino


def _aplicar(z: zipfile.ZipFile, nomes: list[str], antigos: list[str] | None) -> list[str]:
    """Troca os arquivos que mudaram e apaga os que saíram. Devolve os que mudaram."""
    mudaram = []
    for rel in nomes:
        dados = z.read(rel)
        dest = ROOT / rel
        # arquivos iguais não são reescritos (no Windows, reescrever um .bat em uso dá problema)
        if dest.is_file() and dest.read_bytes() == dados:
            continue
        _gravar(dest, dados)
        mudaram.append(rel)
    for rel in sorted(set(antigos or []) - set(nomes)):
        p = ROOT / rel
        if not _protegido(rel) and _caminho_seguro(rel) and p.is_file():
            p.unlink()
            mudaram.append(rel)
    return mudaram


def _voltar(copia: Path, novos: list[str]) -> None:
    """Desfaz uma troca de arquivos a partir da cópia de segurança."""
    guardados = (copia / ".arquivos-guardados.txt").read_text(encoding="utf-8").split()
    for rel in novos:
        p = ROOT / rel
        if rel not in guardados and p.is_file() and not _protegido(rel):
            p.unlink()  # arquivo que só existe na versão nova
    for rel in guardados:
        _gravar(ROOT / rel, (copia / rel).read_bytes())


def instalar(progresso=None) -> dict:
    """Baixa, confere e troca os arquivos do programa. O app deve fechar com o código 3 depois."""
    def passo(frac, texto):
        if progresso is not None:
            progresso(frac, texto)

    if desenvolvimento():
        raise RuntimeError("esta pasta é uma cópia de desenvolvimento (git): use git pull.")
    consulta = verificar(forcar=True)
    if consulta["status"] == "erro":
        raise RuntimeError("não foi possível consultar as versões. Confira a internet.")
    if consulta["status"] != "nova":
        return {"status": "atual", "versao": consulta["atual"]}
    info = consulta["info"]
    atual = consulta["atual"]

    passo(0.1, f"Baixando a versão {info['versao']}…")
    dados = _baixar(f"{BASE}/versoes/{info['arquivo']}", timeout=120)
    passo(0.5, "Conferindo o pacote…")
    z, nomes = conferir_pacote(dados, info)

    antigos = _manifesto_local()
    # sem lista antiga (instalação feita por um zip antigo): guarda o que vai ser sobrescrito
    guardar = sorted(set(antigos or []) | {n for n in nomes if (ROOT / n).is_file()})
    passo(0.6, "Guardando uma cópia da versão atual…")
    copia = _copia_de_seguranca(atual, guardar)
    reqs_antes = _ler(ROOT / "requirements.txt")
    passo(0.7, "Trocando os arquivos do programa…")
    try:
        mudaram = _aplicar(z, nomes, antigos)
    except Exception:
        _voltar(copia, nomes)
        raise
    pendente = {"de": atual, "para": info["versao"],
                "dependencias": _ler(ROOT / "requirements.txt") != reqs_antes,
                "modelos": any(m in mudaram for m in ("download_weights.py", "realce/models.py"))}
    RUNTIME.mkdir(exist_ok=True)
    PENDENTE.write_text(json.dumps(pendente), encoding="utf-8")
    passo(1.0, "Pronto.")
    return {"status": "instalada", "versao": info["versao"], "arquivos": len(mudaram), **pendente}


def _ler(p: Path) -> bytes:
    return p.read_bytes() if p.is_file() else b""


def anterior() -> str | None:
    """Versão guardada em versoes-anteriores/, se houver."""
    if not ANTERIORES.is_dir():
        return None
    pastas = [p.name for p in ANTERIORES.iterdir() if (p / ".arquivos-guardados.txt").exists()]
    return pastas[0] if pastas else None


def restaurar() -> dict:
    """Volta para a versão guardada em versoes-anteriores/. O app deve fechar com o código 3."""
    versao = anterior()
    if not versao:
        raise RuntimeError("não há versão anterior guardada.")
    copia = ANTERIORES / versao
    atual = versao_atual()
    reqs_antes = _ler(ROOT / "requirements.txt")
    guardados = (copia / ".arquivos-guardados.txt").read_text(encoding="utf-8").split()
    for rel in _manifesto_local() or []:
        p = ROOT / rel
        if rel not in guardados and p.is_file() and not _protegido(rel) and _caminho_seguro(rel):
            p.unlink()
    for rel in guardados:
        _gravar(ROOT / rel, (copia / rel).read_bytes())
    shutil.rmtree(ANTERIORES)
    pendente = {"de": atual, "para": versao, "restaurada": True,
                "dependencias": _ler(ROOT / "requirements.txt") != reqs_antes, "modelos": False}
    RUNTIME.mkdir(exist_ok=True)
    PENDENTE.write_text(json.dumps(pendente), encoding="utf-8")
    return pendente


# ---------------- etapas com o app fechado (feitas pelo lançador) ----------------

def _python() -> str:
    exe = Path(sys.executable)
    if exe.name.lower() == "pythonw.exe":
        exe = exe.with_name("python.exe")
    return str(exe)


def _uv() -> str | None:
    dados = os.environ.get("REALCE_DADOS")
    for cand in ([Path(dados) / "uv" / ("uv.exe" if os.name == "nt" else "uv")] if dados else []):
        if cand.is_file():
            return str(cand)
    return shutil.which("uv")


def _rodar(cmd: list[str], log) -> None:
    flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    r = subprocess.run(cmd, cwd=str(ROOT), stdout=log, stderr=subprocess.STDOUT,
                       creationflags=flags)
    if r.returncode:
        raise RuntimeError("não foi possível instalar os componentes novos (código "
                           f"{r.returncode}); detalhes em logs/atualizacao.log")


def concluir_pendente(avisar=None) -> dict | None:
    """Instala bibliotecas e modelos novos, se a última atualização pediu. Se falhar, volta
    para a versão anterior. Chamado pelo lançador, com o servidor do app fechado."""
    if not PENDENTE.exists():
        return None
    pend = json.loads(PENDENTE.read_text(encoding="utf-8"))
    LOGS = ROOT / "logs"
    LOGS.mkdir(exist_ok=True)
    with open(LOGS / "atualizacao.log", "a", encoding="utf-8") as log:
        log.write(time.strftime("\n%Y-%m-%d %H:%M:%S ") + json.dumps(pend) + "\n")
        log.flush()
        try:
            if pend.get("dependencias"):
                if avisar:
                    avisar("Instalando componentes novos…<br>Pode levar alguns minutos.")
                uv = _uv()
                bibliotecas = ROOT / "bibliotecas"  # pacotes prontos levados no app, se houver
                extra = ["--find-links", str(bibliotecas)] if bibliotecas.is_dir() else []
                cmd = ([uv, "pip", "install", "--python", _python()] if uv
                       else [_python(), "-m", "pip", "install"])
                _rodar(cmd + ["-r", "requirements.txt", *extra], log)
            if pend.get("modelos"):
                if avisar:
                    avisar("Baixando modelos de IA novos…<br>Pode levar alguns minutos.")
                _rodar([_python(), "download_weights.py"], log)
        except Exception as e:  # noqa: BLE001 - qualquer falha volta para a versão anterior
            log.write(f"falhou: {e}\n")
            PENDENTE.unlink()
            if not pend.get("restaurada") and anterior():
                volta = restaurar()
                volta["dependencias"] = volta["modelos"] = False  # o ambiente antigo continua lá
                PENDENTE.unlink()
                ATUALIZADO.write_text(json.dumps({"falhou": pend["para"], "versao": volta["para"],
                                                  "erro": str(e)[:200]}), encoding="utf-8")
            return {"falhou": True, "erro": str(e)}
    PENDENTE.unlink()
    ATUALIZADO.write_text(json.dumps(pend), encoding="utf-8")
    return pend


def novidade_local() -> dict | None:
    """Resultado da última atualização, mostrado uma vez na tela depois de reabrir."""
    if not ATUALIZADO.exists():
        return None
    try:
        return json.loads(ATUALIZADO.read_text(encoding="utf-8"))
    finally:
        ATUALIZADO.unlink()
