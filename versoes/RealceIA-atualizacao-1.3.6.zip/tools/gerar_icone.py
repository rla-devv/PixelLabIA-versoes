"""Gera o ícone do RealceIA no padrão visual dos ícones da RLA.dev.

    python tools/gerar_icone.py

Mesmo estilo do ícone de reconhecimento facial: placa azul-marinho arredondada, cantoneiras
ciano brilhantes, linha de varredura e malha de pontos e linhas em ciano e azul. O tema é o do
app: uma lupa sobre uma imagem (montanhas e sol), pixelada acima da linha de varredura e nítida
abaixo dela, como antes e depois do realce.

Cria assets/realceia-icone.svg, assets/realceia-icone-128.png, assets/realceia.ico
(16 a 256 px) e docs/icone-realceia.png (1024 px, vitrine). Rasterizar o SVG usa o Chromium do
Playwright (só no desenvolvimento).
"""

import io
import math
import random
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / "assets"

S = 1024
TILE = (112, 112, 800, 800, 168)      # x, y, largura, altura, raio
LENS_C, LENS_R = (470, 468), 214      # lupa
SCAN_Y = 432                          # linha de varredura
CYAN, CYAN_HI, BLUE, VIOLET = "#5cefff", "#9ff8ff", "#4f8dff", "#7b6dff"


def ridge(x: float) -> float:
    """Altura das montanhas (y da crista) em cada x."""
    peaks = [(315, 520, 0), (450, 340, 0), (585, 468, 0), (690, 535, 0)]
    y = 720.0
    for px, py, w in peaks:
        y = min(y, py + abs(x - px) * 1.15)
    return y


SUN_C, SUN_R = (585, 330), 46


def inside_lens(x, y, margin=0):
    return math.hypot(x - LENS_C[0], y - LENS_C[1]) <= LENS_R - margin


def mesh(rng: random.Random) -> tuple[list, list, list]:
    """Malha de Delaunay na parte nítida (abaixo da linha): o corpo das montanhas."""
    def body(x, y, m=0):
        return y >= SCAN_Y - 1 and y >= ridge(x) - 1 - m and inside_lens(x, y, -2)

    ridge_pts = [(float(x), ridge(x)) for x in np.arange(256, 690, 22)
                 if ridge(x) >= SCAN_Y and inside_lens(x, ridge(x), 8)]
    pts = list(ridge_pts)
    step = 50
    for gy in np.arange(SCAN_Y + 18, 700, step):
        for gx in np.arange(240, 710, step):
            x = gx + rng.uniform(-14, 14) + (step / 2 if int(gy / step) % 2 else 0)
            y = gy + rng.uniform(-12, 12)
            if body(x, y) and y > ridge(x) + 14 and inside_lens(x, y, 16):
                pts.append((x, y))
    for k in range(22):  # borda de baixo da lente
        a = math.pi * k / 21
        x, y = LENS_C[0] + (LENS_R - 6) * math.cos(a), LENS_C[1] + (LENS_R - 6) * math.sin(a)
        if body(x, y, 4):
            pts.append((x, y))
    for x in np.arange(LENS_C[0] - 200, LENS_C[0] + 200, 30):  # na linha de varredura
        if body(x, SCAN_Y + 1, 2) and inside_lens(x, SCAN_Y, 6):
            pts.append((float(x), SCAN_Y + 1.0))
    sub = cv2.Subdiv2D((0, 0, S, S))
    for p in pts:
        sub.insert((float(p[0]), float(p[1])))
    edges = set()
    for t in sub.getTriangleList():
        tri = [(round(t[0], 1), round(t[1], 1)), (round(t[2], 1), round(t[3], 1)),
               (round(t[4], 1), round(t[5], 1))]
        cx, cy = sum(p[0] for p in tri) / 3, sum(p[1] for p in tri) / 3
        if not all(body(*p, 3) for p in tri) or not body(cx, cy, 2):
            continue
        for a, b in ((0, 1), (1, 2), (2, 0)):
            e = tuple(sorted((tri[a], tri[b])))
            if math.dist(*e) < 110:
                edges.add(e)
    return pts, sorted(edges), ridge_pts


def pixels() -> list:
    """Parte pixelada (acima da linha): a mesma imagem em blocos grandes."""
    out = []
    step = 31
    x0 = LENS_C[0] - LENS_R
    for gy in range(LENS_C[1] - LENS_R, SCAN_Y, step):
        for gx in range(x0, LENS_C[0] + LENS_R, step):
            cx, cy = gx + step / 2, gy + step / 2
            if not inside_lens(cx, cy, 8) or cy + step / 2 > SCAN_Y:
                continue
            if math.hypot(cx - SUN_C[0], cy - SUN_C[1]) < SUN_R + 14:
                color, op = CYAN_HI, 0.85      # sol
            elif cy > ridge(cx):
                color, op = BLUE, 0.75         # montanha
            else:
                color, op = "#2a6fa8", 0.16    # céu
            out.append(f'<rect x="{gx + 3}" y="{gy + 3}" width="{step - 6}" height="{step - 6}" '
                       f'rx="5" fill="{color}" opacity="{op}"/>')
    return out


def bracket(x, y, dx, dy, arm=118, r=34):
    """Cantoneira: dois braços com canto arredondado (dx, dy = direção para dentro)."""
    return (f'<path d="M {x} {y + dy * arm} L {x} {y + dy * r} Q {x} {y} {x + dx * r} {y} '
            f'L {x + dx * arm} {y}"/>')


def svg() -> str:
    rng = random.Random(7)
    pts, edges, ridge_pts = mesh(rng)
    tx, ty, tw, th, tr = TILE
    ins = 78
    b = [bracket(tx + ins, ty + ins, 1, 1), bracket(tx + tw - ins, ty + ins, -1, 1),
         bracket(tx + ins, ty + th - ins, 1, -1), bracket(tx + tw - ins, ty + th - ins, -1, -1)]
    lines = "".join(f'<line x1="{a[0]}" y1="{a[1]}" x2="{c[0]}" y2="{c[1]}"/>' for a, c in edges)
    used = {p for e in edges for p in e}
    dots = "".join(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{5.2 if y <= ridge(x) + 2 else 3.8}"/>'
                   for x, y in used)
    crest = " ".join(f"{x:.1f},{y:.1f}" for x, y in ridge_pts)
    hx, hy = (LENS_C[0] + (LENS_R + 8) * math.cos(math.pi / 4),
              LENS_C[1] + (LENS_R + 8) * math.sin(math.pi / 4))
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {S} {S}" width="{S}" height="{S}">
<defs>
  <linearGradient id="tile" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0" stop-color="#1a3049"/><stop offset="1" stop-color="#0b1629"/>
  </linearGradient>
  <radialGradient id="shine" cx="0.5" cy="0.08" r="0.75">
    <stop offset="0" stop-color="#3a6f9a" stop-opacity="0.35"/><stop offset="1" stop-color="#3a6f9a" stop-opacity="0"/>
  </radialGradient>
  <linearGradient id="mesh" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="{CYAN}"/><stop offset="0.6" stop-color="{BLUE}"/><stop offset="1" stop-color="{VIOLET}"/>
  </linearGradient>
  <linearGradient id="lens" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="{CYAN_HI}"/><stop offset="0.55" stop-color="{CYAN}"/><stop offset="1" stop-color="{BLUE}"/>
  </linearGradient>
  <linearGradient id="handle" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="{BLUE}"/><stop offset="1" stop-color="{VIOLET}"/>
  </linearGradient>
  <linearGradient id="band" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0" stop-color="{CYAN}" stop-opacity="0.22"/><stop offset="1" stop-color="{CYAN}" stop-opacity="0"/>
  </linearGradient>
  <linearGradient id="scan" gradientUnits="userSpaceOnUse" x1="{tx + 40}" y1="0" x2="{tx + tw - 40}" y2="0">
    <stop offset="0" stop-color="{CYAN}" stop-opacity="0"/><stop offset="0.12" stop-color="{CYAN_HI}"/>
    <stop offset="0.88" stop-color="{CYAN_HI}"/><stop offset="1" stop-color="{CYAN}" stop-opacity="0"/>
  </linearGradient>
  <filter id="glow" x="-30%" y="-30%" width="160%" height="160%">
    <feGaussianBlur stdDeviation="9" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
  </filter>
  <filter id="glow-soft" x="-20%" y="-20%" width="140%" height="140%">
    <feGaussianBlur stdDeviation="4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
  </filter>
  <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
    <feDropShadow dx="0" dy="14" stdDeviation="22" flood-color="#000814" flood-opacity="0.65"/>
  </filter>
  <clipPath id="in-lens"><circle cx="{LENS_C[0]}" cy="{LENS_C[1]}" r="{LENS_R - 8}"/></clipPath>
  <clipPath id="in-tile"><rect x="{tx}" y="{ty}" width="{tw}" height="{th}" rx="{tr}"/></clipPath>
</defs>
<rect x="{tx}" y="{ty}" width="{tw}" height="{th}" rx="{tr}" fill="url(#tile)" filter="url(#shadow)"/>
<rect x="{tx}" y="{ty}" width="{tw}" height="{th}" rx="{tr}" fill="url(#shine)"/>
<rect x="{tx + 1.5}" y="{ty + 1.5}" width="{tw - 3}" height="{th - 3}" rx="{tr - 1.5}" fill="none" stroke="#33557a" stroke-width="3" stroke-opacity="0.8"/>
<g fill="none" stroke="{CYAN}" stroke-width="24" stroke-linecap="round" stroke-linejoin="round" filter="url(#glow)">{"".join(b)}</g>
<g clip-path="url(#in-tile)"><rect x="{tx}" y="{SCAN_Y}" width="{tw}" height="80" fill="url(#band)"/></g>
<g clip-path="url(#in-lens)">
  <circle cx="{LENS_C[0]}" cy="{LENS_C[1]}" r="{LENS_R}" fill="#081426" opacity="0.55"/>
  {"".join(pixels())}
  <g stroke="url(#mesh)" stroke-width="2.2" stroke-opacity="0.8" filter="url(#glow-soft)">{lines}</g>
  <polyline points="{crest}" fill="none" stroke="{CYAN_HI}" stroke-width="5" stroke-linejoin="round" filter="url(#glow-soft)"/>
  <g fill="#dffcff" filter="url(#glow-soft)">{dots}</g>
</g>
<line x1="{hx:.1f}" y1="{hy:.1f}" x2="{hx + 112:.1f}" y2="{hy + 112:.1f}" stroke="url(#handle)" stroke-width="50" stroke-linecap="round" filter="url(#glow)"/>
<line x1="{hx + 14:.1f}" y1="{hy + 14:.1f}" x2="{hx + 100:.1f}" y2="{hy + 100:.1f}" stroke="#b9c6ff" stroke-opacity="0.35" stroke-width="12" stroke-linecap="round"/>
<circle cx="{LENS_C[0]}" cy="{LENS_C[1]}" r="{LENS_R}" fill="none" stroke="url(#lens)" stroke-width="20" filter="url(#glow)"/>
<rect x="{tx + 40}" y="{SCAN_Y - 3.5}" width="{tw - 80}" height="7" rx="3.5" fill="url(#scan)" filter="url(#glow)"/>
</svg>'''


def render(svg_text: str, size: int) -> Image.Image:
    from playwright.sync_api import sync_playwright

    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=_chromium())
        pg = b.new_page(viewport={"width": size, "height": size})
        pg.set_content(f'<html><body style="margin:0;background:transparent">'
                       f'<div style="width:{size}px;height:{size}px">'
                       f'{svg_text}</div></body></html>')
        pg.evaluate(f"""() => {{ const s=document.querySelector('svg'); s.setAttribute('width','{size}');
                       s.setAttribute('height','{size}'); }}""")
        png = pg.screenshot(omit_background=True, clip={"x": 0, "y": 0, "width": size, "height": size})
        b.close()
    return Image.open(io.BytesIO(png)).convert("RGBA")


def _chromium() -> str | None:
    for cand in Path("/opt/pw-browsers").glob("chromium-*/chrome-linux/chrome"):
        return str(cand)
    return None


def main():
    text = svg()
    (ASSETS / "realceia-icone.svg").write_text(text, encoding="utf-8")
    big = render(text, S)
    big.save(ROOT / "docs" / "icone-realceia.png")  # vitrine (fora do pacote do app)
    # atalho, janela e aba: recortado rente à placa (sobra só a sombra), para o desenho ocupar o
    # ícone inteiro também em 16 e 32 px
    m = TILE[0] - 14
    tight = big.crop((m, m, S - m, S - m + 10)).resize((512, 512), Image.LANCZOS)
    tight.resize((128, 128), Image.LANCZOS).save(ASSETS / "realceia-icone-128.png")
    sizes = [(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
    tight.save(ASSETS / "realceia.ico", sizes=sizes)
    print("ícone gerado:", ", ".join(f"{w}px" for w, _ in sizes))


if __name__ == "__main__":
    main()
