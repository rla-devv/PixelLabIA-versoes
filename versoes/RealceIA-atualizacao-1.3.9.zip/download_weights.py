"""Baixa os pesos dos modelos para a pasta weights/ e os modelos de placa para o cache."""

import shutil
import sys
import tempfile
import time
import urllib.request
import zipfile

from realce.models import LEGACY_WEIGHTS, MODEL_FILES, WEIGHTS


def fetch(url: str, dest: str, tries: int = 4):
    """Baixa com barra de progresso simples e novas tentativas se a conexão cair."""
    def hook(blocks, block_size, total):
        if total > 0:
            done = min(blocks * block_size, total)
            sys.stdout.write(f"\r    {done / 2**20:7.1f} / {total / 2**20:.1f} MB")
            sys.stdout.flush()

    for attempt in range(1, tries + 1):
        try:
            urllib.request.urlretrieve(url, dest, hook)
            print()
            return
        except OSError as e:
            print(f"\n    falhou ({e}); tentativa {attempt} de {tries}")
            if attempt == tries:
                raise
            time.sleep(5 * attempt)


WEIGHTS.mkdir(parents=True, exist_ok=True)
print(f"Modelos em: {WEIGHTS}")

# instalações antigas guardavam os modelos dentro da pasta do app: aproveita em vez de baixar
if LEGACY_WEIGHTS.resolve() != WEIGHTS.resolve() and LEGACY_WEIGHTS.is_dir():
    for f in LEGACY_WEIGHTS.iterdir():
        if f.is_file() and not f.name.endswith(".part") and not (WEIGHTS / f.name).exists():
            print(f"→ reaproveitando {f.name}")
            shutil.move(str(f), WEIGHTS / f.name)
for name, (filename, url) in MODEL_FILES.items():
    path = WEIGHTS / filename
    if path.exists():
        print(f"✓ {filename}")
        continue
    print(f"↓ {filename}")
    tmp = path.with_suffix(path.suffix + ".part")
    if url.endswith(".zip"):
        # o ArcFace só é distribuído dentro do pacote buffalo_l
        with tempfile.TemporaryDirectory() as d:
            zpath = f"{d}/pack.zip"
            fetch(url, zpath)
            with zipfile.ZipFile(zpath) as z:
                member = next(m for m in z.namelist() if m.endswith("w600k_r50.onnx"))
                tmp.write_bytes(z.read(member))
    else:
        fetch(url, str(tmp))
    tmp.replace(path)  # só aparece com o nome final quando o download terminou

print("↓ modelos de placa (detector e OCR)")
from realce.plates import _alpr  # noqa: E402

_alpr()
print("Pronto.")
