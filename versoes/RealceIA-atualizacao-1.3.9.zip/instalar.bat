@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title Instalador do Realce IA - melhoria de imagens e videos, rostos e placas

rem Downloads grandes (Python, PyTorch, bibliotecas e modelos) ficam numa pasta fixa do usuario,
rem compartilhada por qualquer pasta do Realce IA: reinstalar ou atualizar nao baixa tudo de novo.
set "RT=%~dp0.runtime"
set "DADOS=%LOCALAPPDATA%\RealceIA"
set "REALCE_DADOS=%DADOS%"
set "UV=%DADOS%\uv\uv.exe"
set "UV_CACHE_DIR=%DADOS%\cache"
set "UV_PYTHON_INSTALL_DIR=%DADOS%\python"
set "PY=%~dp0.venv\Scripts\python.exe"
if not exist "%DADOS%" mkdir "%DADOS%"

rem instalacoes antigas guardavam o cache de downloads nesta pasta: aproveita
if exist "%RT%\cache" if not exist "%UV_CACHE_DIR%" robocopy "%RT%\cache" "%UV_CACHE_DIR%" /E /MOVE /NFL /NDL /NJH /NJS /NP >nul
if exist "%RT%\uv\uv.exe" if not exist "%UV%" robocopy "%RT%\uv" "%DADOS%\uv" /E /NFL /NDL /NJH /NJS /NP >nul

echo.
echo  ==========================================
echo    Instalador do Realce IA
echo    Melhoria de imagens e videos, rostos e placas
echo  ==========================================
echo  Na primeira vez neste computador leva de 20 a 40 minutos (cerca de 6 GB de downloads).
echo  Depois disso, reinstalar ou atualizar reaproveita o que ja foi baixado.
echo  Os arquivos grandes ficam em %DADOS%
echo.

if exist "%~dp0requirements.txt" goto :pasta_ok
echo  ERRO: parece que o instalador foi aberto de dentro do arquivo ZIP.
echo  Clique com o botao direito no ZIP, escolha "Extrair tudo" e rode o instalar.bat
echo  da pasta extraida.
goto :erro_fim
:pasta_ok

rem ---------- 1. gerenciador de Python (uv) ----------
if exist "%UV%" goto :tem_uv
echo [1/6] Baixando o gerenciador de Python...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://github.com/astral-sh/uv/releases/latest/download/uv-x86_64-pc-windows-msvc.zip' -OutFile '%DADOS%\uv.zip'; Expand-Archive -Force '%DADOS%\uv.zip' '%DADOS%\uv-tmp'; New-Item -ItemType Directory -Force '%DADOS%\uv' | Out-Null; Get-ChildItem '%DADOS%\uv-tmp' -Recurse -Filter 'uv*.exe' | Move-Item -Destination '%DADOS%\uv' -Force; Remove-Item -Recurse -Force '%DADOS%\uv-tmp','%DADOS%\uv.zip'"
if errorlevel 1 goto :erro
:tem_uv

rem ---------- 2. Python 3.12 + ambiente isolado ----------
echo [2/6] Preparando o Python 3.12...
if exist "%PY%" goto :tem_venv
"%UV%" venv --python 3.12 "%~dp0.venv"
if errorlevel 1 goto :erro
:tem_venv

rem ---------- 3. PyTorch: GPU NVIDIA ou CPU ----------
set "TORCH_INDEX=https://download.pytorch.org/whl/cpu"
set "MODO=CPU"
if defined REALCE_FORCAR_CPU goto :instala_torch
nvidia-smi -L >nul 2>nul
if errorlevel 1 goto :instala_torch
set "TORCH_INDEX=https://download.pytorch.org/whl/cu126"
set "MODO=GPU"
:instala_torch
if "%MODO%"=="GPU" echo [3/6] Placa NVIDIA encontrada: instalando o PyTorch com aceleracao CUDA...
if "%MODO%"=="CPU" echo [3/6] Sem placa NVIDIA: instalando o PyTorch para processador...
"%UV%" pip install --python "%PY%" torch torchvision --index-url %TORCH_INDEX%
if errorlevel 1 goto :erro
if "%MODO%"=="CPU" goto :bibliotecas
"%PY%" -c "import sys, torch; ok = torch.cuda.is_available(); print('    GPU em uso:', torch.cuda.get_device_name(0) if ok else 'nenhuma'); sys.exit(0 if ok else 1)"
if not errorlevel 1 goto :bibliotecas
echo.
echo  AVISO: a placa NVIDIA foi encontrada, mas o PyTorch nao conseguiu usa-la.
echo  Atualize o driver em https://www.nvidia.com/pt-br/drivers/ e rode este instalador de novo.
echo  Por enquanto o Realce IA vai funcionar pelo processador, mais devagar.
echo.

:bibliotecas
rem ---------- 4. demais bibliotecas ----------
echo [4/6] Instalando as bibliotecas do Realce IA...
"%UV%" pip install --python "%PY%" -r requirements.txt
if errorlevel 1 goto :erro

rem ---------- 5. modelos de IA ----------
echo [5/6] Conferindo os modelos de IA (na primeira vez, cerca de 3,2 GB)...
"%PY%" download_weights.py
if errorlevel 1 goto :erro

rem ---------- 6. atalhos ----------
if defined REALCE_SEM_ATALHOS goto :fim
echo [6/6] Criando atalhos na Area de Trabalho e no Menu Iniciar...
"%PY%" -m realce.atalhos
if errorlevel 1 echo  Nao consegui criar os atalhos; use o arquivo RealceIA.bat desta pasta.

:fim
echo.
echo  ==========================================
echo    Pronto! Abra o Realce IA pelo atalho na Area de Trabalho
echo    ou com dois cliques em RealceIA.bat
echo  ==========================================
if not defined REALCE_SEM_PAUSA pause
exit /b 0

:erro
echo.
echo  ERRO: a instalacao parou. Verifique a conexao com a internet e rode o instalador de novo;
echo  ele continua de onde parou. Se o erro se repetir, copie as mensagens acima.
:erro_fim
if not defined REALCE_SEM_PAUSA pause
exit /b 1
