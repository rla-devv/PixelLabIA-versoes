"""Atalhos do Realce IA no Windows (Área de Trabalho e Menu Iniciar).

Criados pelo instalar.bat e refeitos pelo lançador quando uma versão muda o nome ou o ícone
(ATALHOS_VERSAO). O ícone tem um nome de arquivo novo a cada troca: o Windows guarda os ícones
em cache pelo caminho, e com o mesmo caminho o atalho continuaria com o ícone antigo.

Só usa a biblioteca padrão (o lançador importa sem carregar o resto do app).
"""

import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
NOME = "Realce IA"
DESCRICAO = "Realce IA - Melhoria de imagens e vídeos, rostos e placas"
ICONE = ROOT / "assets" / "realce-ia.ico"
ANTIGOS = ("Realce.lnk", "RealceIA.lnk")  # nomes usados por versões anteriores
ATALHOS_VERSAO = "2"
MARCA = ROOT / ".runtime" / "atalhos-versao.txt"
# identificador do app na barra de tarefas (separa o Realce IA do ícone do Python)
APP_ID = "RLAdev.RealceIA"


def _ps(texto: str) -> str:
    return texto.replace("'", "''")


def criar(todos: bool = True) -> bool:
    """Cria ou refaz os atalhos. todos=False (atualização): na Área de Trabalho só refaz se já
    havia um atalho do app lá; no Menu Iniciar sempre."""
    if os.name != "nt":
        return False
    pyw = ROOT / ".venv" / "Scripts" / "pythonw.exe"
    script = f"""
$ErrorActionPreference = 'Stop'
$s = New-Object -ComObject WScript.Shell
$desk = [Environment]::GetFolderPath('Desktop')
$prog = [Environment]::GetFolderPath('Programs')
foreach ($d in @($desk, $prog)) {{
  $tinha = $false
  foreach ($n in @({", ".join(f"'{_ps(n)}'" for n in (*ANTIGOS, NOME + '.lnk'))})) {{
    $p = Join-Path $d $n
    if (Test-Path $p) {{ $tinha = $true; Remove-Item $p -ErrorAction SilentlyContinue }}
  }}
  if ($d -eq $desk -and -not $tinha -and '{'1' if todos else '0'}' -eq '0') {{ continue }}
  $l = $s.CreateShortcut((Join-Path $d '{_ps(NOME)}.lnk'))
  $l.TargetPath = '{_ps(str(pyw))}'
  $l.Arguments = '"{_ps(str(ROOT / "realceia.pyw"))}"'
  $l.WorkingDirectory = '{_ps(str(ROOT))}'
  $l.IconLocation = '{_ps(str(ICONE))},0'
  $l.Description = '{_ps(DESCRICAO)}'
  $l.Save()
}}
# pede ao Windows para redesenhar os ícones
Start-Process -FilePath "$env:SystemRoot\\System32\\ie4uinit.exe" -ArgumentList '-show' -WindowStyle Hidden -ErrorAction SilentlyContinue
"""
    r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
                       capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW)
    if r.returncode:
        print("não consegui criar os atalhos:", (r.stderr or r.stdout)[-400:], flush=True)
        return False
    MARCA.parent.mkdir(exist_ok=True)
    MARCA.write_text(ATALHOS_VERSAO, encoding="utf-8")
    return True


def atualizar_se_preciso() -> None:
    """Chamado pelo lançador: refaz os atalhos uma vez quando o nome ou o ícone mudam."""
    if os.name != "nt" or (ROOT / ".git").exists():
        return
    try:
        if MARCA.exists() and MARCA.read_text(encoding="utf-8").strip() == ATALHOS_VERSAO:
            return
        criar(todos=False)
    except Exception as e:  # noqa: BLE001 - atalho nunca impede o app de abrir
        print("atalhos:", e, flush=True)


def identificar_processo() -> None:
    """Faz a barra de tarefas mostrar o Realce IA (nome e ícone) em vez do Python."""
    if os.name != "nt":
        return
    try:
        import ctypes

        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
    except Exception:  # noqa: BLE001
        pass


if __name__ == "__main__":
    sys.exit(0 if criar(todos="--atualizacao" not in sys.argv) else 1)
