"""Detecção (YuNet), alinhamento e restauração de rostos (GFPGAN / CodeFormer).

ATENÇÃO: a restauração gera um rosto *plausível*, não necessariamente o rosto real.
Não use o resultado para reconhecer ou identificar pessoas.
"""

from dataclasses import dataclass
from functools import lru_cache

import cv2
import numpy as np
import torch

from .models import load, weight_path

RESTORERS = {"CodeFormer": "codeformer", "GFPGAN 1.4": "gfpgan-1.4"}

# pontos (olho esq., olho dir., nariz, boca esq., boca dir.) no recorte 512x512 do FFHQ
FFHQ_TEMPLATE_512 = np.array([
    [192.98138, 239.94708], [318.90277, 240.1936], [256.63416, 314.01935],
    [201.26117, 371.41043], [313.08905, 371.15118],
], dtype=np.float32)


@dataclass
class Face:
    box: tuple[int, int, int, int]  # x, y, w, h
    landmarks: np.ndarray            # 5x2, ordenados como FFHQ_TEMPLATE_512
    score: float


@lru_cache(maxsize=1)
def _detector():
    return cv2.FaceDetectorYN.create(str(weight_path("yunet")), "", (320, 320), 0.6, 0.3, 5000)


def detect_faces(img_bgr: np.ndarray, min_score: float = 0.6) -> list[Face]:
    h, w = img_bgr.shape[:2]
    # YuNet funciona melhor em imagens não gigantes
    scale = min(1.0, 1280 / max(h, w))
    small = cv2.resize(img_bgr, None, fx=scale, fy=scale) if scale < 1 else img_bgr
    det = _detector()
    det.setInputSize((small.shape[1], small.shape[0]))
    det.setScoreThreshold(min_score)
    _, rows = det.detect(small)
    faces = []
    for r in rows if rows is not None else []:
        r = r / np.array([scale] * 14 + [1])
        lm = r[4:14].reshape(5, 2)
        eyes = lm[:2][np.argsort(lm[:2, 0])]     # ordena da esquerda p/ direita na imagem
        mouth = lm[3:5][np.argsort(lm[3:5, 0])]
        lm = np.vstack([eyes, lm[2:3], mouth]).astype(np.float32)
        faces.append(Face(tuple(int(v) for v in r[:4]), lm, float(r[14])))
    return faces


def plausible_faces(img_bgr: np.ndarray, faces: list[Face], sure: float = 0.85) -> list[Face]:
    """Descarta "rostos" que não estão numa pessoa (ex.: uma roda de carro com nota 0,70).

    Rosto com nota alta fica sempre. Com nota menor, só se o centro dele estiver dentro de uma
    pessoa encontrada pelo detector de pessoas.
    """
    doubtful = [f for f in faces if f.score < sure]
    if not doubtful:
        return faces
    from .people import detect_people

    people = [b for b, _ in detect_people(img_bgr, 0.3)]

    def inside(f):
        cx, cy = f.box[0] + f.box[2] / 2, f.box[1] + f.box[3] / 2
        return any(x1 <= cx <= x2 and y1 <= cy <= y2 for x1, y1, x2, y2 in people)

    return [f for f in faces if f.score >= sure or inside(f)]


@torch.inference_mode()
def _restore_crop(crop_bgr: np.ndarray, model_name: str, fidelity: float) -> np.ndarray:
    model = load(model_name)
    rgb = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2RGB)
    x = torch.from_numpy(rgb).permute(2, 0, 1).float().div(255).unsqueeze(0)
    x = (x * 2 - 1).to(model.device, model.dtype)  # os modelos de rosto usam [-1, 1]
    if model_name == "codeformer":
        y = model.model(x, weight=fidelity)[0]
    else:
        y = model.model(x)[0]
    y = ((y.float().clamp(-1, 1) + 1) / 2).squeeze(0).permute(1, 2, 0).mul(255).round()
    return cv2.cvtColor(y.byte().cpu().numpy(), cv2.COLOR_RGB2BGR)


def restore_faces(img_bgr: np.ndarray, model_name: str = "codeformer", fidelity: float = 0.7,
                  faces: list[Face] | None = None, blend: float = 1.0) -> tuple[np.ndarray, list[Face]]:
    """Restaura todos os rostos e os cola de volta na imagem.

    fidelity (só CodeFormer): 0 = mais "bonito"/inventado, 1 = mais fiel ao original.
    blend: mistura entre rosto restaurado (1.0) e original (0.0).
    """
    if faces is None:
        faces = detect_faces(img_bgr)
    out = img_bgr.astype(np.float32)
    h, w = img_bgr.shape[:2]
    size = 512
    # máscara com bordas suaves para colar sem emenda
    mask = np.zeros((size, size), np.float32)
    m = size // 16
    mask[m:-m, m:-m] = 1
    mask = cv2.GaussianBlur(mask, (0, 0), m / 1.5)

    for face in faces:
        M, _ = cv2.estimateAffinePartial2D(face.landmarks, FFHQ_TEMPLATE_512, method=cv2.LMEDS)
        if M is None:
            continue
        crop = cv2.warpAffine(img_bgr, M, (size, size), flags=cv2.INTER_LINEAR,
                              borderMode=cv2.BORDER_CONSTANT, borderValue=(135, 133, 132))
        restored = _restore_crop(crop, model_name, fidelity)
        Minv = cv2.invertAffineTransform(M)
        back = cv2.warpAffine(restored, Minv, (w, h), flags=cv2.INTER_LANCZOS4)
        alpha = cv2.warpAffine(mask, Minv, (w, h))[..., None] * blend
        out = out * (1 - alpha) + back.astype(np.float32) * alpha

    return out.clip(0, 255).astype(np.uint8), faces


def draw_faces(img_bgr: np.ndarray, faces: list[Face]) -> np.ndarray:
    vis = img_bgr.copy()
    for f in faces:
        x, y, w, h = f.box
        cv2.rectangle(vis, (x, y), (x + w, y + h), (0, 200, 255), 2)
        for px, py in f.landmarks:
            cv2.circle(vis, (int(px), int(py)), 2, (0, 255, 0), -1)
    return vis
