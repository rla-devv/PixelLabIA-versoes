"""Modo Fiel: melhora a nitidez sem modelos generativos.

Usa apenas redes treinadas para se aproximar dos pixels reais (Restormer para desfoque,
SwinIR/Real-ESRNet em versão PSNR para resolução) e, opcionalmente, nitidez clássica.
O resultado é menos "bonito" que o CodeFormer, mas não cria traços novos no rosto.
"""

import cv2
import numpy as np

from .upscale import run_model, upscale


def unsharp(img_bgr: np.ndarray, amount: float, sigma: float = 1.2) -> np.ndarray:
    """Máscara de nitidez clássica: só realça bordas que já existem (também realça ruído)."""
    if amount <= 0:
        return img_bgr
    blur = cv2.GaussianBlur(img_bgr, (0, 0), sigma)
    return cv2.addWeighted(img_bgr, 1 + amount, blur, -amount, 0)


def combing_index(img_bgr: np.ndarray) -> float:
    """Quanto a imagem tem listras de entrelaçamento ("pente" em quem se mexe).

    Compara a diferença de cada linha para a média das vizinhas com a diferença entre linhas a
    duas de distância: em torno de 0,25 é normal; acima de ~0,4 costuma haver listras.
    """
    g = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY).astype(np.float32)
    if g.shape[0] < 8:
        return 0.0
    d1 = np.abs(g[1:-1] - (g[:-2] + g[2:]) / 2).mean()
    d2 = np.abs(g[2:] - g[:-2]).mean()
    return float(d1 / max(d2, 1e-6))


def looks_interlaced(img_bgr: np.ndarray) -> bool:
    """Vale sugerir "Remover listras"? Só em foto com cara de câmera de segurança.

    Em fotos já reduzidas e recomprimidas o pente deixa de ser "uma linha sim, uma não", e a
    medida de listras também sobe com texturas finas (tecido, cascalho, pele com nitidez de
    JPEG). Câmeras de segurança gravam com pouca cor; fotos comuns, não. Calibrado com fotos de
    câmera com listras reais (medida 0,34 a 0,50, cor média 13 a 15) e fotos sem listras
    (retrato colorido 0,49 com cor 125; cascalho 0,48 com cor 29).
    """
    sat = float(cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)[..., 1].mean())
    return sat < 25 and combing_index(img_bgr) > 0.33


def deinterlace(img_bgr: np.ndarray) -> np.ndarray:
    """Remove as listras de câmera entrelaçada: usa só as linhas pares e recompõe as ímpares."""
    even = img_bgr[0::2]
    return cv2.resize(even, (img_bgr.shape[1], img_bgr.shape[0]), interpolation=cv2.INTER_CUBIC)


def is_grayscale(img_bgr: np.ndarray) -> bool:
    """Foto em preto e branco (câmera noturna/infravermelho), mesmo fotografada de uma tela,
    que deixa um leve tom de cor."""
    sat = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)[..., 1]
    return float(np.percentile(sat, 95)) < 40


def to_gray(img_bgr: np.ndarray) -> np.ndarray:
    return cv2.cvtColor(cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY), cv2.COLOR_GRAY2BGR)


def _moire_mask(gray: np.ndarray, thr: float, min_r: float):
    """Picos no espectro (padrão repetido da grade de pixels da tela) longe do centro."""
    h, w = gray.shape
    F = np.fft.fftshift(np.fft.fft2(gray.astype(np.float32)))
    power = np.abs(F)
    lm = np.log1p(power).astype(np.float32)
    res = cv2.GaussianBlur(lm - cv2.GaussianBlur(lm, (0, 0), max(h, w) / 60), (0, 0), 2)
    yy, xx = np.mgrid[:h, :w]
    far = np.hypot((yy - h / 2) / h, (xx - w / 2) / w) > min_r
    peaks = cv2.dilate(((res > thr) & far).astype(np.float32), np.ones((5, 5), np.uint8))
    energy = float((power ** 2 * peaks).sum() / max((power ** 2 * far).sum(), 1e-9))
    return cv2.GaussianBlur(peaks, (0, 0), 3).clip(0, 1), energy


def moire_index(img_bgr: np.ndarray) -> float:
    """Fração da energia de detalhe que está em padrões repetidos. ~0 em fotos comuns;
    acima de ~0,1 em fotos tiradas de uma tela (moiré)."""
    g = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    k = min(1.0, 1200 / max(g.shape))  # a medida não precisa da resolução toda
    small = cv2.resize(g, None, fx=k, fy=k, interpolation=cv2.INTER_AREA) if k < 1 else g
    return _moire_mask(small, 1.6, 0.06)[1]


def remove_moire(img_bgr: np.ndarray, thr: float = 1.0) -> np.ndarray:
    """Tira o padrão de ondas/grade de uma foto tirada da tela, apagando só as frequências
    desse padrão (o resto da imagem não muda)."""
    mask, _ = _moire_mask(cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY), thr, 0.06)
    keep = 1 - mask
    out = [np.real(np.fft.ifft2(np.fft.ifftshift(np.fft.fftshift(np.fft.fft2(c)) * keep)))
           for c in cv2.split(img_bgr.astype(np.float32))]
    return cv2.merge(out).clip(0, 255).astype(np.uint8)


def faithful_enhance(img_bgr: np.ndarray, sr_model: str = "realesrnet-x4plus",
                     out_scale: float = 2.0, deblur: bool = False,
                     sharpen: float = 0.0) -> np.ndarray:
    img = img_bgr
    if deblur:
        img = run_model(img, "restormer-deblur", tile=384, pad=32)
    if out_scale > 1:
        img = upscale(img, sr_model, out_scale)
    return unsharp(img, sharpen)
