"""Medidor de desvio de identidade com ArcFace (InsightFace w600k_r50).

Compara o rosto da imagem original com o mesmo rosto depois do processamento.
Similaridade alta = o processamento manteve os traços; baixa = o rosto foi alterado.
"""

from functools import lru_cache

import cv2
import numpy as np

from .faces import Face
from .models import weight_path

# pontos de referência do recorte 112x112 usado no treino do ArcFace
ARCFACE_TEMPLATE = np.array([
    [38.2946, 51.6963], [73.5318, 51.5014], [56.0252, 71.7366],
    [41.5493, 92.3655], [70.7299, 92.2041],
], dtype=np.float32)

# faixas calibradas comparando saídas com a foto nítida real (ver README); não servem para
# reconhecer pessoas, só para medir o quanto o processamento mudou o rosto
PRESERVED, CHANGED = 0.80, 0.55


@lru_cache(maxsize=1)
def _session():
    import onnxruntime as ort

    providers = [p for p in ("CUDAExecutionProvider", "CPUExecutionProvider")
                 if p in ort.get_available_providers()]
    return ort.InferenceSession(str(weight_path("arcface")), providers=providers)


def embed(img_bgr: np.ndarray, landmarks: np.ndarray) -> np.ndarray:
    M, _ = cv2.estimateAffinePartial2D(landmarks, ARCFACE_TEMPLATE, method=cv2.LMEDS)
    crop = cv2.warpAffine(img_bgr, M, (112, 112), flags=cv2.INTER_AREA
                          if np.hypot(*M[0, :2]) < 1 else cv2.INTER_CUBIC)
    x = cv2.cvtColor(crop, cv2.COLOR_BGR2RGB).astype(np.float32)
    x = ((x - 127.5) / 127.5).transpose(2, 0, 1)[None]
    sess = _session()
    v = sess.run(None, {sess.get_inputs()[0].name: x})[0][0]
    return v / np.linalg.norm(v)


def verdict(sim: float) -> str:
    if sim >= PRESERVED:
        return "preservada"
    if sim >= CHANGED:
        return "alterada"
    return "MUITO alterada"


def compare(original: np.ndarray, faces: list[Face], outputs: dict[str, np.ndarray]) -> list[list]:
    """Uma linha por rosto: tamanho, e similaridade com o original para cada saída."""
    rows = []
    w0 = original.shape[1]
    for i, f in enumerate(faces, 1):
        ref = embed(original, f.landmarks)
        size = int(max(f.box[2], f.box[3]))
        row = [i, f"{size}px" + (" (pequeno: medida pouco confiável)" if size < 40 else "")]
        for img in outputs.values():
            k = img.shape[1] / w0
            sim = float(ref @ embed(img, f.landmarks * k))
            row.append(f"{sim:.2f} · {verdict(sim)}")
        rows.append(row)
    return rows


def headers(outputs: dict) -> list[str]:
    return ["Rosto", "Tamanho no original", *[f"Identidade: {n}" for n in outputs]]
