"""Carregamento de modelos com cache e escolha automática de dispositivo."""

import os
import sys
from collections import OrderedDict
from functools import lru_cache
from pathlib import Path

import torch
from spandrel import ImageModelDescriptor, ModelLoader

ROOT = Path(__file__).resolve().parent.parent
LEGACY_WEIGHTS = ROOT / "weights"  # local usado pelas primeiras versões


def data_dir() -> Path | None:
    """Pasta compartilhada por todas as instalações do usuário (modelos, Python, cache).

    Fica fora da pasta do app para que reinstalar ou extrair uma versão nova em outra pasta
    não baixe tudo de novo. No Windows: %LOCALAPPDATA%\\RealceIA.
    """
    if os.environ.get("REALCE_DADOS"):
        return Path(os.environ["REALCE_DADOS"])
    if sys.platform == "win32" and os.environ.get("LOCALAPPDATA"):
        return Path(os.environ["LOCALAPPDATA"]) / "RealceIA"
    return None


WEIGHTS = data_dir() / "weights" if data_dir() else LEGACY_WEIGHTS

# nome lógico -> (arquivo, URL)
MODEL_FILES = {
    "realesrgan-x4plus": (
        "RealESRGAN_x4plus.pth",
        "https://github.com/xinntao/Real-ESRGAN/releases/download/v0.1.0/RealESRGAN_x4plus.pth",
    ),
    "realesr-general-x4v3": (
        "realesr-general-x4v3.pth",
        "https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesr-general-x4v3.pth",
    ),
    "gfpgan-1.4": (
        "GFPGANv1.4.pth",
        "https://github.com/TencentARC/GFPGAN/releases/download/v1.3.0/GFPGANv1.4.pth",
    ),
    "codeformer": (
        "codeformer.pth",
        "https://github.com/sczhou/CodeFormer/releases/download/v0.1.0/codeformer.pth",
    ),
    # modelos "fiéis": treinados só para se aproximar dos pixels reais (sem GAN/difusão)
    "swinir-psnr-x4": (
        "003_realSR_BSRGAN_DFO_s64w8_SwinIR-M_x4_PSNR.pth",
        "https://github.com/JingyunLiang/SwinIR/releases/download/v0.0/"
        "003_realSR_BSRGAN_DFO_s64w8_SwinIR-M_x4_PSNR.pth",
    ),
    "realesrnet-x4plus": (
        "RealESRNet_x4plus.pth",
        "https://github.com/xinntao/Real-ESRGAN/releases/download/v0.1.1/RealESRNet_x4plus.pth",
    ),
    "restormer-deblur": (
        "motion_deblurring.pth",
        "https://github.com/swz30/Restormer/releases/download/v1.0/motion_deblurring.pth",
    ),
    # reconhecimento facial (InsightFace buffalo_l, licença não comercial) — vem dentro de um zip
    "arcface": (
        "arcface_w600k_r50.onnx",
        "https://github.com/deepinsight/insightface/releases/download/v0.7/buffalo_l.zip",
    ),
    # identificação de veículos: detector (torchvision, BSD) e OpenCLIP (DataComp, MIT)
    "vehicle-detector": (
        "fasterrcnn_mobilenet_v3_large_fpn-fb6a3cc7.pth",
        "https://download.pytorch.org/models/fasterrcnn_mobilenet_v3_large_fpn-fb6a3cc7.pth",
    ),
    "clip": (
        "clip_vitl14_datacomp.bin",
        "https://huggingface.co/laion/CLIP-ViT-L-14-DataComp.XL-s13B-b90K/resolve/main/"
        "open_clip_pytorch_model.bin",
    ),
    "yunet": (
        "face_detection_yunet_2023mar.onnx",
        "https://media.githubusercontent.com/media/opencv/opencv_zoo/main/models/"
        "face_detection_yunet/face_detection_yunet_2023mar.onnx",
    ),
}


def device() -> torch.device:
    if torch.cuda.is_available():
        return torch.device("cuda")
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def weight_path(name: str) -> Path:
    filename, url = MODEL_FILES[name]
    path = WEIGHTS / filename
    if not path.exists():
        raise FileNotFoundError(
            f"Peso '{filename}' não encontrado em {WEIGHTS}. "
            f"Rode `python download_weights.py` (ou baixe de {url})."
        )
    return path


@lru_cache(maxsize=1)
def gpu_info() -> tuple[str, float] | None:
    """(nome, memória em GB) da GPU NVIDIA, ou None."""
    if not torch.cuda.is_available():
        return None
    p = torch.cuda.get_device_properties(0)
    return p.name, p.total_memory / 1024**3


def _use_half() -> bool:
    info = gpu_info()
    # a série GTX 16xx gera imagens pretas/NaN em meia precisão: usa precisão total
    return bool(info) and "GTX 16" not in info[0]


def _max_loaded() -> int:
    """Quantos modelos manter na GPU ao mesmo tempo (placas de 4 GB não comportam todos)."""
    info = gpu_info()
    if not info:
        return 99
    return 2 if info[1] < 6 else 4 if info[1] < 10 else 99


_cache: OrderedDict[str, ImageModelDescriptor] = OrderedDict()


def load(name: str) -> ImageModelDescriptor:
    if name in _cache:
        _cache.move_to_end(name)
        return _cache[name]
    if name in ("codeformer", "restormer-deblur"):
        # CodeFormer e Restormer ficam no pacote extra; registrar duas vezes dá erro
        import spandrel_extra_arches

        spandrel_extra_arches.install(ignore_duplicates=True)
    while len(_cache) >= _max_loaded():
        _cache.popitem(last=False)  # libera o modelo usado há mais tempo
        torch.cuda.empty_cache()
    model = ModelLoader().load_from_file(weight_path(name))
    assert isinstance(model, ImageModelDescriptor)
    dev = device()
    model.to(dev).eval()
    if dev.type == "cuda" and model.supports_half and _use_half():
        model.half()
    _cache[name] = model
    return model
