"""Fusão multiquadro (super-resolução multiquadro clássica), usada na leitura de placas em vídeo.

Cada quadro registra o rosto com um deslocamento sub-pixel diferente. Alinhando vários
quadros e resolvendo qual imagem ampliada explicaria TODOS eles ao mesmo tempo
(retroprojeção iterativa), recupera-se detalhe que realmente estava na cena e o ruído
cai, sem nenhum modelo generativo.
"""

from dataclasses import dataclass

import cv2
import numpy as np



@dataclass
class FusionResult:
    single: np.ndarray       # quadro de referência ampliado por interpolação (bicúbica)
    fused: np.ndarray        # super-resolução multiquadro
    used: int                # quadros aproveitados
    tried: int               # quadros avaliados
    roi: tuple               # x, y, w, h no quadro original
    aligned: list = None     # cada quadro aproveitado, alinhado na grade ampliada


def read_frames(path: str, t_center: float, n: int) -> tuple[list[np.ndarray], int, float]:
    """Lê n quadros em torno de t_center. Retorna (quadros, índice do quadro central, fps)."""
    cap = cv2.VideoCapture(path)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 10**9
    center = min(int(round(t_center * fps)), total - 1)
    start = max(0, center - n // 2)
    cap.set(cv2.CAP_PROP_POS_FRAMES, start)
    frames = []
    for _ in range(n):
        ok, f = cap.read()
        if not ok:
            break
        frames.append(f)
    cap.release()
    if not frames:
        raise ValueError("Não consegui ler quadros nesse instante do vídeo.")
    return frames, min(center - start, len(frames) - 1), fps


def frame_at(path: str, t: float) -> np.ndarray:
    frames, idx, _ = read_frames(path, t, 1)
    return frames[idx]


def _gray(img):
    g = cv2.cvtColor(img.astype(np.uint8), cv2.COLOR_BGR2GRAY).astype(np.float32) / 255
    return cv2.GaussianBlur(g, (0, 0), 1.0)


def _down(img, size, psf):
    return cv2.resize(cv2.GaussianBlur(img, (0, 0), psf), size, interpolation=cv2.INTER_AREA)


def _up(img, size):
    return cv2.resize(img, size, interpolation=cv2.INTER_CUBIC)


def fuse_region(frames: list[np.ndarray], ref_i: int, box: tuple, detect_centers,
                scale: int = 4, iterations: int = 3, psf: float | None = None,
                margin: tuple[float, float] = (0.5, 0.5), planar: bool = False) -> FusionResult:
    """Super-resolução multiquadro de uma região (rosto, placa…) que se move pouco.

    box: (x, y, w, h) no quadro de referência. detect_centers(frame) -> lista de centros
    candidatos, usada para seguir o objeto entre quadros. planar=True usa homografia
    (objetos planos, como placas); senão, transformação afim.
    """
    ref = frames[ref_i]
    x, y, w, h = box
    H, W = ref.shape[:2]
    mx, my = int(w * margin[0]), int(h * margin[1])
    x0, y0 = max(x - mx, 0), max(y - my, 0)
    rw, rh = min(x + w + mx, W) - x0, min(y + h + my, H) - y0
    cx, cy = x0 + rw / 2, y0 + rh / 2
    lr_size, hr_size = (rw, rh), (rw * scale, rh * scale)
    psf = psf if psf is not None else 0.3 * scale  # desfoque óptico suposto, em pixels da grade fina
    motion = cv2.MOTION_HOMOGRAPHY if planar else cv2.MOTION_AFFINE

    def crop(frame, ccx, ccy):
        M = np.float32([[1, 0, -(ccx - rw / 2)], [0, 1, -(ccy - rh / 2)]])
        return cv2.warpAffine(frame, M, lr_size, flags=cv2.INTER_CUBIC,
                              borderMode=cv2.BORDER_REFLECT).astype(np.float32)

    def warp(img, M, inverse):
        flags = cv2.INTER_CUBIC + (cv2.WARP_INVERSE_MAP if inverse else 0)
        if M.shape[0] == 3:
            return cv2.warpPerspective(img, M, hr_size, flags=flags, borderMode=cv2.BORDER_REFLECT)
        return cv2.warpAffine(img, M, hr_size, flags=flags, borderMode=cv2.BORDER_REFLECT)

    ref_lr = crop(ref, cx, cy)
    ref_up = _up(ref_lr, hr_size)
    ref_g = _gray(ref_up)
    criteria = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 100, 1e-5)
    eye = np.eye(3 if planar else 2, 3, dtype=np.float32)

    # cada entrada: (recorte de baixa resolução, transformação até a referência, correlação)
    obs = [(ref_lr, eye.copy(), 1.0)]
    ref_fc = np.array([x + w / 2, y + h / 2])
    prev_fc = ref_fc
    for i, f in enumerate(frames):
        if i == ref_i:
            continue
        # segue o objeto entre quadros para ter um recorte inicial aproximado
        centers = detect_centers(f)
        if centers:
            near = min(centers, key=lambda c: np.linalg.norm(c - prev_fc))
            if np.linalg.norm(near - prev_fc) < max(w, h):
                prev_fc = near
        sx, sy = prev_fc - ref_fc
        lr = crop(f, cx + sx, cy + sy)
        try:
            # alinhamento fino (sub-pixel) contra o quadro de referência
            cc, M = cv2.findTransformECC(ref_g, _gray(_up(lr, hr_size)), eye.copy(),
                                         motion, criteria, None, 5)
        except cv2.error:
            continue
        obs.append((lr, M, cc))

    # descarta quadros mal alinhados (piscadas, oclusão, mudança de expressão)
    scores = np.array([o[2] for o in obs])
    thr = max(0.7, float(np.median(scores)) - 0.1)
    obs = [o for o in obs if o[2] >= thr]

    aligned = [warp(_up(lr, hr_size), M, inverse=True) for lr, M, _ in obs]
    # ponto de partida: mediana dos quadros alinhados (já sem ruído)
    X = np.median(np.stack(aligned), axis=0)

    # retroprojeção iterativa: ajusta X até que, degradado, reproduza cada quadro observado
    for _ in range(iterations):
        corr = [warp(cv2.GaussianBlur(_up(lr - _down(warp(X, M, False), lr_size, psf), hr_size),
                                      (0, 0), psf), M, True)
                for lr, M, _ in obs]
        X = X + np.median(np.stack(corr), axis=0)  # mediana: robusta a quadros ruins

    return FusionResult(ref_up.clip(0, 255).astype(np.uint8), X.clip(0, 255).astype(np.uint8),
                        len(obs), len(frames), (x0, y0, rw, rh),
                        [a.clip(0, 255).astype(np.uint8) for a in aligned])
