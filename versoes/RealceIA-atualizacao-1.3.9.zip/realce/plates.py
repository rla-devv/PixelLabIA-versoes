"""Detecção e leitura de placas.

A leitura segue o que funcionou melhor na competição ICPR 2026 de placas em baixa resolução:

- o OCR devolve a probabilidade de cada caractere em cada posição, e a leitura é escolhida
  *dentro* do formato brasileiro (Mercosul LLLNLNN ou antiga LLLNNNN), em vez de trocar
  caracteres depois;
- o recorte é lido em várias versões (original, contraste, sem desfoque, ampliada de forma fiel)
  e as probabilidades são combinadas;
- o resultado é uma lista de candidatas com a chance de cada uma, e não só um texto.

Nenhuma versão usa IA generativa: ampliação generativa pode inventar caracteres.
"""

import heapq
from dataclasses import dataclass, field
from functools import lru_cache

import cv2
import numpy as np

LETTERS = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
DIGITS = set("0123456789")
# posições da placa brasileira: Mercosul = LLL N L NN, antiga = LLL N N NN
BR_SLOTS = [LETTERS, LETTERS, LETTERS, DIGITS, LETTERS | DIGITS, DIGITS, DIGITS]

VARIANTS = {
    "original": "Original",
    "contraste": "Contraste (CLAHE)",
    "sem_desfoque": "Sem desfoque (Restormer)",
    "ampliada": "Ampliada fiel (SwinIR)",
}


@dataclass
class Candidate:
    text: str
    share: float          # chance entre as leituras possíveis no formato escolhido
    layout: str | None    # "Mercosul", "Antiga" ou None


@dataclass
class PlateRead:
    probs: np.ndarray                  # (posições, alfabeto), já normalizado
    candidates: list[Candidate]
    char_conf: list[float]             # chance de cada caractere da melhor leitura
    br_fit: float | None               # quanto o OCR "acha" que é uma placa BR de 7 caracteres
    free_text: str                     # leitura sem nenhuma restrição de formato
    mercosul: bool = False             # faixa azul do Mercosul vista: 5ª posição só aceita letra

    @property
    def best(self) -> Candidate | None:
        return self.candidates[0] if self.candidates else None

    @property
    def illegible(self) -> bool:
        """Sem leitura útil: menos de 3 caracteres confiáveis."""
        return not self.best or self.masked().count("?") > len(self.best.text) - 3

    def masked(self, thr: float = 0.7) -> str:
        """Melhor leitura com '?' nos caracteres de baixa confiança."""
        if not self.best:
            return "?"
        return "".join(c if p >= thr else "?" for c, p in zip(self.best.text, self.char_conf))


@dataclass
class PlateResult:
    box: tuple[int, int, int, int]  # x1, y1, x2, y2
    det_conf: float
    fused: PlateRead
    per_variant: dict[str, PlateRead] = field(default_factory=dict)
    angle: int = 0  # inclinação corrigida, em graus (0 = placa já estava reta)
    aspect: float = 3.0  # largura / altura da placa como foi detectada (placa reta)

    @property
    def agreement(self) -> tuple[int, int]:
        """(versões cuja melhor leitura bate com a combinada, total de versões)."""
        best = self.fused.best.text if self.fused.best else None
        hits = sum(1 for r in self.per_variant.values() if r.best and r.best.text == best)
        return hits, len(self.per_variant)

    @property
    def trusted(self) -> bool:
        hits, total = self.agreement
        best = self.fused.best
        return bool(best and best.share >= 0.85 and hits == total
                    and (self.fused.br_fit is None or self.fused.br_fit >= 0.5))


# ---------------- modelos ----------------

@lru_cache(maxsize=1)
def _alpr():
    from fast_alpr import ALPR

    return ALPR(detector_model="yolo-v9-t-640-license-plate-end2end",
                ocr_model="cct-s-v2-global-model", detector_conf_thresh=0.3)


def _ocr():
    return _alpr().ocr.ocr_model


@lru_cache(maxsize=1)
def _alphabet() -> tuple[str, str]:
    cfg = _ocr().config
    return cfg.alphabet, cfg.pad_char


def ocr_probs(crops_bgr: list[np.ndarray]) -> np.ndarray:
    """Probabilidades por posição para cada recorte: (N, posições, alfabeto)."""
    from fast_plate_ocr.inference.plate_recognizer import _load_image_from_source, preprocess_image

    rec = _ocr()
    mode = rec.config.image_color_mode
    conv = cv2.COLOR_BGR2RGB if mode == "rgb" else cv2.COLOR_BGR2GRAY
    imgs = [cv2.cvtColor(c, conv) for c in crops_bgr]
    x = preprocess_image(_load_image_from_source(imgs, rec.config))
    out = rec.model.run([rec.plate_output_name], {"input": x})[0]
    alphabet, _ = _alphabet()
    return out.reshape(len(imgs), -1, len(alphabet)).astype(np.float64)


def detect_plates(img_bgr: np.ndarray):
    return _alpr().detector.predict(img_bgr)


# ângulos em que o quadro é girado para procurar placas inclinadas (o detector só acha
# placas mais ou menos na horizontal; ±45° cobre inclinações de até ~70°)
SEARCH_ANGLES = (0, 45, -45)


@dataclass
class Detection:
    box: tuple[int, int, int, int]   # x1, y1, x2, y2 na imagem original
    conf: float
    angle: int                       # em quantos graus a imagem foi girada para achar a placa
    rbox: tuple[int, int, int, int]  # caixa na imagem girada


def _rotation(shape, angle: float):
    """Matriz que gira a imagem sem cortar as bordas, e o tamanho do resultado."""
    h, w = shape[:2]
    M = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
    cos, sin = abs(M[0, 0]), abs(M[0, 1])
    nw, nh = int(h * sin + w * cos), int(h * cos + w * sin)
    M[0, 2] += nw / 2 - w / 2
    M[1, 2] += nh / 2 - h / 2
    return M, (nw, nh)


def _box_overlap(a, b) -> float:
    """Fração da caixa menor que está dentro da outra (1 = totalmente dentro)."""
    ix = max(0, min(a[2], b[2]) - max(a[0], b[0]))
    iy = max(0, min(a[3], b[3]) - max(a[1], b[1]))
    smaller = min((a[2] - a[0]) * (a[3] - a[1]), (b[2] - b[0]) * (b[3] - b[1]))
    return ix * iy / smaller if smaller else 0.0


def detect_any(img_bgr: np.ndarray, angles=SEARCH_ANGLES) -> list[Detection]:
    """Detecta placas também inclinadas: procura na imagem girada em alguns ângulos.

    Se nada for achado numa imagem grande, tenta de novo com ela reduzida à metade: a redução
    apaga o padrão de interferência (moiré) que aparece em fotos tiradas da tela de um monitor.
    """
    found = _detect_any(img_bgr, angles)
    if not found and max(img_bgr.shape[:2]) > 900:
        half = cv2.resize(img_bgr, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)
        for d in _detect_any(half, angles):
            # leva a caixa de volta à imagem original; a leitura é feita na imagem original
            box = tuple(int(v * 2) for v in d.box)
            rbox = box if d.angle == 0 else tuple(int(v * 2) for v in d.rbox)
            found.append(Detection(box, d.conf, d.angle, rbox))
    return found


def _detect_any(img_bgr: np.ndarray, angles) -> list[Detection]:
    h, w = img_bgr.shape[:2]
    found: list[Detection] = []
    for angle in angles:
        if angle:
            M, size = _rotation(img_bgr.shape, angle)
            img = cv2.warpAffine(img_bgr, M, size, flags=cv2.INTER_LINEAR,
                                 borderMode=cv2.BORDER_REPLICATE)
            inv = cv2.invertAffineTransform(M)
        else:
            img, inv = img_bgr, None
        for d in detect_plates(img):
            b = d.bounding_box
            rbox = (max(b.x1, 0), max(b.y1, 0), min(b.x2, img.shape[1]), min(b.y2, img.shape[0]))
            if rbox[2] - rbox[0] < 4 or rbox[3] - rbox[1] < 4:
                continue
            if inv is None:
                box = rbox
            else:  # leva os cantos de volta para a imagem original
                pts = np.array([[rbox[0], rbox[1]], [rbox[2], rbox[1]], [rbox[2], rbox[3]],
                                [rbox[0], rbox[3]]], np.float32)
                back = cv2.transform(pts[None], inv)[0]
                box = (max(int(back[:, 0].min()), 0), max(int(back[:, 1].min()), 0),
                       min(int(back[:, 0].max()), w), min(int(back[:, 1].max()), h))
            found.append(Detection(box, float(d.confidence), angle, rbox))
    # a mesma placa achada em vários ângulos: vale a detecção reta (caixa mais justa); as
    # giradas só acrescentam placas que a reta não achou
    found.sort(key=lambda d: (d.angle != 0, -d.conf))
    kept: list[Detection] = []
    for d in found:
        # caixa de placa girada, levada de volta à imagem, fica maior que a da placa reta:
        # por isso compara quanto da menor está dentro da outra
        if all(_box_overlap(d.box, k.box) < 0.5 for k in kept):
            kept.append(d)
    return kept


# ---------------- decodificação ----------------

def fuse(probs: list[np.ndarray] | np.ndarray, weights=None) -> np.ndarray:
    """Combina leituras pela média ponderada dos log-probs (favorece o consenso)."""
    p = np.asarray(probs)
    w = np.ones(len(p)) if weights is None else np.asarray(weights, dtype=np.float64)
    logp = np.tensordot(w / w.sum(), np.log(np.clip(p, 1e-9, 1)), axes=1)
    q = np.exp(logp - logp.max(axis=-1, keepdims=True))
    return q / q.sum(axis=-1, keepdims=True)


def _kbest(probs: np.ndarray, slots: list[set[str] | None], k: int) -> list[tuple[str, float]]:
    """As k sequências mais prováveis, com cada posição restrita ao seu conjunto (exato)."""
    alphabet, pad = _alphabet()
    beams = [("", 1.0)]
    for i, allowed in enumerate(slots):
        opts = [(alphabet[j], probs[i, j]) for j in range(len(alphabet))
                if alphabet[j] != pad and (allowed is None or alphabet[j] in allowed)]
        opts = heapq.nlargest(k, opts, key=lambda o: o[1])
        beams = heapq.nlargest(k, ((t + c, s * p) for t, s in beams for c, p in opts),
                               key=lambda b: b[1])
    return beams


MERCOSUL_SLOTS = [LETTERS, LETTERS, LETTERS, DIGITS, LETTERS, DIGITS, DIGITS]


def mercosul_band(crop_bgr: np.ndarray) -> bool:
    """True se a placa tem a faixa azul do Mercosul no topo.

    Corrige antes o balanço de branco usando o fundo branco da própria placa, porque à noite
    a iluminação alaranjada esconde o azul. Sem evidência (placa estourada, borrada), False.
    """
    if crop_bgr.size == 0 or min(crop_bgr.shape[:2]) < 6:
        return False
    c = crop_bgr.astype(np.float32)
    v = c.max(2)
    ref = c[v >= np.percentile(v, 60)].mean(0)  # cor do "branco" sob esta luz
    wb = np.clip(c * (ref.mean() / np.maximum(ref, 1)), 0, 255).astype(np.uint8)
    hsv = cv2.cvtColor(wb, cv2.COLOR_BGR2HSV)
    blue = ((hsv[..., 0] >= 85) & (hsv[..., 0] <= 130) & (hsv[..., 1] >= 45)
            & (hsv[..., 2] >= 60))
    h = blue.shape[0]
    top, bottom = blue[: h // 2].mean(), blue[h // 2:].mean()
    return bool(top >= 0.12 and top >= 1.6 * bottom)


def decode(probs: np.ndarray, br: bool = True, k: int = 5, mercosul: bool = False) -> PlateRead:
    alphabet, pad = _alphabet()
    pad_i = alphabet.index(pad)
    free = "".join(alphabet[j] for j in probs.argmax(-1)).replace(pad, "")

    if br:
        slots = MERCOSUL_SLOTS if mercosul else BR_SLOTS
        n = len(slots)
        # chance de "ser uma placa BR": posições 0-6 com caractere válido e o resto vazio
        mass = [sum(probs[i, alphabet.index(c)] for c in s) for i, s in enumerate(slots)]
        tail = float(np.prod(probs[n:, pad_i])) if probs.shape[0] > n else 1.0
        br_fit = float(np.prod(mass)) * tail
    else:
        n = len(free)
        slots = [None] * n
        mass = [1 - probs[i, pad_i] for i in range(n)]
        br_fit = None
    if n == 0:
        return PlateRead(probs, [], [], br_fit, free, br and mercosul)

    total = float(np.prod(mass))  # soma das chances de TODAS as leituras possíveis
    cands = []
    for text, score in _kbest(probs, slots, k):
        layout = None
        if br:
            layout = "Mercosul" if text[4] in LETTERS else "Antiga"
        cands.append(Candidate(text, score / total if total else 0.0, layout))
    best = cands[0].text
    # confiança de cada caractere da melhor leitura, dentro do que a posição permite
    char_conf = [float(probs[i, alphabet.index(c)] / mass[i]) if mass[i] else 0.0
                 for i, c in enumerate(best)]
    return PlateRead(probs, cands, char_conf, br_fit, free, br and mercosul)


# ---------------- versões do recorte ----------------

def make_variants(crop: np.ndarray, deblur: bool = True, sr: bool = True) -> dict[str, np.ndarray]:
    out = {"original": crop}
    lab = cv2.cvtColor(crop, cv2.COLOR_BGR2LAB)
    lab[..., 0] = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(4, 4)).apply(lab[..., 0])
    out["contraste"] = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
    if deblur:
        from .upscale import run_model

        out["sem_desfoque"] = run_model(crop, "restormer-deblur", tile=512, pad=0)
    if sr:
        from .upscale import upscale

        out["ampliada"] = upscale(crop, "swinir-psnr-x4", 4)
    return out


def _context_crop(img, box, mx=0.15, my=0.3):
    """Recorte com margem (dá contexto aos modelos) e a posição da placa dentro dele."""
    h, w = img.shape[:2]
    x1, y1, x2, y2 = box
    px, py = int((x2 - x1) * mx), int((y2 - y1) * my)
    ex1, ey1, ex2, ey2 = max(x1 - px, 0), max(y1 - py, 0), min(x2 + px, w), min(y2 + py, h)
    return img[ey1:ey2, ex1:ex2], (x1 - ex1, y1 - ey1, x2 - ex1, y2 - ey1)


def read_crop(img: np.ndarray, box, variants: bool = True, deblur: bool = True,
              sr: bool = True, br: bool = True) -> tuple[PlateRead, dict[str, PlateRead], np.ndarray]:
    """Lê uma placa em várias versões e combina. Retorna (combinada, por versão, probs combinadas)."""
    ctx, (cx1, cy1, cx2, cy2) = _context_crop(img, box)
    vs = make_variants(ctx, deblur, sr) if variants else {"original": ctx}
    crops = []
    for v in vs.values():
        k = v.shape[1] / ctx.shape[1]
        crops.append(v[int(cy1 * k):int(cy2 * k), int(cx1 * k):int(cx2 * k)])
    probs = ocr_probs(crops)
    fused = fuse(probs)
    merc = br and mercosul_band(crops[0])
    per = {name: decode(p, br, mercosul=merc) for name, p in zip(vs, probs)}
    return decode(fused, br, mercosul=merc), per, fused


def fuse_reads(reads: list[PlateRead], br: bool = True, top: int = 5) -> PlateRead:
    """Combina várias leituras da mesma placa usando só as melhores, com peso pela qualidade.

    Em vídeo, muitos quadros são ruins (borrados, estourados pelo farol); somar todos por igual
    deixa o ruído dominar. A faixa do Mercosul vale se aparecer em alguma das melhores leituras.
    """
    best = sorted(reads, key=lambda r: -_quality(r, br))[:top]
    weights = [max(_quality(r, br), 1e-3) for r in best]
    merc = any(r.mercosul for r in best)
    return decode(fuse([r.probs for r in best], weights), br, mercosul=merc)


def _quality(read: PlateRead, br: bool) -> float:
    """Nota de 0 a 1 para comparar leituras da mesma placa (ex.: em ângulos diferentes)."""
    if not read.best:
        return 0.0
    conf = float(np.mean(read.char_conf)) if read.char_conf else 0.0
    return conf * (read.br_fit if br and read.br_fit is not None else 1.0)


def _rotate(img: np.ndarray, angle: float) -> np.ndarray:
    """Gira a imagem sem cortar as bordas."""
    if not angle:
        return img
    M, size = _rotation(img.shape, angle)
    return cv2.warpAffine(img, M, size, flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)


def _plate_size(bw: float, bh: float, theta: float) -> tuple[float, float]:
    """Comprimento e altura de uma placa inclinada theta graus que cabe numa caixa bw x bh."""
    c, s_ = abs(np.cos(np.radians(theta))), abs(np.sin(np.radians(theta)))
    det = c * c - s_ * s_
    if abs(det) > 0.25:
        L, S = (bw * c - bh * s_) / det, (bh * c - bw * s_) / det
        if L > S > 4:
            return L, S
    # perto de 45° a conta fica instável: supõe a proporção típica de placa (3:1)
    L = max(bw / (c + s_ / 3), bh / (s_ + c / 3))
    return L, L / 3


def _contour_angles(ctx: np.ndarray) -> list[float]:
    """Inclinações sugeridas pelo contorno claro da placa (quando ela contrasta com o carro)."""
    gray = cv2.GaussianBlur(cv2.cvtColor(ctx, cv2.COLOR_BGR2GRAY), (3, 3), 0)
    _, th = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    th = cv2.morphologyEx(th, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    out = []
    for c in cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0]:
        _, (rw, rh), _ = cv2.minAreaRect(c)
        if min(rw, rh) > 6 and 1.5 <= max(rw, rh) / min(rw, rh) <= 5 and \
                0.15 * th.size < cv2.contourArea(c) < 0.7 * th.size:
            pts = cv2.boxPoints(cv2.minAreaRect(c))
            p, q = max(((pts[i], pts[(i + 1) % 4]) for i in range(4)),
                       key=lambda e: np.linalg.norm(e[1] - e[0]))
            a = float(np.degrees(np.arctan2(q[1] - p[1], q[0] - p[0])))
            out.append(((a + 90) % 180) - 90)
    return out


def _warp_plate(ctx, center, theta, L, S):
    """Gira o recorte para deixar a placa reta e recorta só ela, ampliada para o OCR."""
    k = max(1.0, 80 / S)
    W, H = max(int(L * k * 1.06), 8), max(int(S * k * 1.2), 8)
    M = cv2.getRotationMatrix2D(center, theta, k)
    M[0, 2] += W / 2 - center[0]
    M[1, 2] += H / 2 - center[1]
    return cv2.warpAffine(ctx, M, (W, H), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)


def straighten(img: np.ndarray, box, br: bool = True):
    """Endireita uma placa inclinada (correção geométrica, sem IA).

    Testa ângulos de -90° a 90° (e os sugeridos pelo contorno da placa), recorta a placa
    reta em cada um e fica com o que o OCR lê melhor. Retorna (recorte reto, caixa da placa
    nele, ângulo) ou None se a placa já estava reta.
    """
    ctx, (bx1, by1, bx2, by2) = _context_crop(img, box, mx=0.15, my=0.15)
    center = ((bx1 + bx2) / 2, (by1 + by2) / 2)
    bw, bh = bx2 - bx1, by2 - by1

    def score(theta):
        L, S = _plate_size(bw, bh, theta)
        crop = _warp_plate(ctx, center, theta, L, S)
        return _quality(decode(ocr_probs([crop])[0], br), br), crop

    tried = {}
    for theta in [*range(-90, 91, 10), *_contour_angles(ctx)]:
        tried[round(theta, 1)] = score(theta)
    best = max(tried, key=lambda t: tried[t][0])
    for theta in np.arange(best - 4, best + 5, 2):  # refina perto do melhor ângulo
        tried.setdefault(round(float(theta), 1), score(theta))
    best = max(tried, key=lambda t: tried[t][0])
    if abs(best) < 3:
        return None  # já estava reta: nada a corrigir
    crop = tried[best][1]
    h, w = crop.shape[:2]
    return crop, (0, 0, w, h), int(round(best))


def read_plates(img_bgr: np.ndarray, variants: bool = True, deblur: bool = True,
                sr: bool = True, br: bool = True) -> list[PlateResult]:
    results = []
    rotated = {}
    for det in detect_any(img_bgr):
        if det.angle not in rotated:
            rotated[det.angle] = _rotate(img_bgr, det.angle)
        img = rotated[det.angle]
        fused, per, _ = read_crop(img, det.rbox, variants, deblur, sr, br)
        angle = det.angle
        if _quality(fused, br) < 0.5:
            # leitura ruim: a placa pode continuar inclinada; tenta endireitar
            found = straighten(img, det.rbox, br)
            if found:
                straight, sbox, extra = found
                f2, p2, _ = read_crop(straight, sbox, variants, deblur, sr, br)
                # só aceita se a leitura ficar boa de verdade (não só "menos ruim")
                if f2.best and f2.best.share >= 0.3 and _quality(f2, br) > _quality(fused, br):
                    fused, per, angle = f2, p2, det.angle + extra
        rw, rh = det.rbox[2] - det.rbox[0], det.rbox[3] - det.rbox[1]
        results.append(PlateResult(det.box, det.conf, fused, per, angle, rw / max(rh, 1)))
    return results


# ---------------- apresentação ----------------

def draw_plates(img_bgr: np.ndarray, plates: list[PlateResult]) -> np.ndarray:
    vis = img_bgr.copy()
    for p in plates:
        x1, y1, x2, y2 = p.box
        best = p.fused.best
        color = (0, 200, 0) if p.trusted else (0, 165, 255)
        cv2.rectangle(vis, (x1, y1), (x2, y2), color, 2)
        legible = not p.fused.illegible
        label = f"{p.fused.masked()} {best.share:.0%}" if legible else "ilegivel"
        (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)
        cv2.rectangle(vis, (x1, max(y1 - th - 10, 0)), (x1 + tw + 6, y1), color, -1)
        cv2.putText(vis, label, (x1 + 3, max(y1 - 6, th)), cv2.FONT_HERSHEY_SIMPLEX, 0.7,
                    (0, 0, 0), 2, cv2.LINE_AA)
    return vis


# ---------------- placa em vídeo (multiquadro) ----------------

def _plate_boxes(frame, angles=(0,)) -> list[tuple[int, int, int, int]]:
    return [(d.box[0], d.box[1], d.box[2] - d.box[0], d.box[3] - d.box[1])
            for d in detect_any(frame, angles)]


def plates_in_frame(frame) -> list[tuple[int, int, int, int]]:
    """Placas do quadro (x, y, w, h), da maior para a menor (inclusive inclinadas)."""
    return sorted(_plate_boxes(frame, SEARCH_ANGLES), key=lambda b: -b[2] * b[3])


@dataclass
class MultiFrameRead:
    single: PlateRead           # só o quadro escolhido (com versões)
    votes: PlateRead            # probabilidades somadas de todos os quadros alinhados
    fused_img: PlateRead        # OCR da imagem fundida
    combined: PlateRead         # votos + imagem fundida
    fusion: object              # FusionResult (imagens)
    per_frame: list[str]        # melhor leitura de cada quadro
    angle: int = 0              # inclinação corrigida na imagem fundida
    final: PlateRead = None     # resultado final: melhores leituras (quadros e imagem combinada)
    view: tuple = None          # (um quadro, combinada) recortados na placa, para mostrar


def read_plate_video(path: str, t: float, near_box: tuple | None = None, n_frames: int = 15,
                     scale: int = 4, iterations: int = 2, br: bool = True) -> MultiFrameRead:
    """Lê a placa do instante t combinando vários quadros.

    near_box (x1, y1, x2, y2): escolhe a placa mais próxima dessa posição; sem ele, a maior.
    """
    from .multiframe import fuse_region, read_frames

    frames, ref_i, _ = read_frames(path, t, n_frames)
    dets = detect_any(frames[ref_i])
    if not dets:
        raise ValueError("Nenhuma placa encontrada nesse momento do vídeo.")
    if near_box is not None:
        cx, cy = (near_box[0] + near_box[2]) / 2, (near_box[1] + near_box[3]) / 2
        dets.sort(key=lambda d: ((d.box[0] + d.box[2]) / 2 - cx) ** 2
                  + ((d.box[1] + d.box[3]) / 2 - cy) ** 2)
    det = dets[0]
    # placa inclinada: gira todos os quadros do mesmo jeito, para ela ficar na horizontal
    frames = [_rotate(f, det.angle) for f in frames]
    x, y = det.rbox[0], det.rbox[1]
    w, h = det.rbox[2] - det.rbox[0], det.rbox[3] - det.rbox[1]

    def centers(f):
        return [np.array([bx + bw / 2, by + bh / 2]) for bx, by, bw, bh in _plate_boxes(f)]

    fr = fuse_region(frames, ref_i, (x, y, w, h), centers, scale, iterations,
                     margin=(0.3, 0.6), planar=True)
    # posição da placa dentro da grade ampliada
    x0, y0 = fr.roi[0], fr.roi[1]
    px1, py1 = (x - x0) * scale, (y - y0) * scale
    px2, py2 = px1 + w * scale, py1 + h * scale

    def plate_of(img):
        return img[py1:py2, px1:px2]

    def view_of(img):  # a placa com uma margem, para o usuário comparar
        mx, my = (px2 - px1) // 3, (py2 - py1) // 2
        return img[max(py1 - my, 0):py2 + my, max(px1 - mx, 0):px2 + mx]

    single, _, _ = read_crop(frames[ref_i], (x, y, x + w, y + h), br=br)
    frame_probs = ocr_probs([plate_of(a) for a in fr.aligned])
    votes = fuse(frame_probs)
    fused_crop = plate_of(fr.fused)
    fused_probs = ocr_probs([fused_crop])[0]
    fused_read, angle = decode(fused_probs, br, mercosul=br and mercosul_band(fused_crop)), 0
    if _quality(fused_read, br) < 0.5:
        # placa inclinada: endireita a imagem combinada e lê de novo
        found = straighten(fr.fused, (px1, py1, px2, py2), br)
        if found:
            straight = decode(ocr_probs([found[0]])[0], br, mercosul=fused_read.mercosul)
            if (straight.best and straight.best.share >= 0.3
                    and _quality(straight, br) > _quality(fused_read, br)):
                fused_read, angle = straight, found[2]
                fused_probs = straight.probs
    frame_reads = [decode(p, br, mercosul=br and mercosul_band(plate_of(a)))
                   for p, a in zip(frame_probs, fr.aligned)]
    # votos dos quadros e leitura da imagem fundida com o mesmo peso
    combined = fuse([votes, fused_probs])
    return MultiFrameRead(
        single=single,
        votes=decode(votes, br),
        fused_img=fused_read,
        combined=decode(combined, br),
        fusion=fr,
        per_frame=[r.best.text if r.best else "?" for r in frame_reads],
        angle=det.angle + angle,
        # quadros estourados ou borrados pesam pouco: só as melhores leituras entram
        final=fuse_reads([single, fused_read, *frame_reads], br),
        view=(view_of(fr.single), view_of(fr.fused)),
    )
