"""Execução de modelos de imagem (super-resolução e restauração) em blocos."""

import cv2
import numpy as np
import torch

from .models import load

def _to_tensor(img_bgr: np.ndarray, dtype, dev) -> torch.Tensor:
    rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    t = torch.from_numpy(rgb).permute(2, 0, 1).float().div(255).unsqueeze(0)
    return t.to(dev, dtype)


def _to_bgr(t: torch.Tensor) -> np.ndarray:
    rgb = t.squeeze(0).float().clamp(0, 1).permute(1, 2, 0).mul(255).round().byte().cpu().numpy()
    return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)


def run_model(img_bgr: np.ndarray, model_name: str, tile: int = 256, pad: int = 16) -> np.ndarray:
    """Aplica o modelo em blocos sobrepostos. Se faltar memória na GPU, tenta blocos menores."""
    while True:
        try:
            return _run_tiled(img_bgr, model_name, tile, pad)
        except torch.cuda.OutOfMemoryError:
            torch.cuda.empty_cache()
            if tile <= 64:
                raise
            tile //= 2


@torch.inference_mode()
def _run_tiled(img_bgr: np.ndarray, model_name: str, tile: int, pad: int) -> np.ndarray:
    model = load(model_name)
    dev, dtype = model.device, model.dtype
    s = model.scale
    mult = model.size_requirements.multiple_of
    h, w = img_bgr.shape[:2]
    x = _to_tensor(img_bgr, dtype, dev)
    out = torch.zeros((1, 3, h * s, w * s), dtype=dtype, device=dev)

    for y0 in range(0, h, tile):
        for x0 in range(0, w, tile):
            y1, x1 = min(y0 + tile, h), min(x0 + tile, w)
            py0, px0 = max(y0 - pad, 0), max(x0 - pad, 0)
            py1, px1 = min(y1 + pad, h), min(x1 + pad, w)
            patch = x[:, :, py0:py1, px0:px1]
            ph, pw = patch.shape[2:]
            eh, ew = -ph % mult, -pw % mult  # alguns modelos exigem múltiplos de 8
            if eh or ew:
                patch = torch.nn.functional.pad(patch, (0, ew, 0, eh), mode="replicate")
            res = model(patch)[:, :, :ph * s, :pw * s]
            oy, ox = (y0 - py0) * s, (x0 - px0) * s
            out[:, :, y0 * s:y1 * s, x0 * s:x1 * s] = \
                res[:, :, oy:oy + (y1 - y0) * s, ox:ox + (x1 - x0) * s]

    return _to_bgr(out)


def upscale(img_bgr: np.ndarray, model_name: str = "realesr-general-x4v3",
            out_scale: float = 4.0, tile: int = 256) -> np.ndarray:
    result = run_model(img_bgr, model_name, tile)
    s = result.shape[1] / img_bgr.shape[1]
    if out_scale != s:
        h, w = img_bgr.shape[:2]
        size = (round(w * out_scale), round(h * out_scale))
        interp = cv2.INTER_AREA if out_scale < s else cv2.INTER_LANCZOS4
        result = cv2.resize(result, size, interpolation=interp)
    return result
