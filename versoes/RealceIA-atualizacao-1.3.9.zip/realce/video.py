"""Vídeo: melhoria quadro a quadro e busca de placas com soma das leituras entre quadros."""

import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

import cv2
import numpy as np

from . import plates as plates_mod
from .upscale import upscale


def _ffmpeg() -> str | None:
    """ffmpeg do sistema ou o que vem no pacote imageio-ffmpeg (Windows não traz ffmpeg)."""
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    try:
        import imageio_ffmpeg

        return imageio_ffmpeg.get_ffmpeg_exe()
    except (ImportError, RuntimeError):
        return None


def _iou(a, b) -> float:
    ix1, iy1, ix2, iy2 = max(a[0], b[0]), max(a[1], b[1]), min(a[2], b[2]), min(a[3], b[3])
    inter = max(0, ix2 - ix1) * max(0, iy2 - iy1)
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / union if union else 0.0


def _open(src: str, start: float = 0, end: float | None = None):
    """Abre o vídeo já no início do trecho. Devolve (cap, fps, primeiro, último quadro + 1);
    último 0 = até o fim (vídeo sem contagem de quadros)."""
    cap = cv2.VideoCapture(src)
    if not cap.isOpened():
        raise ValueError("Não consegui abrir o vídeo.")
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 0
    first = max(0, int(round((start or 0) * fps)))
    last = int(round(end * fps)) if end else total
    if total:
        last = min(last, total)
    if last and first >= last:
        raise ValueError("O trecho escolhido está vazio: o fim precisa vir depois do início.")
    if first:
        cap.set(cv2.CAP_PROP_POS_FRAMES, first)
    return cap, fps, first, last


def fmt_time(t: float) -> str:
    return f"{int(t // 60)}:{t % 60:04.1f}"


def report(progress, label: str, idx: int, first: int, last: int, fps: float):
    """Progresso com o tempo do vídeo ("0:12.4 de 0:45.0"): a página usa esse tempo para
    acompanhar a análise no próprio vídeo."""
    if progress is not None and last:
        progress((idx - first) / max(last - first, 1),
                 desc=f"{label}: {fmt_time(idx / fps)} de {fmt_time(last / fps)}")


def process_video(src: str, upscaler: str = "realesr-general-x4v3", out_scale: float = 2.0,
                  start: float = 0, end: float | None = None, progress=None) -> str:
    """Aumenta a resolução de cada quadro do trecho e devolve o caminho do vídeo novo (com o
    áudio do mesmo trecho)."""
    cap, fps, first, last = _open(src, start, end)
    w, h = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    ow, oh = round(w * out_scale) // 2 * 2, round(h * out_scale) // 2 * 2  # H.264 exige pares

    tmpdir = Path(tempfile.mkdtemp(prefix="realce_"))
    raw_path, out_path = tmpdir / "raw.mp4", tmpdir / "video-melhorado.mp4"
    writer = cv2.VideoWriter(str(raw_path), cv2.VideoWriter_fourcc(*"mp4v"), fps, (ow, oh))
    idx = first
    while not last or idx < last:
        ok, frame = cap.read()
        if not ok:
            break
        out = upscale(frame, upscaler, out_scale)
        if out.shape[:2] != (oh, ow):
            out = cv2.resize(out, (ow, oh))
        writer.write(out)
        idx += 1
        report(progress, "Melhorando", idx, first, last, fps)
    cap.release()
    writer.release()

    ffmpeg = _ffmpeg()
    if ffmpeg:
        # recodifica para H.264 (toca em qualquer lugar) e reaproveita o áudio original
        subprocess.run([ffmpeg, "-y", "-loglevel", "error", "-i", str(raw_path),
                        "-ss", f"{first / fps:.3f}", "-i", src,
                        "-map", "0:v", "-map", "1:a?", "-c:v", "libx264", "-crf", "18",
                        "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", str(out_path)],
                       check=True)
    else:
        raw_path.rename(out_path)
    return str(out_path)


@dataclass
class PlateTrack:
    box: tuple
    first_frame: int
    last_frame: int
    reads: list = field(default_factory=list)  # leitura de cada quadro em que a placa apareceu
    best_frame: int = 0                        # quadro com a leitura mais nítida
    best_box: tuple = (0, 0, 0, 0)
    best_q: float = -1.0
    aspects: list = field(default_factory=list)
    history: list = field(default_factory=list)  # (quadro, caixa) de cada detecção

    def add(self, read: plates_mod.PlateRead, idx: int, box: tuple, br: bool):
        self.reads.append(read)
        # o melhor quadro é o de leitura mais nítida, não o de placa maior: de perto, o farol
        # costuma estourar a placa no branco
        q = plates_mod._quality(read, br)
        if q > self.best_q:
            self.best_q, self.best_frame, self.best_box = q, idx, box

    def result(self, br: bool) -> plates_mod.PlateRead:
        return plates_mod.fuse_reads(self.reads, br)


@dataclass
class FoundPlate:
    read: plates_mod.PlateRead
    reads: int
    start: float
    end: float
    t_best: float
    box_best: tuple  # x1, y1, x2, y2 no quadro t_best
    vehicle: object = None  # vehicle.Vehicle, se identificado


def _identify_vehicles(src: str, tracks, found, progress=None):
    """Identifica o veículo de cada placa usando até 3 quadros: o mais nítido, o do meio e o último."""
    from . import vehicle as vehicle_mod

    cap = cv2.VideoCapture(src)
    for n, (t, f) in enumerate(zip(tracks, found), 1):
        if progress is not None:
            progress(n / len(found), desc=f"Identificando o veículo {n} de {len(found)}")
        hist = t.history
        picks = {t.best_frame: t.best_box, hist[len(hist) // 2][0]: hist[len(hist) // 2][1],
                 hist[-1][0]: hist[-1][1]}
        samples = []
        for idx, box in picks.items():
            cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
            ok, frame = cap.read()
            if ok:
                samples.append((frame, box))
        f.vehicle = vehicle_mod.identify(samples)
    cap.release()


def scan_plates(src: str, every: int = 3, br: bool = True, start: float = 0,
                end: float | None = None, progress=None, vehicles: bool = True) -> list[FoundPlate]:
    """Procura as placas do trecho do vídeo e soma as leituras de cada uma ao longo dos quadros."""
    cap, fps, first, last = _open(src, start, end)
    tracks: list[PlateTrack] = []
    idx = first
    while not last or idx < last:
        ok, frame = cap.read()
        if not ok:
            break
        if idx % every == 0:
            for p in plates_mod.read_plates(frame, variants=False, br=br):
                match = max(tracks, key=lambda t: _iou(t.box, p.box), default=None)
                if (match is None or _iou(match.box, p.box) < 0.25
                        or idx - match.last_frame > every * 10):
                    match = PlateTrack(p.box, idx, idx)
                    tracks.append(match)
                match.box, match.last_frame = p.box, idx
                match.add(p.fused, idx, p.box, br)
                match.aspects.append(p.aspect)
                match.history.append((idx, p.box))
        idx += 1
        report(progress, "Procurando placas", idx, first, last, fps)
    cap.release()

    found, kept = [], []
    for t in sorted(tracks, key=lambda t: t.first_frame):
        if len(t.reads) < 2:  # detecção solta, vista uma vez só
            continue
        # caixa "quadrada" que nunca rendeu leitura: não é placa (ex.: um veículo inteiro);
        # placas de moto também são quase quadradas, mas costumam render alguma leitura
        if np.median(t.aspects) < 1.3 and t.best_q < 0.05:
            continue
        found.append(FoundPlate(t.result(br), len(t.reads), t.first_frame / fps,
                                t.last_frame / fps, t.best_frame / fps, t.best_box))
        kept.append(t)
    if vehicles and found:
        _identify_vehicles(src, kept, found, progress)
    return found
