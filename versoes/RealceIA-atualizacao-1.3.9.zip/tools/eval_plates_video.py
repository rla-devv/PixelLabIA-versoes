"""Avalia a leitura de placas em vídeo com placas sintéticas degradadas.

Uso: python tools/eval_plates_video.py [n_placas] [fator_de_reducao]
Compara: um quadro só (sem e com versões), votos entre quadros, imagem fundida e combinação.
"""

import random
import subprocess
import sys
import tempfile
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from synth_plates import degrade, paste_plate, random_text, render_plate  # noqa: E402

from realce import plates  # noqa: E402
from realce.multiframe import read_frames  # noqa: E402

N = int(sys.argv[1]) if len(sys.argv) > 1 else 20
FACTOR = float(sys.argv[2]) if len(sys.argv) > 2 else 7
FRAMES = 15
ROOT = Path(__file__).resolve().parent.parent

scene = cv2.imread(str(ROOT / "samples/plate.png"))
# a placa sintética é colada por cima da placa real da cena (ampliada 3x)
px, py, pw, ph = (3 * v for v in plates._plate_boxes(scene)[0])  # só a detecção reta
scene = cv2.resize(scene, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
quad = np.float32([[px, py], [px + pw, py], [px + pw, py + ph], [px, py + ph]])

rng, nrng = random.Random(7), np.random.default_rng(7)
methods = ["um quadro (original)", "um quadro (versões)", "votos entre quadros",
           "imagem fundida", "votos + fundida"]
hits = {m: 0 for m in methods}
top3 = {m: 0 for m in methods}
chars = {m: 0 for m in methods}
tmp = Path(tempfile.mkdtemp())
for k in range(N):
    layout = rng.choice(["Mercosul", "Antiga"])
    truth = random_text(layout, rng)
    hr = paste_plate(scene, render_plate(truth, layout), quad)
    for i in range(FRAMES):
        shift = (0, 0) if i == FRAMES // 2 else nrng.uniform(-1.5 * FACTOR, 1.5 * FACTOR, 2)
        cv2.imwrite(str(tmp / f"{i:03d}.png"), degrade(hr, FACTOR, 5, nrng, tuple(shift)))
    video = tmp / "v.mp4"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-framerate", "15", "-i",
                    str(tmp / "%03d.png"), "-vf", "pad=ceil(iw/2)*2:ceil(ih/2)*2",
                    "-c:v", "libx264", "-crf", "23", "-pix_fmt", "yuv420p", str(video)],
                   check=True)
    try:
        r = plates.read_plate_video(str(video), (FRAMES // 2) / 15, n_frames=FRAMES)
    except ValueError:
        print(f"{truth}: placa não detectada")
        continue
    reads = {
        "um quadro (original)": None,  # preenchido abaixo
        "um quadro (versões)": r.single,
        "votos entre quadros": r.votes,
        "imagem fundida": r.fused_img,
        "votos + fundida": r.combined,
    }
    # leitura só do recorte original do quadro escolhido
    frames, ref_i, _ = read_frames(str(video), (FRAMES // 2) / 15, 1)
    b = plates.plates_in_frame(frames[ref_i])[0]
    _, per, _ = plates.read_crop(frames[ref_i], (b[0], b[1], b[0] + b[2], b[1] + b[3]),
                                 variants=False)
    reads["um quadro (original)"] = per["original"]
    line = []
    for m, rd in reads.items():
        texts = [c.text for c in rd.candidates[:3]]
        hits[m] += bool(texts and texts[0] == truth)
        top3[m] += truth in texts
        if texts:
            chars[m] += sum(a == b for a, b in zip(texts[0], truth)) / len(truth)
        line.append(texts[0] if texts else "?")
    print(truth, "|", " ".join(line), f"| quadros usados {r.fusion.used}/{r.fusion.tried}")

print(f"\nPlacas: {N} · redução {FACTOR}× (placa com ~{pw / FACTOR:.0f}×{ph / FACTOR:.0f} px)")
for m in methods:
    print(f"{m:24s} placa inteira {hits[m] / N:5.0%} · entre as 3 primeiras {top3[m] / N:5.0%}"
          f" · caracteres certos {chars[m] / N:5.0%}")
