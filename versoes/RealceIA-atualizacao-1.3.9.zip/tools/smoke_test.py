"""Teste rápido de instalação: confere bibliotecas, modelos e a interface.

Uso: .venv\\Scripts\\python.exe tools\\smoke_test.py
"""

import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tools"))

import cv2  # noqa: E402
import numpy as np  # noqa: E402
import torch  # noqa: E402

from realce import faces, plates  # noqa: E402
from realce.faithful import faithful_enhance  # noqa: E402
from realce.models import device, gpu_info  # noqa: E402
from realce.upscale import upscale  # noqa: E402
from synth_plates import render_plate  # noqa: E402


def step(name, fn):
    t = time.time()
    result = fn()
    print(f"OK  {name} ({time.time() - t:.1f}s)", flush=True)
    return result


print(f"Python {sys.version.split()[0]} · torch {torch.__version__} · dispositivo {device()}"
      f" · GPU {gpu_info()}", flush=True)

img = cv2.resize(render_plate("RLA2E26", "Mercosul"), (200, 65), interpolation=cv2.INTER_AREA)
step("super-resolução generativa", lambda: upscale(img, "realesr-general-x4v3", 2))
step("super-resolução fiel", lambda: faithful_enhance(img, "swinir-psnr-x4", 2))
step("detecção de rostos", lambda: faces.detect_faces(np.zeros((128, 128, 3), np.uint8)))
step("restauração de rosto", lambda: faces._restore_crop(np.zeros((512, 512, 3), np.uint8),
                                                          "codeformer", 0.7))
read = step("OCR de placa", lambda: plates.decode(plates.ocr_probs([img])[0]))
step("identificação de veículo", lambda: __import__("realce.vehicle", fromlist=["x"]).identify(
    [(cv2.copyMakeBorder(img, 200, 40, 200, 200, cv2.BORDER_REPLICATE), (200, 200, 400, 265))]))
assert read.best and read.best.text == "RLA2E26", f"OCR leu {read.best}"


def serve():
    import app

    app.demo.queue().launch(server_name="127.0.0.1", prevent_thread_lock=True,
                            **app.launch_options())
    with urllib.request.urlopen(app.demo.local_url, timeout=30) as r:
        assert r.status == 200
    app.demo.close()


step("interface", serve)
if sys.platform == "win32":
    step("janela própria (pywebview)", lambda: __import__("webview"))
print("Tudo certo.")
