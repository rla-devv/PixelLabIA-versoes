"""Gera placas brasileiras sintéticas (Mercosul e antiga) e cenas/vídeos degradados para testes.

Não substitui fotos reais: a fonte não é a FE-Schrift oficial. Serve para medir, de forma
controlada, quanto cada técnica ajuda quando a placa fica pequena e com ruído.
"""

import random
import string

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"
SMALL = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"


def random_text(layout: str, rng: random.Random) -> str:
    L, D = string.ascii_uppercase, string.digits
    mid = rng.choice(L) if layout == "Mercosul" else rng.choice(D)
    return "".join(rng.choices(L, k=3)) + rng.choice(D) + mid + "".join(rng.choices(D, k=2))


def render_plate(text: str, layout: str, width: int = 400) -> np.ndarray:
    h = int(width * 130 / 400)
    if layout == "Mercosul":
        img = Image.new("RGB", (width, h), "white")
        d = ImageDraw.Draw(img)
        band = int(h * 0.24)
        d.rectangle([0, 0, width, band], fill=(0, 51, 153))
        f = ImageFont.truetype(SMALL, int(band * 0.7))
        d.text((width / 2, band / 2), "BRASIL", font=f, fill="white", anchor="mm")
        top = band
    else:
        img = Image.new("RGB", (width, h), (200, 200, 200))
        d = ImageDraw.Draw(img)
        f = ImageFont.truetype(SMALL, int(h * 0.15))
        d.text((width / 2, h * 0.12), "SP-SAO PAULO", font=f, fill="black", anchor="mm")
        top = int(h * 0.24)
        text = text[:3] + "-" + text[3:]
    d.rectangle([0, 0, width - 1, h - 1], outline="black", width=max(2, width // 100))
    # texto desenhado largo e depois comprimido na horizontal (fonte "condensada")
    big = ImageFont.truetype(FONT, int((h - top) * 0.95))
    tw = d.textbbox((0, 0), text, font=big)
    glyph = Image.new("L", (tw[2] - tw[0] + 4, tw[3] - tw[1] + 4), 0)
    ImageDraw.Draw(glyph).text((2 - tw[0], 2 - tw[1]), text, font=big, fill=255)
    gw = int(width * 0.9)
    gh = int((h - top) * 0.78)
    glyph = glyph.resize((gw, gh), Image.LANCZOS)
    ox, oy = (width - gw) // 2, top + ((h - top) - gh) // 2
    img.paste((0, 0, 0), (ox, oy, ox + gw, oy + gh), glyph)
    return cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)


def paste_plate(scene: np.ndarray, plate: np.ndarray, quad: np.ndarray) -> np.ndarray:
    """Cola a placa na cena dentro do quadrilátero (4 cantos, sentido horário)."""
    h, w = plate.shape[:2]
    src = np.float32([[0, 0], [w, 0], [w, h], [0, h]])
    H = cv2.getPerspectiveTransform(src, np.float32(quad))
    size = (scene.shape[1], scene.shape[0])
    warped = cv2.warpPerspective(plate, H, size, flags=cv2.INTER_AREA)
    mask = cv2.warpPerspective(np.full((h, w), 255, np.uint8), H, size, flags=cv2.INTER_AREA)
    a = (mask.astype(np.float32) / 255)[..., None]
    return (scene * (1 - a) + warped * a).astype(np.uint8)


def degrade(img: np.ndarray, factor: float, noise: float, rng: np.random.Generator,
            shift=(0.0, 0.0), blur: float = 1.0, jpeg: int | None = 60) -> np.ndarray:
    """Simula câmera distante: desloca (sub-pixel), desfoca, reduz, adiciona ruído e compressão."""
    M = np.float32([[1, 0, shift[0]], [0, 1, shift[1]]])
    x = cv2.warpAffine(img, M, (img.shape[1], img.shape[0]), flags=cv2.INTER_CUBIC,
                       borderMode=cv2.BORDER_REFLECT)
    x = cv2.GaussianBlur(x, (0, 0), blur * factor / 2)
    x = cv2.resize(x, None, fx=1 / factor, fy=1 / factor, interpolation=cv2.INTER_AREA)
    x = np.clip(x + rng.normal(0, noise, x.shape), 0, 255).astype(np.uint8)
    if jpeg:
        x = cv2.imdecode(cv2.imencode(".jpg", x, [cv2.IMWRITE_JPEG_QUALITY, jpeg])[1], 1)
    return x
