"""Identidade visual do RealceIA (tema, estilos, cabeçalho e balões de ajuda)."""
