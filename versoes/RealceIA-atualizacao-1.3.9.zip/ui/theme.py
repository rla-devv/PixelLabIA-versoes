"""Tema do Gradio no padrão visual dos apps da RLA.dev (o mesmo do Enxuto)."""

import json
from pathlib import Path

import gradio as gr

HERE = Path(__file__).resolve().parent

# paleta: escuro (padrão) e claro
DARK = dict(bg="#0b1716", surface="#10211f", surface2="#152b28", line="#22413c",
            text="#e6f1ee", muted="#93ada8", accent="#41d1b6", accent_ink="#05231d")
LIGHT = dict(bg="#f2f7f6", surface="#ffffff", surface2="#e9f2f0", line="#d3e3e0",
             text="#11211f", muted="#55706b", accent="#0e9c84", accent_ink="#ffffff")


def _pair(key):
    return LIGHT[key], DARK[key]


def build_theme() -> gr.themes.Base:
    t = gr.themes.Base(
        primary_hue=gr.themes.colors.teal,
        neutral_hue=gr.themes.colors.slate,
        font=[gr.themes.GoogleFont("Figtree", weights=(400, 500, 700, 800)), "Segoe UI", "system-ui", "sans-serif"],
        radius_size=gr.themes.sizes.radius_lg,
    )
    values = {}
    for name, key in [
        ("body_background_fill", "bg"),
        ("background_fill_primary", "surface"),
        ("background_fill_secondary", "surface2"),
        ("block_background_fill", "surface"),
        ("block_border_color", "line"),
        ("border_color_primary", "line"),
        ("body_text_color", "text"),
        ("block_title_text_color", "text"),
        ("block_label_text_color", "muted"),
        ("body_text_color_subdued", "muted"),
        ("input_background_fill", "surface2"),
        ("input_border_color", "line"),
        ("block_label_background_fill", "surface2"),
        ("button_secondary_background_fill", "surface2"),
        ("button_secondary_background_fill_hover", "line"),
        ("button_secondary_border_color", "line"),
        ("button_secondary_text_color", "text"),
        ("button_primary_background_fill", "accent"),
        ("button_primary_background_fill_hover", "accent"),
        ("button_primary_text_color", "accent_ink"),
        ("slider_color", "accent"),
        ("checkbox_background_color_selected", "accent"),
        ("checkbox_border_color_selected", "accent"),
        ("color_accent_soft", "surface2"),
        ("table_even_background_fill", "surface"),
        ("table_odd_background_fill", "surface2"),
        ("table_border_color", "line"),
    ]:
        light, dark = _pair(key)
        values[name] = light
        values[name + "_dark"] = dark
    t.set(**values, color_accent=DARK["accent"], block_shadow="none", block_shadow_dark="none",
          button_large_radius="999px", button_medium_radius="999px",
          button_small_radius="999px", block_border_width="1px")
    return t


def css() -> str:
    return (HERE / "style.css").read_text(encoding="utf-8")


def head(help_texts: dict[str, str], version: str) -> str:
    """Script dos balões de ajuda, do tema e da busca de atualização, com os dados embutidos."""
    js = (HERE / "ui.js").read_text(encoding="utf-8")
    data = {"help": help_texts, "version": version}
    return f"<script>window.REALCE = {json.dumps(data, ensure_ascii=False)};\n{js}</script>"
