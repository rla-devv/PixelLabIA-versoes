__version__ = "1.5.2"

# as versões novas são publicadas em rla-devv/realceia-versoes (ver realce/atualizacao.py)
