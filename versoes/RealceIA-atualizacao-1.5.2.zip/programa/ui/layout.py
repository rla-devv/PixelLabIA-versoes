"""Blocos de HTML fixos: cabeçalho, chamada principal, cartões das ferramentas e rodapé."""

import base64
from html import escape
from pathlib import Path

ASSETS = Path(__file__).resolve().parent.parent / "assets"

ICONS = {
    "logo": '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/><path d="M11 8v6M8 11h6"/>',
    "heart": '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2'
             '-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>',
    "moon": '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
    "sun": '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41'
           'M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/>',
    "check": '<path d="M20 6 9 17l-5-5"/>',
    "shield": '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1'
              'c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/>'
              '<path d="m9 12 2 2 4-4"/>',
    "alert": '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/>'
             '<path d="M12 9v4"/><path d="M12 17h.01"/>',
    "image": '<rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="9" cy="9" r="2"/>'
             '<path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>',
    "face": '<path d="M3 7V5a2 2 0 0 1 2-2h2"/><path d="M17 3h2a2 2 0 0 1 2 2v2"/>'
            '<path d="M21 17v2a2 2 0 0 1-2 2h-2"/><path d="M7 21H5a2 2 0 0 1-2-2v-2"/>'
            '<path d="M8 14s1.5 2 4 2 4-2 4-2"/><path d="M9 9h.01"/><path d="M15 9h.01"/>',
    "plate": '<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 12h2"/><path d="M10 12h2"/>'
             '<path d="M14 12h4"/>',
    "video": '<path d="m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.47.47 0 0 0-.75-.39L16 10.5"/>'
             '<rect x="2" y="6" width="14" height="12" rx="2"/>',
    "film": '<rect width="18" height="18" x="3" y="3" rx="2"/>'
            '<path d="M7 3v18M3 7.5h4M3 12h18M3 16.5h4M17 3v18M17 7.5h4M17 16.5h4"/>',
    "refresh": '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/>'
               '<path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
    "person": '<circle cx="12" cy="7" r="4"/><path d="M5 21v-2a7 7 0 0 1 14 0v2"/>',
    "chip": '<rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/>'
            '<path d="M15 2v2M15 20v2M2 15h2M2 9h2M20 15h2M20 9h2M9 2v2M9 20v2"/>',
}

DONATE_URL = "https://link.mercadopago.com.br/rladevapps"


def icon(name: str) -> str:
    return (f'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" '
            f'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">{ICONS[name]}</svg>')


# ferramentas: (id, ícone, título, descrição curta)
PHOTO_TOOLS = [
    ("foto", "image", "Melhorar foto", "Deixa a foto maior e mais nítida; pode melhorar rostos."),
    ("placas", "plate", "Ler placa", "Lê a placa e identifica tipo, cor e possível modelo do veículo."),
]
VIDEO_TOOLS = [
    ("video", "film", "Melhorar vídeo", "Aumenta a resolução do vídeo, quadro a quadro."),
    ("placas-video", "plate", "Placas no vídeo", "Encontra as placas e os veículos do vídeo e lê cada placa com precisão."),
    ("pessoas-video", "person", "Pessoas no vídeo", "Encontra as pessoas e deixa cabeça e tronco mais nítidos combinando quadros."),
]


def logo_img(cls: str = "rl-logo-img") -> str:
    """Ícone do app embutido na página (o mesmo do atalho)."""
    png = ASSETS / "realceia-icone-128.png"
    if not png.exists():
        return f'<div class="rl-logo">{icon("logo")}</div>'
    data = base64.b64encode(png.read_bytes()).decode()
    return f'<img class="{cls}" src="data:image/png;base64,{data}" alt="" width="36" height="36">'


def header(name: str, tagline: str, version: str) -> str:
    return f"""
<header class="rl-header">
  <div class="rl-brand">
    {logo_img()}
    <div>
      <div><span class="rl-name">{name}</span> <span class="rl-tagline"><span class="rl-dash">- </span>{escape(tagline)} diretamente no seu computador.</span></div>
      <div class="rl-sub">Desenvolvido por RLA.dev · versão {version}</div>
    </div>
  </div>
  <nav class="rl-actions" aria-label="Ações">
    <button class="rl-btn" type="button" data-action="donate" title="Apoie o projeto">{icon("heart")}<span>Apoie o projeto</span></button>
    <button class="rl-btn" type="button" data-action="update" title="Buscar atualização">{icon("refresh")}<span class="rl-upd-label">Buscar atualização</span></button>
    <button class="rl-btn" type="button" data-action="theme" title="Trocar o tema"><span class="rl-ic-sun">{icon("sun")}</span><span class="rl-ic-moon">{icon("moon")}</span><span class="rl-theme-label">Tema escuro</span></button>
  </nav>
</header>
<div id="rl-backdrop" class="rl-backdrop" data-action="modal-close"></div>
<section id="rl-donate" class="rl-donate" role="dialog" aria-modal="true" aria-labelledby="rl-donate-t">
  <button class="rl-modal-x" type="button" data-action="donate-close" aria-label="Fechar">×</button>
  <h3 id="rl-donate-t">Apoie o projeto</h3>
  <p><b>O {name} é gratuito e continua sendo.</b> Ele é mantido pela RLA.dev no tempo livre.
  Se ele te ajudou, uma doação de qualquer valor ajuda a manter o projeto e a criar novas ferramentas.</p>
  <ul>
    <li>A doação é feita no site do Mercado Pago, por <b>PIX</b>, cartão ou saldo, e não precisa de conta.</li>
    <li>Não é necessário doar para usar nenhuma função do app.</li>
  </ul>
  <div class="rl-row">
    <a class="rl-btn rl-btn-solid" href="{DONATE_URL}" target="_blank" rel="noopener">Doar pelo Mercado Pago</a>
    <button class="rl-btn rl-btn-ghost" type="button" data-action="donate-close">Fechar</button>
  </div>
  <small>Se o link não abrir, copie o endereço: <code>{DONATE_URL}</code></small>
</section>
<section id="rl-update" class="rl-donate" role="dialog" aria-modal="true" aria-live="polite" aria-label="Atualização"></section>
<section id="rl-privacy" class="rl-donate" role="dialog" aria-modal="true" aria-labelledby="rl-privacy-t">
  <button class="rl-modal-x" type="button" data-action="modal-close" aria-label="Fechar">×</button>
  <h3 id="rl-privacy-t">Seus arquivos não saem do computador</h3>
  <p>Todas as fotos e vídeos são processados no seu próprio computador. Nenhum arquivo e nenhum dado
  seu é enviado para a internet.</p>
  <p>A internet só é usada para:</p>
  <ul>
    <li>instalar, uma única vez: o Python, os componentes do programa e os modelos de IA (cerca de 6 GB);</li>
    <li>ver se há versão nova do {name}, ao abrir e a cada 15 minutos (só consulta o número da versão);</li>
    <li>baixar a versão nova, quando você clica em Atualizar agora.</li>
  </ul>
  <p>Depois de instalado, o {name} funciona sem internet.</p>
  <div class="rl-row"><button class="rl-btn rl-btn-solid" type="button" data-action="modal-close">Entendi</button></div>
</section>
"""


def hero(device_text: str) -> str:
    return f"""
<section class="rl-hero">
  <h1>Imagens mais nítidas, <em>direto no seu PC.</em></h1>
  <div class="rl-hero-text">
    <p>Melhore fotos e vídeos e leia placas de veículos.
    Escolha uma ferramenta, envie o arquivo e baixe o resultado.</p>
    <button class="rl-privacy" type="button" data-action="privacy">
      <span>{icon("check")}Funciona sem internet</span>
      <span>{icon("check")}Nenhum arquivo é enviado para fora do seu computador</span>
      <span class="more">Saiba mais ›</span>
    </button>
    <p class="rl-device">{device_text}</p>
  </div>
</section>
"""


def _cards(tools) -> str:
    out = []
    for tid, ic, title, desc in tools:
        out.append(f'<button class="rl-card" type="button" data-tab="{tid}" aria-pressed="false">'
                   f'<span class="ic">{icon(ic)}</span><span><b>{title}</b><small>{desc}</small></span>'
                   f'</button>')
    return "".join(out)


def tool_nav() -> str:
    return f"""
<section class="rl-nav" aria-label="Ferramentas">
  <h2>O que você quer fazer?</h2>
  <p>Passe o mouse ou toque no <b>?</b> ao lado de cada opção para ver o que ela faz.</p>
  <div class="rl-groups">
    <div class="rl-group"><h3>{icon("image")}Fotos</h3><div class="rl-cards">{_cards(PHOTO_TOOLS)}</div></div>
    <div class="rl-group"><h3>{icon("video")}Vídeos</h3><div class="rl-cards">{_cards(VIDEO_TOOLS)}</div></div>
  </div>
</section>
"""


def tool_head(title: str, desc: str, steps: list[str], warning: str | None = None) -> str:
    items = "".join(f"<li>{s}</li>" for s in steps)
    warn = (f'<div class="rl-note warn" style="margin-top:14px">{icon("alert")}<div>{warning}</div></div>'
            if warning else "")
    return (f'<section class="rl-tool"><h2>{title}</h2><p>{desc}</p>'
            f'<ol class="rl-steps" aria-label="Como usar">{items}</ol>{warn}</section>')


def col_title(text: str) -> str:
    return f'<div class="rl-col-title">{text}</div>'


def footer(name: str, version: str) -> str:
    return (f'<div class="rl-foot">{name} {version} · Desenvolvido por RLA.dev · '
            f'Os modelos de IA podem errar: confira sempre o resultado.</div>')
