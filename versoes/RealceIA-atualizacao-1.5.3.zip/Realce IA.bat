@echo off
cd /d "%~dp0"
rem codigo do app: na subpasta "programa" (desde a 1.5.0) ou nesta pasta
set "PROG=%~dp0"
if exist "%~dp0programa\realceia.pyw" set "PROG=%~dp0programa\"
if exist ".venv\Scripts\pythonw.exe" goto :abrir
echo O Realce IA ainda nao foi instalado. Rode instalar.bat primeiro.
pause
exit /b 1
:abrir
start "" ".venv\Scripts\pythonw.exe" "%PROG%realceia.pyw" %*
