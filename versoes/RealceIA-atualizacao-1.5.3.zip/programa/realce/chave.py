"""Senha da sessão: só a janela do Realce IA usa o servidor local.

O lançador sorteia uma senha a cada abertura e a passa ao servidor (variável REALCE_CHAVE). A
janela abre o endereço com ?chave=<senha> uma vez; o servidor confere, guarda a senha num cookie
"só para o próprio site" e tira a senha do endereço. Daí em diante, todo pedido sem o cookie
certo é recusado. Um site aberto no navegador que descubra a porta não sabe a senha, e o
navegador não manda o cookie em pedidos que partem de outra página.

Sem REALCE_CHAVE (python app.py direto, ou um lançador antigo) não há conferência.
"""

import secrets
from http.cookies import SimpleCookie
from urllib.parse import parse_qsl, urlencode

LIVRES = {"/api/saude"}  # o lançador e a espera da página consultam sem cookie (só ok + versão)


def nova() -> str:
    return secrets.token_urlsafe(32)


def proteger(app, chave: str | None, porta: int):
    """Envolve o app ASGI: recusa pedidos sem a senha da sessão."""
    if not chave:
        return app
    nome = f"realce_chave_{porta}"  # cookies não separam portas: o nome separa

    def confere(valor: str | None) -> bool:
        return bool(valor) and secrets.compare_digest(valor, chave)

    async def protegido(scope, receive, send):
        if scope["type"] not in ("http", "websocket") or scope.get("path") in LIVRES:
            return await app(scope, receive, send)
        cabecalhos = {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in scope.get("headers", [])}
        cookie = SimpleCookie(cabecalhos.get("cookie", ""))
        if nome in cookie and confere(cookie[nome].value):
            return await app(scope, receive, send)
        consulta = parse_qsl(scope.get("query_string", b"").decode("latin-1"), keep_blank_values=True)
        dada = next((v for k, v in consulta if k == "chave"), None)
        if scope["type"] == "http" and confere(dada):
            # guarda a senha no cookie e volta ao mesmo endereço, sem a senha
            resto = urlencode([(k, v) for k, v in consulta if k != "chave"])
            destino = (scope.get("root_path", "") + scope["path"]) + (f"?{resto}" if resto else "")
            await send({"type": "http.response.start", "status": 303, "headers": [
                (b"location", destino.encode("latin-1")),
                (b"set-cookie", f"{nome}={chave}; Path=/; HttpOnly; SameSite=Strict".encode("latin-1")),
                (b"cache-control", b"no-store"),
            ]})
            await send({"type": "http.response.body", "body": b""})
            return
        if scope["type"] == "websocket":
            await send({"type": "websocket.close", "code": 1008})
            return
        corpo = ("Acesso negado. Abra o Realce IA pelo atalho na Área de Trabalho ou no Menu "
                 "Iniciar.").encode("utf-8")
        await send({"type": "http.response.start", "status": 403, "headers": [
            (b"content-type", b"text/plain; charset=utf-8"), (b"cache-control", b"no-store")]})
        await send({"type": "http.response.body", "body": corpo})

    return protegido
