@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"
title Realce IA - Instalação

rem Downloads grandes (Python, PyTorch, bibliotecas e modelos) ficam numa pasta fixa do usuario,
rem compartilhada por qualquer pasta do Realce IA: reinstalar ou atualizar nao baixa tudo de novo.
set "RT=%~dp0.runtime"
set "DADOS=%LOCALAPPDATA%\RealceIA"
set "REALCE_DADOS=%DADOS%"
set "UV=%DADOS%\uv\uv.exe"
rem versao fixa do uv e o SHA-256 publicado com ela: nada de fora entra sem conferencia
set "REALCE_UV_VERSAO=0.12.24"
set "REALCE_UV_SHA256=7c38608c8a18ee137d748a1773053b07ec8f3a30fab49aebaa6f4e4efeceb019"
set "UV_CACHE_DIR=%DADOS%\cache"
set "UV_PYTHON_INSTALL_DIR=%DADOS%\python"
set "PY=%~dp0.venv\Scripts\python.exe"
if not exist "%DADOS%" mkdir "%DADOS%"

rem instalacoes antigas guardavam o cache de downloads nesta pasta: aproveita
if exist "%RT%\cache" if not exist "%UV_CACHE_DIR%" robocopy "%RT%\cache" "%UV_CACHE_DIR%" /E /MOVE /NFL /NDL /NJH /NJS /NP >nul
if exist "%RT%\uv\uv.exe" if not exist "%UV%" robocopy "%RT%\uv" "%DADOS%\uv" /E /NFL /NDL /NJH /NJS /NP >nul

echo.
echo  Realce IA - Melhoria de fotos e vídeos e leitura de placas diretamente no seu computador
echo.
echo  A internet é usada só durante a instalação, para baixar o Python, os componentes do programa e os modelos de IA.
echo  Depois de instalado, o Realce IA funciona sem internet.
echo.
echo  Na primeira vez neste computador leva de 20 a 40 minutos (cerca de 6 GB de downloads).
echo  Depois disso, reinstalar ou atualizar reaproveita o que já foi baixado.
echo  Os arquivos grandes ficam em %DADOS%
echo.

rem aberto de dentro do ZIP, o Windows roda o instalador numa pasta temporaria
echo "%~dp0" | find /i "\AppData\Local\Temp\" >nul
if errorlevel 1 goto :fora_do_zip
echo  ERRO: parece que o instalador foi aberto de dentro do arquivo ZIP.
echo  Clique com o botão direito no ZIP, escolha "Extrair tudo" e rode o instalar.bat
echo  da pasta extraída.
goto :erro_fim
:fora_do_zip

rem ---------- internet: a instalacao precisa dela para baixar os componentes ----------
powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol='Tls12'; try { $null = Invoke-WebRequest -UseBasicParsing -TimeoutSec 20 'https://raw.githubusercontent.com/rla-devv/realceia-versoes/main/atualizacao.json'; exit 0 } catch { if ($_.Exception.Response) { exit 0 } else { exit 1 } }"
if not errorlevel 1 goto :tem_internet
echo  Sem conexão com a internet. A instalação precisa de internet para baixar os componentes do
echo  programa (só desta vez). Conecte o computador à internet e rode este arquivo de novo.
goto :erro_fim
:tem_internet

rem ---------- 0. o programa: baixa a versao publicada mais nova ----------
rem O pacote de instalacao traz so este arquivo. O resto vem do repositorio de versoes,
rem conferido pelo SHA-256 como nas atualizacoes.
if exist "%~dp0programa\app.py" goto :tem_programa
if exist "%~dp0app.py" goto :tem_programa
echo [0/6] Baixando o Realce IA...
set "APP=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; $base=$env:REALCE_VERSOES_URL; if(-not $base){$base='https://raw.githubusercontent.com/rla-devv/realceia-versoes/main'}; $i=Invoke-RestMethod ($base+'/atualizacao.json?t='+[DateTimeOffset]::UtcNow.ToUnixTimeSeconds()); if($i.arquivo -notmatch '^[A-Za-z0-9._-]+\.zip$'){throw 'nome de pacote invalido'}; $z=Join-Path $env:DADOS 'pacote.zip'; $t=Join-Path $env:DADOS 'pacote'; Invoke-WebRequest ($base+'/versoes/'+$i.arquivo) -OutFile $z; if((Get-Item $z).Length -ne [long]$i.tamanho -or (Get-FileHash $z -Algorithm SHA256).Hash -ne $i.sha256.ToUpper()){throw 'o pacote baixado nao confere (SHA-256)'}; if(Test-Path $t){Remove-Item -Recurse -Force $t}; Expand-Archive $z $t; $novo=Join-Path $t 'instalar.bat'; $este=Join-Path $env:APP 'instalar.bat'; if((Test-Path $novo) -and (Get-FileHash $novo).Hash -ne (Get-FileHash $este).Hash){Copy-Item $novo (Join-Path $env:DADOS 'instalar-novo.bat') -Force}; Write-Host ('    versao '+$i.versao)"
if errorlevel 1 goto :erro
robocopy "%DADOS%\pacote" "%~dp0." /E /XF instalar.bat /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 goto :erro
rmdir /s /q "%DADOS%\pacote"
del /q "%DADOS%\pacote.zip"
rem o pacote trouxe um instalador mais novo: troca e roda ele (numa linha so, lida antes da troca)
if exist "%DADOS%\instalar-novo.bat" move /y "%DADOS%\instalar-novo.bat" "%~f0" >nul & "%~f0" %*
:tem_programa

rem codigo do app: na subpasta "programa" (desde a 1.5.0) ou nesta pasta (versoes anteriores)
set "PROG=%~dp0"
if exist "%~dp0programa\app.py" set "PROG=%~dp0programa\"

rem ---------- 1. gerenciador de Python (uv) ----------
if exist "%UV%" goto :tem_uv
echo [1/6] Baixando o gerenciador de Python...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; $z=Join-Path $env:DADOS 'uv.zip'; $t=Join-Path $env:DADOS 'uv-tmp'; Invoke-WebRequest ('https://github.com/astral-sh/uv/releases/download/'+$env:REALCE_UV_VERSAO+'/uv-x86_64-pc-windows-msvc.zip') -OutFile $z; if((Get-FileHash $z -Algorithm SHA256).Hash -ne $env:REALCE_UV_SHA256.ToUpper()){Remove-Item $z; throw 'o uv baixado nao confere (SHA-256)'}; Expand-Archive -Force $z $t; New-Item -ItemType Directory -Force (Join-Path $env:DADOS 'uv') | Out-Null; Get-ChildItem $t -Recurse -Filter 'uv*.exe' | Move-Item -Destination (Join-Path $env:DADOS 'uv') -Force; Remove-Item -Recurse -Force $t,$z"
if errorlevel 1 goto :erro
:tem_uv

rem ---------- 2. Python 3.12 + ambiente isolado ----------
echo [2/6] Preparando o Python 3.12...
if exist "%PY%" goto :tem_venv
"%UV%" venv --python 3.12 "%~dp0.venv"
if errorlevel 1 goto :erro
:tem_venv

rem ---------- 3. PyTorch: GPU NVIDIA ou CPU ----------
set "TORCH_INDEX=https://download.pytorch.org/whl/cpu"
set "MODO=CPU"
if defined REALCE_FORCAR_CPU goto :instala_torch
nvidia-smi -L >nul 2>nul
if errorlevel 1 goto :instala_torch
set "TORCH_INDEX=https://download.pytorch.org/whl/cu126"
set "MODO=GPU"
:instala_torch
if "%MODO%"=="GPU" echo [3/6] Placa NVIDIA encontrada: instalando o PyTorch com aceleração CUDA...
if "%MODO%"=="CPU" echo [3/6] Sem placa NVIDIA: instalando o PyTorch para processador...
"%UV%" pip install --python "%PY%" torch torchvision --index-url %TORCH_INDEX%
if errorlevel 1 goto :erro
if "%MODO%"=="CPU" goto :bibliotecas
"%PY%" -c "import sys, torch; ok = torch.cuda.is_available(); print('    GPU em uso:', torch.cuda.get_device_name(0) if ok else 'nenhuma'); sys.exit(0 if ok else 1)"
if not errorlevel 1 goto :bibliotecas
echo.
echo  AVISO: a placa NVIDIA foi encontrada, mas o PyTorch não conseguiu usá-la.
echo  Atualize o driver em https://www.nvidia.com/pt-br/drivers/ e rode este instalador de novo.
echo  Por enquanto o Realce IA vai funcionar pelo processador, mais devagar.
echo.

:bibliotecas
rem ---------- 4. demais bibliotecas ----------
echo [4/6] Instalando as bibliotecas do Realce IA...
rem instalacoes antigas tem o onnxruntime comum: ele da lugar ao com DirectML (placa de video)
set "TROCA_ONNX="
"%PY%" -c "import importlib.metadata as m; m.distribution('onnxruntime')" >nul 2>nul
if not errorlevel 1 set "TROCA_ONNX=1"
if defined TROCA_ONNX "%UV%" pip uninstall --python "%PY%" onnxruntime
"%UV%" pip install --python "%PY%" -r "%PROG%requirements.txt"
if errorlevel 1 goto :erro
if defined TROCA_ONNX "%UV%" pip install --python "%PY%" --reinstall --no-deps onnxruntime-directml
if errorlevel 1 goto :erro

rem ---------- 5. modelos de IA ----------
echo [5/6] Conferindo os modelos de IA (na primeira vez, cerca de 3,2 GB)...
pushd "%PROG%"
"%PY%" download_weights.py
set "ERRO=%errorlevel%"
popd
if not "%ERRO%"=="0" goto :erro

rem ---------- 6. atalhos ----------
if defined REALCE_SEM_ATALHOS goto :fim
echo [6/6] Criando atalhos na Área de Trabalho e no Menu Iniciar...
pushd "%PROG%"
"%PY%" -m realce.atalhos
if errorlevel 1 echo  Não consegui criar os atalhos; use o arquivo "Realce IA.bat" desta pasta.
popd

:fim
echo.
echo  Pronto! O Realce IA está abrindo. Das próximas vezes, abra pelo atalho "Realce IA" na Área de
echo  Trabalho ou no Menu Iniciar.
if defined REALCE_SEM_PAUSA exit /b 0
start "" "%~dp0.venv\Scripts\pythonw.exe" "%PROG%realceia.pyw"
timeout /t 6 >nul
exit /b 0

:erro
echo.
echo  ERRO: a instalação parou. Verifique a conexão com a internet e rode o instalador de novo;
echo  ele continua de onde parou. Se o erro se repetir, copie as mensagens acima.
:erro_fim
if not defined REALCE_SEM_PAUSA pause
exit /b 1
